// Generates migrations/0002_seed_data.sql with properly hashed demo passwords
// using the exact same algorithm as src/utils/crypto.ts (Node crypto, SHA-256 x1000).
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

function sha256Hex(data) {
  return crypto.createHash('sha256').update(data).digest('hex');
}

function hashPassword(password, saltHex) {
  const salt = saltHex || crypto.randomBytes(16).toString('hex');
  let value = salt + ':' + password;
  for (let i = 0; i < 1000; i++) value = sha256Hex(value);
  return `${salt}:${value}`;
}

function esc(s) {
  return String(s).replace(/'/g, "''");
}

const lines = [];
lines.push('-- Auto-generated seed data with hashed demo passwords. Do not edit by hand; regenerate with scripts/gen-seed.cjs');
lines.push('');

// ---- Demo Hotels ----
lines.push(`INSERT OR IGNORE INTO hotels (id, name, code, property_type_id, address, city, country, phone, email, currency, tax_rate, checkin_time, checkout_time) VALUES
  (1, 'PCH PMS Lagos', 'PSL', 1, '12 Admiralty Way, Lekki Phase 1', 'Lagos', 'Nigeria', '+234 801 234 5678', 'lagos@pchpms.com', '₦', 7.5, '14:00', '12:00'),
  (2, 'PCH PMS Abuja', 'PSA', 1, '5 Aminu Kano Crescent, Wuse 2', 'Abuja', 'Nigeria', '+234 802 345 6789', 'abuja@pchpms.com', '₦', 7.5, '14:00', '12:00');`);
lines.push('');

// ---- Room Types ----
lines.push(`INSERT OR IGNORE INTO room_types (id, hotel_id, name, base_price, max_occupancy, color) VALUES
  (1, 1, 'Standard Room', 25000, 2, '#6C63FF'),
  (2, 1, 'Deluxe Room', 40000, 2, '#00C9A7'),
  (3, 1, 'Executive Suite', 65000, 3, '#FF9800'),
  (4, 2, 'Standard Room', 22000, 2, '#6C63FF'),
  (5, 2, 'Deluxe Room', 38000, 2, '#00C9A7');`);
lines.push('');

// ---- Rooms ----
const roomRows = [];
let roomId = 1;
// Lagos - Standard (type 1): 101-108
for (let i = 1; i <= 8; i++) { roomRows.push(`(${roomId++}, 1, 1, '${100 + i}', 1, 'available')`); }
// Lagos - Deluxe (type 2): 201-206
for (let i = 1; i <= 6; i++) { roomRows.push(`(${roomId++}, 1, 2, '${200 + i}', 2, 'available')`); }
// Lagos - Executive Suite (type 3): 301-303
for (let i = 1; i <= 3; i++) { roomRows.push(`(${roomId++}, 1, 3, '${300 + i}', 3, 'available')`); }
// Abuja - Standard (type 4): 101-106
for (let i = 1; i <= 6; i++) { roomRows.push(`(${roomId++}, 2, 4, '${100 + i}', 1, 'available')`); }
// Abuja - Deluxe (type 5): 201-204
for (let i = 1; i <= 4; i++) { roomRows.push(`(${roomId++}, 2, 5, '${200 + i}', 2, 'available')`); }
lines.push(`INSERT OR IGNORE INTO rooms (id, hotel_id, room_type_id, room_number, floor, status) VALUES\n  ${roomRows.join(',\n  ')};`);
lines.push('');

// ---- Staff Users (hashed passwords) ----
const users = [
  { id: 1, hotel_id: null, username: 'superadmin', password: 'super123', full_name: 'System Super Admin', role: 'super_admin', email: 'superadmin@pchpms.com', perms: { all: true } },
  { id: 2, hotel_id: 1, username: 'admin1', password: 'admin123', full_name: 'Adaeze Okafor', role: 'admin', email: 'admin1@pchpms.com', perms: { all: true } },
  { id: 3, hotel_id: 1, username: 'linda', password: 'linda123', full_name: 'Linda Chukwu', role: 'receptionist', email: 'linda@pchpms.com', perms: { dashboard: true, reservations: true, checkin: true, guests: true, rooms: true, payments: true, invoices: true, shifts: true, pos: true, arrivals: true, inhouse: true, messaging: true } },
  { id: 4, hotel_id: 1, username: 'tunde', password: 'tunde123', full_name: 'Tunde Bakare', role: 'housekeeping', email: 'tunde@pchpms.com', perms: { housekeeping: true, rooms_status: true } },
  { id: 5, hotel_id: 2, username: 'admin2', password: 'admin123', full_name: 'Ibrahim Musa', role: 'admin', email: 'admin2@pchpms.com', perms: { all: true } },
];

for (const u of users) {
  const hash = hashPassword(u.password);
  lines.push(`INSERT OR IGNORE INTO users (id, hotel_id, username, password_hash, full_name, role, email, permissions) VALUES (${u.id}, ${u.hotel_id === null ? 'NULL' : u.hotel_id}, '${esc(u.username)}', '${hash}', '${esc(u.full_name)}', '${u.role}', '${esc(u.email)}', '${esc(JSON.stringify(u.perms))}');`);
}
lines.push('');

// ---- Sample Guests ----
lines.push(`INSERT OR IGNORE INTO guests (id, hotel_id, first_name, last_name, phone, email, nationality, vip_status, loyalty_points, loyalty_tier) VALUES
  (1, 1, 'Chidi', 'Eze', '+234 803 111 2222', 'chidi.eze@example.com', 'Nigerian', 1, 2400, 'gold'),
  (2, 1, 'Fatima', 'Abdullahi', '+234 805 222 3333', 'fatima.a@example.com', 'Nigerian', 0, 350, 'bronze'),
  (3, 2, 'John', 'Smith', '+1 202 555 0147', 'john.smith@example.com', 'American', 1, 6200, 'platinum');`);
lines.push('');

// ---- POS Items ----
lines.push(`INSERT OR IGNORE INTO pos_items (id, hotel_id, name, price, category) VALUES
  (1, 1, 'Jollof Rice & Chicken', 4500, 'food'),
  (2, 1, 'Club Soda', 1000, 'beverage'),
  (3, 1, 'Laundry Service', 3000, 'service'),
  (4, 2, 'Continental Breakfast', 5000, 'food'),
  (5, 2, 'Bottled Water', 500, 'beverage');`);
lines.push('');

const outPath = path.join(__dirname, '..', 'migrations', '0002_seed_data.sql');
fs.writeFileSync(outPath, lines.join('\n') + '\n');
console.log('Wrote', outPath);
console.log('Demo credentials:');
for (const u of users) console.log(`  ${u.username} / ${u.password}  (${u.role})`);
