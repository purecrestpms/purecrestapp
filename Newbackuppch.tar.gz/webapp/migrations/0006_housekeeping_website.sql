-- PCH PMS v4: Room housekeeping statuses + Property Website / Direct Booking Engine

-- ==================== Housekeeping Status ====================
-- Separate from the operational `rooms.status` (available|occupied|reserved|maintenance),
-- this tracks the physical/cleanliness state front desk & housekeeping care about:
--   vacant_clean | vacant_dirty | occupied | reserved | out_of_order
ALTER TABLE rooms ADD COLUMN housekeeping_status TEXT DEFAULT 'vacant_clean';

UPDATE rooms SET housekeeping_status = CASE status
  WHEN 'occupied' THEN 'occupied'
  WHEN 'reserved' THEN 'reserved'
  WHEN 'maintenance' THEN 'out_of_order'
  ELSE 'vacant_clean'
END WHERE housekeeping_status IS NULL OR housekeeping_status = 'vacant_clean';

CREATE INDEX IF NOT EXISTS idx_rooms_housekeeping_status ON rooms(housekeeping_status);

-- ==================== Property Website / Direct Booking Engine ====================
CREATE TABLE IF NOT EXISTS website_settings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  hotel_id INTEGER NOT NULL UNIQUE,
  is_enabled INTEGER DEFAULT 0,
  slug TEXT UNIQUE,
  template TEXT DEFAULT 'modern', -- modern | classic
  primary_color TEXT DEFAULT '#3B82F6',
  hero_title TEXT,
  hero_subtitle TEXT,
  hero_image_url TEXT,
  about_text TEXT,
  contact_phone TEXT,
  contact_email TEXT,
  contact_address TEXT,
  show_rates INTEGER DEFAULT 1,
  min_stay_nights INTEGER DEFAULT 1,
  booking_notice_hours INTEGER DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (hotel_id) REFERENCES hotels(id)
);

CREATE TABLE IF NOT EXISTS website_bookings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  hotel_id INTEGER NOT NULL,
  reservation_id INTEGER,
  room_type_id INTEGER,
  guest_name TEXT,
  guest_email TEXT,
  guest_phone TEXT,
  check_in_date TEXT,
  check_out_date TEXT,
  status TEXT DEFAULT 'pending', -- pending | confirmed | failed
  message TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (hotel_id) REFERENCES hotels(id)
);

CREATE INDEX IF NOT EXISTS idx_website_bookings_hotel ON website_bookings(hotel_id);
