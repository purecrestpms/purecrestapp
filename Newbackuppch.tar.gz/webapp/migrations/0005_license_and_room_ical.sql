-- PCH PMS v3: Platform licensing + per-room iCal feeds (import & export)

-- ==================== Licensing ====================
-- Single-row (or few historical rows) license record for this platform install.
CREATE TABLE IF NOT EXISTS license (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  license_key TEXT,
  status TEXT DEFAULT 'trial', -- trial | active | expired | suspended
  plan TEXT DEFAULT 'trial',
  customer_name TEXT,
  customer_email TEXT,
  max_hotels INTEGER DEFAULT 1,
  max_rooms INTEGER DEFAULT 50,
  trial_started_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  trial_days INTEGER DEFAULT 14,
  activated_at DATETIME,
  expires_at DATETIME,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

INSERT OR IGNORE INTO license (id, status, plan, trial_started_at, trial_days, max_hotels, max_rooms)
VALUES (1, 'trial', 'trial', CURRENT_TIMESTAMP, 14, 3, 200);

CREATE TABLE IF NOT EXISTS license_history (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  action TEXT NOT NULL, -- activated | renewed | expired | suspended
  license_key TEXT,
  plan TEXT,
  note TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- ==================== Per-Room iCal Feeds ====================
-- Every room/unit can have its own import feed (pull bookings from an OTA's
-- per-listing iCal export URL) and its own export token (so the OTA can pull
-- this room's live availability back). This is independent of the hotel-wide
-- Channel Manager connections and lets small operators map 1 OTA listing : 1 room.
CREATE TABLE IF NOT EXISTS room_ical_feeds (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  hotel_id INTEGER NOT NULL,
  room_id INTEGER NOT NULL,
  label TEXT,
  source_name TEXT DEFAULT 'Other', -- Booking.com | Airbnb | Expedia | Other...
  import_url TEXT,
  export_token TEXT,
  auto_sync INTEGER DEFAULT 1,
  status TEXT DEFAULT 'pending', -- pending | connected | error
  last_sync_at DATETIME,
  last_sync_status TEXT,
  created_by INTEGER,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (hotel_id) REFERENCES hotels(id),
  FOREIGN KEY (room_id) REFERENCES rooms(id)
);

CREATE TABLE IF NOT EXISTS room_ical_sync_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  hotel_id INTEGER NOT NULL,
  feed_id INTEGER NOT NULL,
  room_id INTEGER,
  status TEXT DEFAULT 'success',
  events_fetched INTEGER DEFAULT 0,
  created_count INTEGER DEFAULT 0,
  updated_count INTEGER DEFAULT 0,
  cancelled_count INTEGER DEFAULT 0,
  duplicates_skipped INTEGER DEFAULT 0,
  conflicts_detected INTEGER DEFAULT 0,
  message TEXT,
  started_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  finished_at DATETIME
);

-- Link a reservation back to the specific per-room feed that created it, so a
-- later sync can detect the external booking was modified or cancelled.
ALTER TABLE reservations ADD COLUMN ical_feed_id INTEGER;

CREATE INDEX IF NOT EXISTS idx_room_ical_feeds_room ON room_ical_feeds(room_id);
CREATE INDEX IF NOT EXISTS idx_room_ical_feeds_hotel ON room_ical_feeds(hotel_id);
CREATE INDEX IF NOT EXISTS idx_room_ical_sync_logs_feed ON room_ical_sync_logs(feed_id);
CREATE INDEX IF NOT EXISTS idx_reservations_ical_feed ON reservations(ical_feed_id);
