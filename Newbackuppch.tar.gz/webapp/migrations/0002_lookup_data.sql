-- PCH PMS seed data: property types, roles, OTA channel catalog, demo hotels/staff/rooms
-- Demo password for every seeded account is set via app.js migration note; actual hashes
-- are inserted by scripts/seed.ts at migration time (Web Crypto hashing can't run in plain SQL).

INSERT OR IGNORE INTO property_types (id, name, description, icon, is_system) VALUES
  (1, 'Hotel', 'Full-service hotel with multiple room types', 'fa-hotel', 1),
  (2, 'Apartment / Serviced Apartment', 'Self-contained apartment units for short or long stays', 'fa-building', 1),
  (3, 'Guesthouse / B&B', 'Small guesthouse or bed & breakfast', 'fa-house-chimney', 1),
  (4, 'Resort', 'Resort property with leisure facilities', 'fa-umbrella-beach', 1),
  (5, 'Hostel', 'Budget hostel with shared or private rooms', 'fa-bed', 1);

INSERT OR IGNORE INTO roles (id, key, name, description, permissions, is_system) VALUES
  (1, 'super_admin', 'Super Admin', 'Full platform access across all hotels', '{"all":true}', 1),
  (2, 'admin', 'Hotel Admin', 'Full access within an assigned hotel', '{"all":true}', 1),
  (3, 'manager', 'Manager', 'Full operational access within an assigned hotel', '{"all":true}', 1),
  (4, 'receptionist', 'Receptionist', 'Front-desk operations: reservations, check-in/out, guests, payments', '{"dashboard":true,"reservations":true,"checkin":true,"guests":true,"rooms":true,"payments":true,"invoices":true,"shifts":true,"pos":true,"arrivals":true,"inhouse":true,"messaging":true}', 1),
  (5, 'housekeeping', 'Housekeeping', 'Room status and housekeeping task management', '{"housekeeping":true,"rooms_status":true}', 1),
  (6, 'accountant', 'Accountant', 'Payments, invoices and reporting access', '{"reports":true,"payments":true,"invoices":true}', 1);

INSERT OR IGNORE INTO ota_channels (id, name, slug, type, icon, color, is_builtin) VALUES
  (1, 'Booking.com', 'booking', 'ical', 'fa-b', '#003580', 1),
  (2, 'Airbnb', 'airbnb', 'ical', 'fa-airbnb', '#FF5A5F', 1),
  (3, 'Expedia', 'expedia', 'ical', 'fa-plane', '#FFC72C', 1),
  (4, 'Agoda', 'agoda', 'ical', 'fa-a', '#5392F9', 1),
  (5, 'Hotels.com', 'hotelscom', 'ical', 'fa-h', '#D32F2F', 1),
  (6, 'Google Hotels', 'google', 'ical', 'fa-google', '#4285F4', 1),
  (7, 'Direct Website', 'direct', 'api', 'fa-globe', '#6C63FF', 1);
