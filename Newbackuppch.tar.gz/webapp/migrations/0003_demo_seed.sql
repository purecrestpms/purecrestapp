-- Auto-generated seed data with hashed demo passwords. Do not edit by hand; regenerate with scripts/gen-seed.cjs

INSERT OR IGNORE INTO hotels (id, name, code, property_type_id, address, city, country, phone, email, currency, tax_rate, checkin_time, checkout_time) VALUES
  (1, 'PCH PMS Lagos', 'PSL', 1, '12 Admiralty Way, Lekki Phase 1', 'Lagos', 'Nigeria', '+234 801 234 5678', 'lagos@pchpms.com', '₦', 7.5, '14:00', '12:00'),
  (2, 'PCH PMS Abuja', 'PSA', 1, '5 Aminu Kano Crescent, Wuse 2', 'Abuja', 'Nigeria', '+234 802 345 6789', 'abuja@pchpms.com', '₦', 7.5, '14:00', '12:00');

INSERT OR IGNORE INTO room_types (id, hotel_id, name, base_price, max_occupancy, color) VALUES
  (1, 1, 'Standard Room', 25000, 2, '#6C63FF'),
  (2, 1, 'Deluxe Room', 40000, 2, '#00C9A7'),
  (3, 1, 'Executive Suite', 65000, 3, '#FF9800'),
  (4, 2, 'Standard Room', 22000, 2, '#6C63FF'),
  (5, 2, 'Deluxe Room', 38000, 2, '#00C9A7');

INSERT OR IGNORE INTO rooms (id, hotel_id, room_type_id, room_number, floor, status) VALUES
  (1, 1, 1, '101', 1, 'available'),
  (2, 1, 1, '102', 1, 'available'),
  (3, 1, 1, '103', 1, 'available'),
  (4, 1, 1, '104', 1, 'available'),
  (5, 1, 1, '105', 1, 'available'),
  (6, 1, 1, '106', 1, 'available'),
  (7, 1, 1, '107', 1, 'available'),
  (8, 1, 1, '108', 1, 'available'),
  (9, 1, 2, '201', 2, 'available'),
  (10, 1, 2, '202', 2, 'available'),
  (11, 1, 2, '203', 2, 'available'),
  (12, 1, 2, '204', 2, 'available'),
  (13, 1, 2, '205', 2, 'available'),
  (14, 1, 2, '206', 2, 'available'),
  (15, 1, 3, '301', 3, 'available'),
  (16, 1, 3, '302', 3, 'available'),
  (17, 1, 3, '303', 3, 'available'),
  (18, 2, 4, '101', 1, 'available'),
  (19, 2, 4, '102', 1, 'available'),
  (20, 2, 4, '103', 1, 'available'),
  (21, 2, 4, '104', 1, 'available'),
  (22, 2, 4, '105', 1, 'available'),
  (23, 2, 4, '106', 1, 'available'),
  (24, 2, 5, '201', 2, 'available'),
  (25, 2, 5, '202', 2, 'available'),
  (26, 2, 5, '203', 2, 'available'),
  (27, 2, 5, '204', 2, 'available');

INSERT OR IGNORE INTO users (id, hotel_id, username, password_hash, full_name, role, email, permissions) VALUES (1, NULL, 'superadmin', 'cfdc6841bb39f9ed200557c7a825dc5e:30f0cb938e47c19ccd0ebde15da023ecbc3d2d7e770c92beef4331b1176d65f4', 'System Super Admin', 'super_admin', 'superadmin@pchpms.com', '{"all":true}');
INSERT OR IGNORE INTO users (id, hotel_id, username, password_hash, full_name, role, email, permissions) VALUES (2, 1, 'admin1', '767cb60b4a7461544be1aa68a6503ca7:140d73e7d180379b849c55c903923498174e7a2314e1c86d0786e8c4cb84217e', 'Adaeze Okafor', 'admin', 'admin1@pchpms.com', '{"all":true}');
INSERT OR IGNORE INTO users (id, hotel_id, username, password_hash, full_name, role, email, permissions) VALUES (3, 1, 'linda', 'f25f545fa6dcc8a9a20fc8b45230672b:1b8de3145e5a6446adc78a27cea214e31b9ed9deba83b63db55e8b2cd3f41593', 'Linda Chukwu', 'receptionist', 'linda@pchpms.com', '{"dashboard":true,"reservations":true,"checkin":true,"guests":true,"rooms":true,"payments":true,"invoices":true,"shifts":true,"pos":true,"arrivals":true,"inhouse":true,"messaging":true}');
INSERT OR IGNORE INTO users (id, hotel_id, username, password_hash, full_name, role, email, permissions) VALUES (4, 1, 'tunde', 'f1269debee043198efae197d73ce3388:b4ceccb92b58db0bbc80889f2403fc9511e96ec93acdd5be49910295cde1958c', 'Tunde Bakare', 'housekeeping', 'tunde@pchpms.com', '{"housekeeping":true,"rooms_status":true}');
INSERT OR IGNORE INTO users (id, hotel_id, username, password_hash, full_name, role, email, permissions) VALUES (5, 2, 'admin2', 'be3043a1b123f03c1efffeab92947625:96416c2876bc7e0abcc17681f9ac98556ee6d960213c7a1ca2e1dc9ac787eefc', 'Ibrahim Musa', 'admin', 'admin2@pchpms.com', '{"all":true}');

INSERT OR IGNORE INTO guests (id, hotel_id, first_name, last_name, phone, email, nationality, vip_status, loyalty_points, loyalty_tier) VALUES
  (1, 1, 'Chidi', 'Eze', '+234 803 111 2222', 'chidi.eze@example.com', 'Nigerian', 1, 2400, 'gold'),
  (2, 1, 'Fatima', 'Abdullahi', '+234 805 222 3333', 'fatima.a@example.com', 'Nigerian', 0, 350, 'bronze'),
  (3, 2, 'John', 'Smith', '+1 202 555 0147', 'john.smith@example.com', 'American', 1, 6200, 'platinum');

INSERT OR IGNORE INTO pos_items (id, hotel_id, name, price, category) VALUES
  (1, 1, 'Jollof Rice & Chicken', 4500, 'food'),
  (2, 1, 'Club Soda', 1000, 'beverage'),
  (3, 1, 'Laundry Service', 3000, 'service'),
  (4, 2, 'Continental Breakfast', 5000, 'food'),
  (5, 2, 'Bottled Water', 500, 'beverage');

