-- PCH PMS v2: Room/Room-Type features (shortlet apartments etc.), room image gallery, teams

-- Room types: bedrooms/bathrooms (for apartments/shortlets) + feature list (JSON array of strings)
ALTER TABLE room_types ADD COLUMN bedrooms INTEGER DEFAULT 1;
ALTER TABLE room_types ADD COLUMN bathrooms INTEGER DEFAULT 1;
ALTER TABLE room_types ADD COLUMN unit_kind TEXT DEFAULT 'room'; -- room | apartment | studio | suite
ALTER TABLE room_types ADD COLUMN features TEXT DEFAULT '[]';

-- Individual rooms: per-unit feature overrides + description
ALTER TABLE rooms ADD COLUMN features TEXT DEFAULT '[]';
ALTER TABLE rooms ADD COLUMN description TEXT DEFAULT '';

-- Room photo gallery (stored in R2, served via /files/:key)
CREATE TABLE IF NOT EXISTS room_images (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  room_id INTEGER NOT NULL,
  image_key TEXT NOT NULL,
  image_url TEXT NOT NULL,
  is_primary INTEGER DEFAULT 0,
  sort_order INTEGER DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (room_id) REFERENCES rooms(id)
);

-- Teams: group staff for shift/task assignment
CREATE TABLE IF NOT EXISTS teams (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  hotel_id INTEGER NOT NULL,
  name TEXT NOT NULL,
  description TEXT,
  color TEXT DEFAULT '#6C63FF',
  created_by INTEGER,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS team_members (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  team_id INTEGER NOT NULL,
  user_id INTEGER NOT NULL,
  role_in_team TEXT DEFAULT 'member',
  added_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (team_id) REFERENCES teams(id),
  FOREIGN KEY (user_id) REFERENCES users(id),
  UNIQUE(team_id, user_id)
);

CREATE INDEX IF NOT EXISTS idx_room_images_room ON room_images(room_id);
CREATE INDEX IF NOT EXISTS idx_teams_hotel ON teams(hotel_id);
CREATE INDEX IF NOT EXISTS idx_team_members_team ON team_members(team_id);
CREATE INDEX IF NOT EXISTS idx_team_members_user ON team_members(user_id);
