-- PCH PMS Multi-Hotel PMS - Core Schema

CREATE TABLE IF NOT EXISTS property_types (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE,
  description TEXT,
  icon TEXT DEFAULT 'fa-hotel',
  is_system INTEGER DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS roles (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  key TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  description TEXT,
  permissions TEXT DEFAULT '{}',
  is_system INTEGER DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS hotels (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  code TEXT UNIQUE,
  property_type_id INTEGER,
  address TEXT,
  city TEXT,
  country TEXT,
  phone TEXT,
  email TEXT,
  currency TEXT DEFAULT '₦',
  tax_rate REAL DEFAULT 7.5,
  checkin_time TEXT DEFAULT '14:00',
  checkout_time TEXT DEFAULT '12:00',
  timezone TEXT DEFAULT 'Africa/Lagos',
  is_active INTEGER DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (property_type_id) REFERENCES property_types(id)
);

CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  hotel_id INTEGER,
  username TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  full_name TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'receptionist',
  email TEXT,
  phone TEXT,
  permissions TEXT DEFAULT '{}',
  is_active INTEGER DEFAULT 1,
  last_login DATETIME,
  created_by INTEGER,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (hotel_id) REFERENCES hotels(id)
);

CREATE TABLE IF NOT EXISTS room_types (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  hotel_id INTEGER NOT NULL,
  name TEXT NOT NULL,
  base_price REAL NOT NULL DEFAULT 0,
  max_occupancy INTEGER DEFAULT 2,
  color TEXT DEFAULT '#6C63FF',
  description TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (hotel_id) REFERENCES hotels(id)
);

CREATE TABLE IF NOT EXISTS rooms (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  hotel_id INTEGER NOT NULL,
  room_type_id INTEGER NOT NULL,
  room_number TEXT NOT NULL,
  floor INTEGER DEFAULT 1,
  status TEXT DEFAULT 'available',
  notes TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (hotel_id) REFERENCES hotels(id),
  FOREIGN KEY (room_type_id) REFERENCES room_types(id)
);

CREATE TABLE IF NOT EXISTS guests (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  hotel_id INTEGER,
  first_name TEXT NOT NULL,
  last_name TEXT NOT NULL,
  phone TEXT,
  email TEXT,
  id_type TEXT,
  id_number TEXT,
  nationality TEXT,
  address TEXT,
  city TEXT,
  country TEXT,
  date_of_birth TEXT,
  gender TEXT,
  company TEXT,
  vip_status INTEGER DEFAULT 0,
  loyalty_points INTEGER DEFAULT 0,
  loyalty_tier TEXT DEFAULT 'bronze',
  total_stays INTEGER DEFAULT 0,
  total_spent REAL DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (hotel_id) REFERENCES hotels(id)
);

CREATE TABLE IF NOT EXISTS reservations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  hotel_id INTEGER NOT NULL,
  reservation_code TEXT UNIQUE,
  guest_id INTEGER NOT NULL,
  room_type_id INTEGER,
  room_id INTEGER,
  check_in_date TEXT NOT NULL,
  check_out_date TEXT NOT NULL,
  actual_check_in DATETIME,
  actual_check_out DATETIME,
  adults INTEGER DEFAULT 1,
  children INTEGER DEFAULT 0,
  rate_per_night REAL DEFAULT 0,
  total_amount REAL DEFAULT 0,
  paid_amount REAL DEFAULT 0,
  status TEXT DEFAULT 'reserved',
  source TEXT DEFAULT 'walk-in',
  channel_id INTEGER,
  external_uid TEXT,
  is_flagged_duplicate INTEGER DEFAULT 0,
  key_card_number TEXT,
  key_assigned INTEGER DEFAULT 0,
  special_requests TEXT,
  created_by INTEGER,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (hotel_id) REFERENCES hotels(id),
  FOREIGN KEY (guest_id) REFERENCES guests(id),
  FOREIGN KEY (room_id) REFERENCES rooms(id)
);

CREATE TABLE IF NOT EXISTS payments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  hotel_id INTEGER,
  reservation_id INTEGER,
  guest_id INTEGER,
  amount REAL NOT NULL,
  payment_method TEXT DEFAULT 'cash',
  payment_type TEXT DEFAULT 'room_charge',
  reference_number TEXT,
  notes TEXT,
  shift_id INTEGER,
  received_by INTEGER,
  is_refund INTEGER DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS invoices (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  hotel_id INTEGER,
  invoice_number TEXT UNIQUE,
  reservation_id INTEGER,
  guest_id INTEGER,
  subtotal REAL DEFAULT 0,
  tax_amount REAL DEFAULT 0,
  discount_amount REAL DEFAULT 0,
  total_amount REAL DEFAULT 0,
  amount_paid REAL DEFAULT 0,
  balance_due REAL DEFAULT 0,
  status TEXT DEFAULT 'draft',
  items TEXT DEFAULT '[]',
  created_by INTEGER,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS housekeeping_tasks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  hotel_id INTEGER,
  room_id INTEGER NOT NULL,
  task_type TEXT DEFAULT 'cleaning',
  priority TEXT DEFAULT 'normal',
  status TEXT DEFAULT 'pending',
  assigned_to INTEGER,
  notes TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  completed_at DATETIME
);

CREATE TABLE IF NOT EXISTS pos_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  hotel_id INTEGER,
  name TEXT NOT NULL,
  price REAL NOT NULL,
  category TEXT DEFAULT 'food',
  is_active INTEGER DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS pos_orders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  hotel_id INTEGER,
  order_number TEXT,
  reservation_id INTEGER,
  guest_id INTEGER,
  room_id INTEGER,
  items TEXT DEFAULT '[]',
  subtotal REAL DEFAULT 0,
  tax REAL DEFAULT 0,
  total REAL DEFAULT 0,
  payment_method TEXT DEFAULT 'cash',
  payment_status TEXT DEFAULT 'paid',
  shift_id INTEGER,
  created_by INTEGER,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS shifts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  hotel_id INTEGER,
  user_id INTEGER NOT NULL,
  user_name TEXT,
  opening_cash REAL DEFAULT 0,
  total_payments REAL DEFAULT 0,
  total_cash REAL DEFAULT 0,
  total_card REAL DEFAULT 0,
  total_transfer REAL DEFAULT 0,
  expected_balance REAL DEFAULT 0,
  actual_balance REAL,
  variance REAL,
  notes TEXT,
  status TEXT DEFAULT 'open',
  start_time DATETIME DEFAULT CURRENT_TIMESTAMP,
  end_time DATETIME,
  closed_by INTEGER
);

CREATE TABLE IF NOT EXISTS messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  hotel_id INTEGER,
  from_user_id INTEGER,
  to_user_id INTEGER,
  subject TEXT,
  body TEXT,
  priority TEXT DEFAULT 'normal',
  is_broadcast INTEGER DEFAULT 0,
  is_read INTEGER DEFAULT 0,
  is_trashed INTEGER DEFAULT 0,
  reply_to INTEGER,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS loyalty_transactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  guest_id INTEGER NOT NULL,
  type TEXT NOT NULL,
  points INTEGER NOT NULL,
  description TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS activity_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  hotel_id INTEGER,
  user_id INTEGER,
  user_name TEXT,
  action TEXT,
  details TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- ==================== Reservation Calendar: Date Blocking ====================
CREATE TABLE IF NOT EXISTS room_blocks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  hotel_id INTEGER NOT NULL,
  room_id INTEGER,
  room_type_id INTEGER,
  start_date TEXT NOT NULL,
  end_date TEXT NOT NULL,
  reason TEXT,
  block_type TEXT DEFAULT 'manual',
  source_channel_id INTEGER,
  created_by INTEGER,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- ==================== Channel Manager ====================
CREATE TABLE IF NOT EXISTS ota_channels (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  type TEXT DEFAULT 'ical',
  icon TEXT DEFAULT 'fa-globe',
  color TEXT DEFAULT '#6C63FF',
  is_builtin INTEGER DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS channel_connections (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  hotel_id INTEGER NOT NULL,
  channel_id INTEGER NOT NULL,
  room_type_id INTEGER,
  label TEXT,
  ical_import_url TEXT,
  ical_export_token TEXT,
  api_key TEXT,
  api_secret TEXT,
  connection_mode TEXT DEFAULT 'ical',
  status TEXT DEFAULT 'pending',
  auto_sync INTEGER DEFAULT 1,
  last_sync_at DATETIME,
  last_sync_status TEXT,
  created_by INTEGER,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS channel_sync_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  hotel_id INTEGER NOT NULL,
  connection_id INTEGER,
  channel_name TEXT,
  direction TEXT DEFAULT 'import',
  status TEXT DEFAULT 'success',
  events_fetched INTEGER DEFAULT 0,
  reservations_created INTEGER DEFAULT 0,
  reservations_updated INTEGER DEFAULT 0,
  duplicates_skipped INTEGER DEFAULT 0,
  conflicts_detected INTEGER DEFAULT 0,
  message TEXT,
  started_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  finished_at DATETIME
);

CREATE INDEX IF NOT EXISTS idx_reservations_hotel ON reservations(hotel_id);
CREATE INDEX IF NOT EXISTS idx_reservations_room ON reservations(room_id);
CREATE INDEX IF NOT EXISTS idx_reservations_dates ON reservations(check_in_date, check_out_date);
CREATE INDEX IF NOT EXISTS idx_reservations_status ON reservations(status);
CREATE INDEX IF NOT EXISTS idx_reservations_external ON reservations(external_uid);
CREATE INDEX IF NOT EXISTS idx_rooms_hotel ON rooms(hotel_id);
CREATE INDEX IF NOT EXISTS idx_guests_hotel ON guests(hotel_id);
CREATE INDEX IF NOT EXISTS idx_payments_reservation ON payments(reservation_id);
CREATE INDEX IF NOT EXISTS idx_users_hotel ON users(hotel_id);
CREATE INDEX IF NOT EXISTS idx_room_blocks_room ON room_blocks(room_id);
CREATE INDEX IF NOT EXISTS idx_room_blocks_dates ON room_blocks(start_date, end_date);
CREATE INDEX IF NOT EXISTS idx_channel_connections_hotel ON channel_connections(hotel_id);
CREATE INDEX IF NOT EXISTS idx_channel_sync_logs_hotel ON channel_sync_logs(hotel_id);
