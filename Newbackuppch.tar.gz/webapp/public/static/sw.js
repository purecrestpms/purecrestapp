const CACHE_VERSION = 'pchpms-v1';
const STATIC_CACHE = CACHE_VERSION + '-static';
const API_CACHE = CACHE_VERSION + '-api';
const CDN_CACHE = CACHE_VERSION + '-cdn';

const STATIC_ASSETS = [
  '/',
  '/static/app.js',
  '/static/style.css',
  '/static/manifest.webmanifest',
  '/static/icon-192.png',
  '/static/icon-512.png'
];

const CDN_ASSETS = [
  'https://cdn.tailwindcss.com',
  'https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.5.0/css/all.min.css',
  'https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css',
  'https://cdn.jsdelivr.net/npm/flatpickr/dist/themes/material_purple.css',
  'https://cdn.jsdelivr.net/npm/flatpickr',
  'https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js',
  'https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.2/jspdf.umd.min.js',
  'https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.8.2/jspdf.plugin.autotable.min.js',
  'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap'
];

// API endpoints to cache for offline use
const CACHEABLE_API_PATHS = [
  '/api/dashboard',
  '/api/rooms',
  '/api/room-types',
  '/api/reservations',
  '/api/guests',
  '/api/housekeeping',
  '/api/invoices',
  '/api/payments',
  '/api/shifts',
  '/api/shifts/current',
  '/api/pos/items',
  '/api/pos/orders',
  '/api/settings/property',
  '/api/sync/data',
  '/api/arrivals',
  '/api/inhouse',
  '/api/users',
  '/api/reports/occupancy',
  '/api/reports/revenue',
  '/api/reports/guests'
];

// Install - cache all static and CDN assets
self.addEventListener('install', (event) => {
  event.waitUntil(
    Promise.all([
      caches.open(STATIC_CACHE).then(cache => {
        return Promise.allSettled(
          STATIC_ASSETS.map(url =>
            cache.add(new Request(url, { mode: 'same-origin' })).catch(e => {
              console.warn('Failed to cache static:', url, e);
            })
          )
        );
      }),
      caches.open(CDN_CACHE).then(cache => {
        return Promise.allSettled(
          CDN_ASSETS.map(url =>
            cache.add(new Request(url, { mode: 'cors' })).catch(e => {
              console.warn('Failed to cache CDN:', url, e);
            })
          )
        );
      })
    ])
  );
  self.skipWaiting();
});

// Activate - clean old caches
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then(keys => {
      return Promise.all(
        keys.filter(key => {
          return !key.startsWith(CACHE_VERSION);
        }).map(key => caches.delete(key))
      );
    })
  );
  self.clients.claim();
});

// Fetch handler with smart caching strategies
self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);

  // Skip non-GET requests (POST/PUT/DELETE go straight to network)
  if (event.request.method !== 'GET') {
    event.respondWith(
      fetch(event.request).catch(() => {
        return new Response(JSON.stringify({ error: 'Offline - action queued', offline: true }), {
          status: 503,
          headers: { 'Content-Type': 'application/json' }
        });
      })
    );
    return;
  }

  // API requests - Network first, fallback to cache
  if (url.pathname.startsWith('/api/')) {
    const isCacheable = CACHEABLE_API_PATHS.some(path => url.pathname.startsWith(path));
    
    event.respondWith(
      fetch(event.request)
        .then(response => {
          if (response.ok && isCacheable) {
            const clone = response.clone();
            caches.open(API_CACHE).then(cache => {
              cache.put(event.request, clone);
            });
          }
          return response;
        })
        .catch(async () => {
          // Try cached API response
          const cached = await caches.match(event.request);
          if (cached) {
            // Add offline header to indicate stale data
            const body = await cached.text();
            return new Response(body, {
              status: 200,
              headers: {
                'Content-Type': 'application/json',
                'X-From-Cache': 'true',
                'X-Cache-Date': cached.headers.get('date') || 'unknown'
              }
            });
          }
          return new Response(JSON.stringify({ error: 'Offline', offline: true }), {
            status: 503,
            headers: { 'Content-Type': 'application/json' }
          });
        })
    );
    return;
  }

  // CDN assets - Cache first, then network
  if (url.hostname !== self.location.hostname) {
    event.respondWith(
      caches.match(event.request).then(cached => {
        if (cached) return cached;
        return fetch(event.request).then(response => {
          if (response.ok) {
            const clone = response.clone();
            caches.open(CDN_CACHE).then(cache => cache.put(event.request, clone));
          }
          return response;
        }).catch(() => {
          return new Response('', { status: 503 });
        });
      })
    );
    return;
  }

  // Static assets - Cache first, then network (stale while revalidate)
  event.respondWith(
    caches.match(event.request).then(cached => {
      const fetchPromise = fetch(event.request).then(response => {
        if (response.ok) {
          const clone = response.clone();
          caches.open(STATIC_CACHE).then(cache => cache.put(event.request, clone));
        }
        return response;
      }).catch(() => null);

      // Return cached version immediately, update in background
      if (cached) {
        fetchPromise; // fire and forget update
        return cached;
      }

      return fetchPromise || caches.match('/');
    })
  );
});

// Listen for sync events
self.addEventListener('sync', (event) => {
  if (event.tag === 'purestay-sync') {
    event.waitUntil(
      self.clients.matchAll().then(clients => {
        clients.forEach(client => {
          client.postMessage({ type: 'SYNC_REQUESTED' });
        });
      })
    );
  }
});

// Listen for messages from the app
self.addEventListener('message', (event) => {
  if (event.data === 'SKIP_WAITING') {
    self.skipWaiting();
  }
  if (event.data === 'CLEAR_API_CACHE') {
    caches.delete(API_CACHE);
  }
});
