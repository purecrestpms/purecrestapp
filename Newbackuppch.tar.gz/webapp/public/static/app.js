// ==================== PCH PMS - Multi-Property PMS ====================
const APP = {
  user: JSON.parse(localStorage.getItem('ps_user') || 'null'),
  hotelId: localStorage.getItem('ps_hotel_id'),
  hotels: JSON.parse(localStorage.getItem('ps_hotels') || '[]'),
  currentPage: 'dashboard',
  data: {},
  currency: localStorage.getItem('ps_currency') || '₦',
  hotelName: localStorage.getItem('ps_hotel_name') || 'PCH PMS',
  hotelCity: localStorage.getItem('ps_hotel_city') || '',
  unreadMessages: 0
};

// ==================== UTILITIES ====================
const $ = (s) => document.querySelector(s);
const $$ = (s) => document.querySelectorAll(s);
const api = async (url, opts = {}) => {
  try {
    const headers = { 'Content-Type': 'application/json' };
    if (APP.hotelId) headers['X-Hotel-Id'] = APP.hotelId;
    const r = await fetch(`/api${url}`, { headers, ...opts });
    const d = await r.json();
    if (!r.ok) throw new Error(d.error || 'Request failed');
    return d;
  } catch (e) { showToast(e.message, 'error'); throw e; }
};
const post = (url, body) => api(url, { method: 'POST', body: JSON.stringify(body) });
const put = (url, body) => api(url, { method: 'PUT', body: JSON.stringify(body) });
const del = (url) => api(url, { method: 'DELETE' });

const fmt = (n) => APP.currency + Number(n||0).toLocaleString('en-NG', { minimumFractionDigits: 0 });
const fmtDate = (d) => d ? new Date(d+'T00:00:00').toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }) : '-';
const fmtDateTime = (dt) => dt ? new Date(dt).toLocaleString('en-GB', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }) : '-';
const fmtTime = (t) => { if (!t) return '-'; const [h, m] = t.split(':'); const hr = parseInt(h); return `${hr > 12 ? hr - 12 : hr || 12}:${m} ${hr >= 12 ? 'PM' : 'AM'}`; };
const today = () => new Date().toISOString().split('T')[0];
const dayName = () => new Date().toLocaleDateString('en-US', { weekday: 'long' });
const fullDate = () => new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
const esc = (s) => String(s||'').replace(/'/g, "\\'").replace(/"/g, '&quot;');

function showToast(msg, type = 'success') {
  const t = document.createElement('div');
  t.className = `fixed top-4 right-4 z-[9999] px-5 py-3 rounded-xl shadow-lg text-white font-medium text-sm fade-in flex items-center gap-2 ${type === 'error' ? 'bg-red-500' : type === 'warning' ? 'bg-orange-500' : 'bg-green-500'}`;
  t.innerHTML = `<i class="fas fa-${type === 'error' ? 'exclamation-circle' : type === 'warning' ? 'exclamation-triangle' : 'check-circle'}"></i> ${msg}`;
  document.body.appendChild(t);
  setTimeout(() => { t.style.opacity = '0'; t.style.transition = 'opacity 0.3s'; setTimeout(() => t.remove(), 300); }, 3000);
}

function showModal(title, content, size = 'md') {
  const sizes = { sm: 'max-w-md', md: 'max-w-2xl', lg: 'max-w-4xl', xl: 'max-w-6xl' };
  const id = 'modal-' + Date.now();
  const overlay = document.createElement('div');
  overlay.id = id;
  overlay.className = 'modal-overlay fade-in';
  overlay.innerHTML = `<div class="modal-content ${sizes[size]} w-full mx-4 p-0">
    <div class="flex items-center justify-between p-5 border-b border-gray-100 no-print">
      <h3 class="text-lg font-bold text-gray-800">${title}</h3>
      <button onclick="closeModal('${id}')" class="w-8 h-8 rounded-lg bg-gray-100 hover:bg-gray-200 flex items-center justify-center transition-colors"><i class="fas fa-times text-gray-500"></i></button>
    </div>
    <div class="p-5">${content}</div>
  </div>`;
  overlay.addEventListener('click', (e) => { if (e.target === overlay) closeModal(id); });
  document.body.appendChild(overlay);
  setTimeout(() => initDatePickers(), 100);
  return id;
}
function closeModal(id) { const m = document.getElementById(id); if (m) { m.style.opacity = '0'; m.style.transition = 'opacity 0.2s'; setTimeout(() => m.remove(), 200); } }
function closeAllModals() { $$('.modal-overlay').forEach(m => m.remove()); }

function initDatePickers() {
  // IMPORTANT: flatpickr's altInput clone inherits the original element's CSS
  // classes (including 'date-picker'), but is never tagged 'flatpickr-input'.
  // Since this function is called more than once per modal (callers invoke it
  // explicitly AND showModal() schedules its own setTimeout call), a naive
  // `.date-picker:not(.flatpickr-input)` selector will match that altInput on
  // the second pass and re-initialize flatpickr ON TOP OF IT, silently
  // corrupting the real date value (e.g. a selected "2026-11-11" would get
  // reparsed from the altInput's human-readable "Nov 11, 2026" text and come
  // out as a nonsense date like "2026-01-01"). Guard against both the
  // re-entrant call AND the altInput class leak.
  $$('.date-picker:not(.flatpickr-input)').forEach(el => {
    if (el._flatpickr) return; // already initialized - never re-process
    const existingVal = el.value;
    const fp = flatpickr(el, {
      dateFormat: 'Y-m-d',
      altInput: true,
      altFormat: 'M j, Y',
      disableMobile: true,
      defaultDate: existingVal || null,
      allowInput: false
    });
    // Ensure the value is properly set if there was an existing value
    if (existingVal) {
      fp.setDate(existingVal, true, 'Y-m-d');
    }
    // Strip the leaked 'date-picker' class from the generated altInput so it
    // can never be matched (and re-initialized) by a future call, regardless
    // of the _flatpickr guard above.
    if (fp.altInput) fp.altInput.classList.remove('date-picker');
  });
}

function confirmAction(msg) {
  return new Promise(resolve => {
    const id = showModal('Confirm', `<div class="text-center py-4">
      <div class="w-16 h-16 rounded-full bg-orange-100 flex items-center justify-center mx-auto mb-4"><i class="fas fa-exclamation-triangle text-2xl text-orange-500"></i></div>
      <p class="text-gray-600 mb-6">${msg}</p>
      <div class="flex gap-3 justify-center">
        <button onclick="closeModal('${id}'); window._cr(false)" class="btn btn-outline">Cancel</button>
        <button onclick="closeModal('${id}'); window._cr(true)" class="btn btn-danger">Confirm</button>
      </div></div>`, 'sm');
    window._cr = resolve;
  });
}

// ==================== PDF ====================
function generatePDF(title, headers, rows, opts = {}) {
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF(opts.orientation || 'p', 'mm', 'a4');
  doc.setFillColor(108, 99, 255); doc.rect(0, 0, 220, 35, 'F');
  doc.setTextColor(255); doc.setFontSize(20); doc.setFont('helvetica', 'bold');
  doc.text('PCH PMS', 14, 16); doc.setFontSize(10); doc.setFont('helvetica', 'normal');
  doc.text(APP.hotelName + ' - ' + APP.hotelCity, 14, 23);
  doc.text(`Generated: ${fullDate()}`, 220 - 14, 16, { align: 'right' });
  if (opts.dateRange) doc.text(opts.dateRange, 220 - 14, 23, { align: 'right' });
  doc.setTextColor(50); doc.setFontSize(16); doc.setFont('helvetica', 'bold');
  doc.text(title, 14, 48);
  if (opts.summary) { doc.setFontSize(10); doc.setFont('helvetica', 'normal'); doc.setTextColor(100); doc.text(opts.summary, 14, 56); }
  doc.autoTable({ head: [headers], body: rows, startY: opts.summary ? 62 : 54, styles: { fontSize: 9, cellPadding: 4 }, headStyles: { fillColor: [108, 99, 255] }, alternateRowStyles: { fillColor: [248, 248, 255] }, margin: { left: 14, right: 14 } });
  const pc = doc.internal.getNumberOfPages();
  for (let i = 1; i <= pc; i++) { doc.setPage(i); doc.setFontSize(8); doc.setTextColor(150); doc.text(`Page ${i}/${pc}`, doc.internal.pageSize.width / 2, doc.internal.pageSize.height - 10, { align: 'center' }); }
  doc.save(`${title.replace(/\s+/g, '_')}_${today()}.pdf`);
  showToast('PDF downloaded!');
}

// ==================== CSV ====================
function csvEscape(v) {
  if (v === null || v === undefined) return '';
  const s = String(v);
  if (/[",\n\r]/.test(s)) return '"' + s.replace(/"/g, '""') + '"';
  return s;
}
function generateCSV(title, headers, rows) {
  const lines = [headers.map(csvEscape).join(',')];
  rows.forEach(r => lines.push(r.map(csvEscape).join(',')));
  const csv = '\uFEFF' + lines.join('\r\n');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = `${title.replace(/\s+/g, '_')}_${today()}.csv`;
  document.body.appendChild(a); a.click(); a.remove();
  URL.revokeObjectURL(url);
  showToast('CSV downloaded!');
}
// Renders a PDF + CSV export button pair for use in page toolbars
function exportBtns(pdfFn, csvFn) {
  return `<button onclick="${pdfFn}()" class="btn btn-outline btn-sm"><i class="fas fa-file-pdf"></i> PDF</button>
    <button onclick="${csvFn}()" class="btn btn-outline btn-sm"><i class="fas fa-file-csv"></i> CSV</button>`;
}

function hasPermission(perm) {
  if (!APP.user) return false;
  const perms = typeof APP.user.permissions === 'string' ? JSON.parse(APP.user.permissions) : APP.user.permissions;
  if (perms.all) return true;
  if (APP.user.role === 'super_admin' || APP.user.role === 'admin' || APP.user.role === 'manager') return true;
  return !!perms[perm];
}

function isSuperAdmin() { return APP.user?.role === 'super_admin'; }
function isHotelAdmin() { return APP.user?.role === 'admin' || APP.user?.role === 'manager'; }
function isReceptionist() { return APP.user?.role === 'receptionist'; }
function isHousekeeping() { return APP.user?.role === 'housekeeping'; }

// ==================== AUTH ====================
const LOGIN_FEATURES = [
  { icon: 'fa-calendar-days', title: 'Reservation Calendar', desc: 'Day, week &amp; month room-by-room availability grid' },
  { icon: 'fa-tower-broadcast', title: 'Channel Manager', desc: 'Sync Booking.com, Airbnb, Expedia &amp; more in real time' },
  { icon: 'fa-satellite-dish', title: 'Per-Room iCal Sync', desc: 'Every room gets its own import/export calendar feed' },
  { icon: 'fa-shield-halved', title: 'Role-Based Access', desc: 'Super Admin, property types, staff roles &amp; permissions' },
];

async function renderLogin() {
  let licenseBanner = '';
  try {
    const lic = await api('/license/status');
    if (lic.status === 'trial' && lic.remaining_days !== null) {
      const urgent = lic.remaining_days <= 3;
      licenseBanner = `<div class="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium mb-5 ${urgent ? 'bg-red-500/15 text-red-100 border border-red-400/30' : 'bg-white/10 text-white/90 border border-white/15'}">
        <i class="fas fa-clock"></i> Trial: <b>${Math.max(lic.remaining_days, 0)} day${lic.remaining_days===1?'':'s'}</b> remaining — activate a license key anytime from the Super Admin panel.
      </div>`;
    } else if (lic.status === 'expired') {
      licenseBanner = `<div class="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium mb-5 bg-red-500/20 text-red-50 border border-red-400/40">
        <i class="fas fa-triangle-exclamation"></i> License expired. Sign in as Super Admin to activate a license key.
      </div>`;
    }
  } catch (e) { /* license endpoint optional, ignore if unreachable */ }

  $('#app').innerHTML = `
    <div class="min-h-screen flex" style="background:#0f0a2e">
      <div class="hidden lg:flex lg:w-1/2 relative overflow-hidden items-center justify-center p-12" style="background: linear-gradient(135deg, #1a1145 0%, #2d1f6e 55%, #6C63FF 100%);">
        <div class="absolute inset-0 opacity-20" style="background-image: radial-gradient(circle at 20% 20%, white 1px, transparent 1px), radial-gradient(circle at 80% 60%, white 1px, transparent 1px); background-size: 60px 60px, 90px 90px;"></div>
        <div class="relative z-10 max-w-md">
          <div class="flex items-center gap-3 mb-8">
            <div class="w-14 h-14 bg-white/15 rounded-2xl flex items-center justify-center backdrop-blur-sm"><i class="fas fa-hotel text-3xl text-white"></i></div>
            <div><h1 class="text-2xl font-extrabold text-white leading-tight">PCH PMS</h1><p class="text-white/50 text-xs tracking-widest uppercase">Property Management System</p></div>
          </div>
          ${licenseBanner}
          <h2 class="text-3xl font-bold text-white leading-tight mb-3">Run every property<br>from one dashboard.</h2>
          <p class="text-white/60 text-sm mb-8">Reservations, housekeeping, billing, channel sync and multi-property administration — built for hotels, apartments, guesthouses &amp; resorts.</p>
          <div class="space-y-4">
            ${LOGIN_FEATURES.map(f => `<div class="flex items-start gap-3">
              <div class="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center flex-shrink-0 mt-0.5"><i class="fas ${f.icon} text-white text-sm"></i></div>
              <div><p class="text-white font-semibold text-sm">${f.title}</p><p class="text-white/50 text-xs">${f.desc}</p></div>
            </div>`).join('')}
          </div>
        </div>
      </div>
      <div class="flex-1 flex items-center justify-center p-6 bg-gray-50">
        <div class="w-full max-w-md">
          <div class="lg:hidden text-center mb-6">
            <div class="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center mx-auto mb-3"><i class="fas fa-hotel text-3xl text-primary"></i></div>
            <h1 class="text-2xl font-extrabold text-gray-800">PCH PMS</h1>
            ${licenseBanner ? `<div class="mt-4 text-left">${licenseBanner.replace(/text-white\/90|text-white\/50|text-red-100|text-red-50/g,'text-gray-700').replace(/bg-white\/10|border-white\/15/g,'bg-gray-100 border-gray-200')}</div>` : ''}
          </div>
          <div class="bg-white rounded-2xl shadow-2xl p-8 border border-gray-100">
            <h2 class="text-xl font-bold text-gray-800 mb-1">Welcome Back</h2>
            <p class="text-gray-500 text-sm mb-6">Sign in to your account</p>
            <div id="login-error" class="hidden bg-red-50 text-red-600 p-3 rounded-xl text-sm mb-4 flex items-center gap-2"><i class="fas fa-exclamation-circle"></i><span></span></div>
            <div class="space-y-4">
              <div><label class="block text-sm font-medium text-gray-700 mb-1.5">Username</label>
                <div class="relative"><i class="fas fa-user absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400 text-sm"></i>
                <input id="login-user" type="text" class="input-field pl-10" placeholder="Enter username" value="superadmin"></div></div>
              <div><label class="block text-sm font-medium text-gray-700 mb-1.5">Password</label>
                <div class="relative"><i class="fas fa-lock absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400 text-sm"></i>
                <input id="login-pass" type="password" class="input-field pl-10 pr-10" placeholder="Enter password" value="super123">
                <button type="button" tabindex="-1" onclick="const i=$('#login-pass');i.type=i.type==='password'?'text':'password';this.querySelector('i').className='fas '+(i.type==='password'?'fa-eye':'fa-eye-slash')" class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"><i class="fas fa-eye"></i></button></div></div>
              <button onclick="doLogin()" id="login-btn" class="btn btn-primary w-full justify-center py-3 text-base"><i class="fas fa-sign-in-alt"></i> Sign In</button>
            </div>
            <div class="mt-6 p-4 bg-gray-50 rounded-xl border border-gray-100">
              <p class="text-xs text-gray-500 font-semibold mb-2 flex items-center gap-1.5"><i class="fas fa-flask text-primary"></i> Demo Accounts</p>
              <div class="grid grid-cols-1 gap-1.5 text-xs text-gray-600">
                <button type="button" onclick="fillLogin('superadmin','super123')" class="text-left hover:text-primary"><b>Super Admin:</b> superadmin / super123</button>
                <button type="button" onclick="fillLogin('admin1','admin123')" class="text-left hover:text-primary"><b>Hotel Admin (Lagos):</b> admin1 / admin123</button>
                <button type="button" onclick="fillLogin('linda','linda123')" class="text-left hover:text-primary"><b>Receptionist (Lagos):</b> linda / linda123</button>
                <button type="button" onclick="fillLogin('tunde','tunde123')" class="text-left hover:text-primary"><b>Housekeeping (Lagos):</b> tunde / tunde123</button>
                <button type="button" onclick="fillLogin('admin2','admin123')" class="text-left hover:text-primary"><b>Hotel Admin (Abuja):</b> admin2 / admin123</button>
              </div>
            </div>
          </div>
          <p class="text-center text-gray-400 text-xs mt-6">© ${new Date().getFullYear()} PCH PMS · Property Management System</p>
        </div>
      </div>
    </div>`;
  $('#login-pass').addEventListener('keypress', (e) => { if (e.key === 'Enter') doLogin(); });
  $('#login-user').addEventListener('keypress', (e) => { if (e.key === 'Enter') doLogin(); });
}
function fillLogin(user, pass) { $('#login-user').value = user; $('#login-pass').value = pass; }

async function doLogin() {
  const btn = $('#login-btn');
  btn.disabled = true; btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Signing in...';
  try {
    const d = await post('/auth/login', { username: $('#login-user').value, password: $('#login-pass').value });
    APP.user = d.user;
    localStorage.setItem('ps_user', JSON.stringify(d.user));
    
    if (d.user.role === 'super_admin') {
      APP.hotels = d.hotels || [];
      localStorage.setItem('ps_hotels', JSON.stringify(APP.hotels));
      if (d.hotels.length > 0) {
        // Show hotel selector
        showHotelSelector(d.hotels);
        return;
      }
    } else {
      APP.hotelId = d.user.hotel_id;
      APP.hotelName = d.user.hotel_name;
      APP.hotelCity = d.user.hotel_city;
      APP.currency = d.user.hotel_currency || '₦';
      localStorage.setItem('ps_hotel_id', APP.hotelId);
      localStorage.setItem('ps_hotel_name', APP.hotelName);
      localStorage.setItem('ps_hotel_city', APP.hotelCity);
      localStorage.setItem('ps_currency', APP.currency);
    }
    showToast(`Welcome back, ${d.user.full_name}!`);
    renderApp();
  } catch (e) {
    const err = $('#login-error');
    if (err) { err.classList.remove('hidden'); err.querySelector('span').textContent = 'Invalid username or password'; }
    btn.disabled = false; btn.innerHTML = '<i class="fas fa-sign-in-alt"></i> Sign In';
  }
}

function showHotelSelector(hotels) {
  $('#app').innerHTML = `
    <div class="min-h-screen flex items-center justify-center" style="background: linear-gradient(135deg, #1a1145 0%, #2d1f6e 50%, #6C63FF 100%);">
      <div class="w-full max-w-lg mx-4">
        <div class="text-center mb-8">
          <div class="w-20 h-20 bg-white/20 rounded-2xl flex items-center justify-center mx-auto mb-4"><i class="fas fa-hotel text-4xl text-white"></i></div>
          <h1 class="text-3xl font-extrabold text-white">PCH PMS</h1>
          <p class="text-white/60 text-sm mt-1">Select a hotel to manage</p>
        </div>
        <div class="bg-white rounded-2xl shadow-2xl p-8">
          <h2 class="text-lg font-bold text-gray-800 mb-4">Welcome, ${APP.user.full_name}</h2>
          <div class="space-y-3">
            ${hotels.map(h => `<button onclick="selectHotel(${h.id}, '${esc(h.name)}', '${esc(h.city+', '+h.country)}', '${h.currency||'₦'}')" class="w-full text-left p-4 bg-gray-50 rounded-xl hover:bg-primary/5 hover:border-primary border-2 border-transparent transition-all">
              <div class="flex items-center gap-3">
                <div class="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center"><i class="fas fa-building text-primary text-lg"></i></div>
                <div><p class="font-bold text-gray-800">${h.name}</p><p class="text-sm text-gray-500">${h.city}, ${h.country} · ${h.room_count||0} rooms</p></div>
              </div>
            </button>`).join('')}
            <button onclick="selectHotel(null, 'PCH PMS HQ', 'All Hotels', '₦')" class="w-full text-left p-4 bg-purple-50 rounded-xl hover:bg-purple-100 border-2 border-transparent transition-all">
              <div class="flex items-center gap-3">
                <div class="w-12 h-12 rounded-xl bg-purple-200 flex items-center justify-center"><i class="fas fa-globe text-purple-600 text-lg"></i></div>
                <div><p class="font-bold text-gray-800">Super Admin Panel</p><p class="text-sm text-gray-500">Manage all hotels</p></div>
              </div>
            </button>
          </div>
        </div>
      </div>
    </div>`;
}

function selectHotel(id, name, city, currency) {
  APP.hotelId = id;
  APP.hotelName = name;
  APP.hotelCity = city;
  APP.currency = currency;
  localStorage.setItem('ps_hotel_id', id || '');
  localStorage.setItem('ps_hotel_name', name);
  localStorage.setItem('ps_hotel_city', city);
  localStorage.setItem('ps_currency', currency);
  showToast(`Managing: ${name}`);
  APP.currentPage = id ? 'dashboard' : 'hotels';
  renderApp();
}

function logout() {
  APP.user = null; APP.hotelId = null; APP.hotels = [];
  localStorage.removeItem('ps_user'); localStorage.removeItem('ps_hotel_id');
  localStorage.removeItem('ps_hotels'); localStorage.removeItem('ps_hotel_name');
  localStorage.removeItem('ps_hotel_city'); localStorage.removeItem('ps_currency');
  renderLogin();
}

function switchHotel() {
  if (isSuperAdmin() && APP.hotels.length > 0) showHotelSelector(APP.hotels);
}

// ==================== NAV (grouped for easy navigation) ====================
function getNavGroups() {
  if (isSuperAdmin() && !APP.hotelId) {
    return [
      { label: 'Platform', items: [
        { id: 'hotels', icon: 'fa-building', label: 'Hotels' },
        { id: 'staff', icon: 'fa-user-tie', label: 'All Staff' },
        { id: 'superadmin', icon: 'fa-shield-halved', label: 'Property Types & Roles' },
        { id: 'license', icon: 'fa-key', label: 'License' },
        { id: 'backup', icon: 'fa-database', label: 'Backup & Export' },
      ]}
    ];
  }
  if (isHousekeeping()) {
    return [{ label: 'My Work', items: [{ id: 'housekeeping', icon: 'fa-broom', label: 'Housekeeping' }] }];
  }
  const groups = [
    { label: 'Overview', items: [
      { id: 'dashboard', icon: 'fa-th-large', label: 'Dashboard' },
    ]},
    { label: 'Front Desk', items: [
      { id: 'reservations', icon: 'fa-calendar-check', label: 'Reservations' },
      { id: 'calendar', icon: 'fa-calendar-days', label: 'Calendar' },
      { id: 'arrivals', icon: 'fa-plane-arrival', label: 'Arrivals' },
      { id: 'inhouse', icon: 'fa-door-open', label: 'In-House' },
      { id: 'walkin', icon: 'fa-walking', label: 'Walk-in Check-in' },
    ]},
    { label: 'Guests', items: [
      { id: 'guests', icon: 'fa-users', label: 'Guests' },
      { id: 'loyalty', icon: 'fa-award', label: 'Loyalty' },
      { id: 'messaging', icon: 'fa-comments', label: 'Messages' },
    ]},
    { label: 'Property', items: [
      { id: 'rooms', icon: 'fa-bed', label: 'Rooms & Units' },
      { id: 'housekeeping', icon: 'fa-broom', label: 'Housekeeping' },
      { id: 'teams', icon: 'fa-people-group', label: 'Teams' },
      { id: 'channels', icon: 'fa-tower-broadcast', label: 'Channel Manager' },
    ]},
    { label: 'Revenue', items: [
      { id: 'payments', icon: 'fa-credit-card', label: 'Payments' },
      { id: 'invoices', icon: 'fa-file-invoice-dollar', label: 'Invoices' },
      { id: 'pos', icon: 'fa-cash-register', label: 'POS' },
      ...(hasPermission('reports') || isHotelAdmin() ? [{ id: 'reports', icon: 'fa-chart-bar', label: 'Reports' }] : []),
    ]},
    { label: 'Operations', items: [
      { id: 'shifts', icon: 'fa-clock', label: 'Shifts' },
    ]},
  ];
  if (isHotelAdmin() || isSuperAdmin()) {
    groups.push({ label: 'Administration', items: [
      { id: 'staff', icon: 'fa-user-tie', label: 'Staff' },
      { id: 'settings', icon: 'fa-cog', label: 'Settings' },
    ]});
  }
  return groups;
}
function getNavItems() { return getNavGroups().flatMap(g => g.items); }

// ==================== MAIN APP ====================
function renderApp() {
  if (!APP.user) { renderLogin(); return; }
  const navGroups = getNavGroups();
  const initials = APP.user.full_name.split(' ').map(n => n[0]).join('');
  
  $('#app').innerHTML = `<div class="flex h-screen overflow-hidden main-flex-wrap">
    <div id="mobile-overlay" class="mobile-overlay" onclick="toggleSidebar(false)"></div>
    <aside id="sidebar" class="w-[240px] min-w-[240px] h-full flex flex-col no-print" style="background: linear-gradient(180deg, #1a1145 0%, #0f0a2e 100%);">
      <div class="p-5 flex items-center gap-3 cursor-pointer" onclick="switchHotel()">
        <div class="w-10 h-10 bg-white/15 rounded-xl flex items-center justify-center"><i class="fas fa-hotel text-xl text-white"></i></div>
        <div class="flex-1 min-w-0"><h1 class="text-white font-bold text-lg leading-tight truncate">PCH PMS</h1><p class="text-white/40 text-[10px] tracking-wider uppercase">Multi-Property PMS</p></div>
        <button onclick="event.stopPropagation();toggleSidebar(false)" class="md:hidden w-8 h-8 rounded-lg bg-white/10 flex items-center justify-center text-white"><i class="fas fa-times"></i></button>
      </div>
      <nav class="flex-1 py-1 overflow-y-auto">
        ${navGroups.map(g => `<div class="nav-group-label">${g.label}</div>
        ${g.items.map(n => `<button onclick="navigate('${n.id}')" class="sidebar-item w-full flex items-center gap-3 px-4 py-2.5 text-left ${APP.currentPage === n.id ? 'active' : ''}">
          <i class="fas ${n.icon} w-5 text-center ${APP.currentPage === n.id ? 'text-white' : 'text-white/50'}"></i>
          <span class="${APP.currentPage === n.id ? 'text-white font-semibold' : 'text-white/70'} text-sm">${n.label}</span>
          ${n.id === 'messaging' ? '<span id="msg-badge-nav" class="ml-auto"></span>' : ''}
        </button>`).join('')}`).join('')}
      </nav>
      <div class="p-4 m-3 rounded-xl bg-white/5 border border-white/10">
        <div class="flex items-center gap-3">
          <div class="w-10 h-10 rounded-xl bg-primary/30 flex items-center justify-center"><i class="fas fa-building text-primary-200 text-sm"></i></div>
          <div class="flex-1 min-w-0"><p class="text-white text-sm font-medium truncate">${APP.hotelName}</p><p class="text-white/40 text-xs">${APP.hotelCity}</p></div>
        </div>
        <div id="sync-status" class="mt-3 pt-3 border-t border-white/10"></div>
      </div>
      <button id="pwa-install-btn" onclick="installPWA()" class="hidden mx-3 mb-3 px-4 py-2.5 rounded-xl bg-gradient-to-r from-primary to-purple-500 text-white text-sm font-semibold flex items-center gap-2 hover:from-primary/90 hover:to-purple-500/90 transition-all">
        <i class="fas fa-download"></i> Install PCH PMS
      </button>
    </aside>
    <div class="flex-1 flex flex-col overflow-hidden">
      <header class="app-header h-16 bg-white border-b border-gray-100 flex items-center px-6 gap-4 flex-shrink-0 no-print">
        <button id="sidebar-toggle-btn" onclick="toggleSidebar(true)" class="w-10 h-10 rounded-xl bg-gray-50 items-center justify-center hover:bg-gray-100"><i class="fas fa-bars text-gray-600"></i></button>
        <div class="flex-1"></div>
        <div class="flex items-center gap-2 ml-auto">
          <div class="hidden md:flex items-center gap-2 px-3 py-2 bg-gray-50 rounded-xl">
            <i class="fas fa-calendar text-primary text-sm"></i>
            <div class="text-right"><p class="text-sm font-semibold text-gray-800">${fullDate()}</p></div>
          </div>
          <div class="relative">
            <button onclick="navigate('messaging')" class="w-10 h-10 rounded-xl bg-gray-50 flex items-center justify-center hover:bg-gray-100"><i class="fas fa-bell text-gray-500"></i></button>
            <span id="msg-badge-header" class="notification-badge hidden">0</span>
          </div>
          <div class="flex items-center gap-3 pl-3 ml-1 border-l border-gray-100 cursor-pointer" onclick="showProfileMenu()">
            <div class="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center"><span class="text-primary font-bold text-sm">${initials}</span></div>
            <div class="hidden md:block"><p class="text-sm font-semibold text-gray-800">${APP.user.full_name}</p><p class="text-[10px] text-gray-500 capitalize">${APP.user.role.replace('_',' ')}</p></div>
          </div>
        </div>
      </header>
      <main id="main-content" class="flex-1 overflow-y-auto p-6 bg-gray-50"></main>
    </div>
  </div>`;
  
  navigate(APP.currentPage);
  loadUnreadCount();
  // Update PWA/offline status indicators
  setTimeout(() => {
    updateSyncStatusUI();
    if (deferredInstallPrompt) showInstallButton();
    updateOnlineStatus();
  }, 200);
}

function toggleSidebar(open) {
  const sb = $('#sidebar'); const ov = $('#mobile-overlay');
  if (!sb) return;
  if (open) { sb.classList.add('mobile-open'); ov?.classList.add('show'); }
  else { sb.classList.remove('mobile-open'); ov?.classList.remove('show'); }
}

function navigate(page) {
  APP.currentPage = page;
  $$('.sidebar-item').forEach(el => {
    const isActive = el.onclick?.toString().includes(`'${page}'`);
    el.classList.toggle('active', isActive);
    const i = el.querySelector('i'); const s = el.querySelector('span');
    if (i) { i.classList.toggle('text-white', isActive); i.classList.toggle('text-white/50', !isActive); }
    if (s) { s.classList.toggle('text-white', isActive); s.classList.toggle('font-semibold', isActive); s.classList.toggle('text-white/70', !isActive); }
  });
  const pages = { dashboard: renderDashboard, reservations: renderReservations, arrivals: renderArrivals, inhouse: renderInHouse, walkin: renderWalkin, guests: renderGuests, rooms: renderRooms, housekeeping: renderHousekeeping, payments: renderPayments, invoices: renderInvoices, pos: renderPOS, reports: renderReports, shifts: renderShifts, staff: renderStaff, settings: renderSettings, hotels: renderHotels, messaging: renderMessaging, loyalty: renderLoyalty, calendar: renderCalendarPage, channels: renderChannelsPage, teams: renderTeamsPage, superadmin: renderSuperAdminPage, backup: renderBackupPage, license: renderLicensePage };
  const mc = $('#main-content');
  if (mc && pages[page]) {
    mc.innerHTML = '<div class="flex items-center justify-center h-64"><div class="animate-spin w-10 h-10 border-4 border-primary border-t-transparent rounded-full"></div></div>';
    pages[page]();
  }
  // Close mobile sidebar after navigating
  toggleSidebar(false);
}

async function loadUnreadCount() {
  if (!APP.hotelId || !APP.user) return;
  try {
    const r = await api(`/messages/unread?user_id=${APP.user.id}`);
    APP.unreadMessages = r.count || 0;
    const hdr = $('#msg-badge-header');
    const nav = $('#msg-badge-nav');
    if (hdr) { if (APP.unreadMessages > 0) { hdr.classList.remove('hidden'); hdr.textContent = APP.unreadMessages; } else { hdr.classList.add('hidden'); } }
    if (nav && APP.unreadMessages > 0) { nav.innerHTML = `<span class="bg-red-500 text-white text-[10px] px-1.5 py-0.5 rounded-full">${APP.unreadMessages}</span>`; }
  } catch(e) {}
}

function showProfileMenu() {
  showModal('Profile', `<div class="space-y-4">
    <div class="flex items-center gap-4 p-4 bg-gray-50 rounded-xl">
      <div class="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center"><span class="text-primary font-bold text-2xl">${APP.user.full_name.split(' ').map(n=>n[0]).join('')}</span></div>
      <div><h3 class="text-lg font-bold">${APP.user.full_name}</h3><p class="text-gray-500 capitalize">${APP.user.role.replace('_',' ')}</p><p class="text-gray-400 text-sm">${APP.hotelName}</p></div>
    </div>
    <button onclick="showChangePassword()" class="w-full text-left px-4 py-3 rounded-xl hover:bg-gray-50 flex items-center gap-3"><i class="fas fa-key text-gray-400 w-5"></i><span class="text-sm">Change Password</span></button>
    ${isSuperAdmin() ? `<button onclick="closeAllModals(); switchHotel()" class="w-full text-left px-4 py-3 rounded-xl hover:bg-gray-50 flex items-center gap-3"><i class="fas fa-exchange-alt text-gray-400 w-5"></i><span class="text-sm">Switch Hotel</span></button>` : ''}
    <button onclick="closeAllModals(); logout()" class="w-full text-left px-4 py-3 rounded-xl hover:bg-red-50 text-red-500 flex items-center gap-3"><i class="fas fa-sign-out-alt w-5"></i><span class="text-sm font-medium">Sign Out</span></button>
  </div>`, 'sm');
}

function showChangePassword() {
  closeAllModals();
  showModal('Change Password', `<div class="space-y-4">
    <div><label class="block text-sm font-medium text-gray-700 mb-1">Current Password</label><input type="password" id="cp-current" class="input-field"></div>
    <div><label class="block text-sm font-medium text-gray-700 mb-1">New Password</label><input type="password" id="cp-new" class="input-field"></div>
    <div><label class="block text-sm font-medium text-gray-700 mb-1">Confirm Password</label><input type="password" id="cp-confirm" class="input-field"></div>
    <button onclick="doChangePassword()" class="btn btn-primary w-full justify-center">Update Password</button>
  </div>`, 'sm');
}

async function doChangePassword() {
  const np = $('#cp-new').value;
  if (np !== $('#cp-confirm').value) return showToast('Passwords do not match', 'error');
  if (np.length < 4) return showToast('Password too short', 'error');
  await put('/auth/change-password', { user_id: APP.user.id, current_password: $('#cp-current').value, new_password: np });
  closeAllModals(); showToast('Password updated');
}

// ==================== SUPER ADMIN: HOTELS ====================
async function renderHotels() {
  const hotels = await api('/hotels');
  const mc = $('#main-content');
  mc.innerHTML = `<div class="fade-in">
    <div class="flex items-center justify-between mb-6">
      <div><h2 class="text-2xl font-bold text-gray-800">Hotels</h2><p class="text-gray-500 text-sm">Manage all hotel properties</p></div>
      <button onclick="showAddHotel()" class="btn btn-primary"><i class="fas fa-plus"></i> Add Hotel</button>
    </div>
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      ${hotels.map(h => `<div class="card p-6">
        <div class="flex items-center gap-3 mb-4">
          <div class="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center"><i class="fas fa-building text-primary text-xl"></i></div>
          <div class="flex-1 min-w-0"><h3 class="font-bold text-lg truncate">${h.name}</h3><p class="text-gray-500 text-sm">${h.city}, ${h.country}</p></div>
          <span class="badge badge-primary flex-shrink-0" title="Property ID">ID #${h.id}</span>
        </div>
        <div class="grid grid-cols-2 gap-3 mb-4">
          <div class="p-3 bg-gray-50 rounded-lg"><p class="text-xs text-gray-500">Rooms</p><p class="font-bold">${h.room_count||0}</p></div>
          <div class="p-3 bg-gray-50 rounded-lg"><p class="text-xs text-gray-500">Staff</p><p class="font-bold">${h.staff_count||0}</p></div>
        </div>
        <div class="flex gap-2">
          <button onclick="selectHotel(${h.id}, '${esc(h.name)}', '${esc(h.city+', '+h.country)}', '${h.currency||'₦'}')" class="btn btn-primary btn-sm flex-1 justify-center"><i class="fas fa-sign-in-alt"></i> Manage</button>
          <button onclick="showEditHotel(${h.id})" class="btn btn-outline btn-sm"><i class="fas fa-edit"></i></button>
          <button onclick="deleteHotel(${h.id})" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></button>
        </div>
      </div>`).join('')}
    </div>
  </div>`;
}

function showAddHotel() {
  showModal('Add Hotel', `<div class="space-y-4">
    <div class="grid grid-cols-2 gap-4">
      <div><label class="block text-sm font-medium text-gray-700 mb-1">Hotel Name *</label><input id="ah-name" class="input-field"></div>
      <div><label class="block text-sm font-medium text-gray-700 mb-1">Code *</label><input id="ah-code" class="input-field" placeholder="e.g. PSL"></div>
      <div><label class="block text-sm font-medium text-gray-700 mb-1">Address</label><input id="ah-addr" class="input-field"></div>
      <div><label class="block text-sm font-medium text-gray-700 mb-1">City</label><input id="ah-city" class="input-field"></div>
      <div><label class="block text-sm font-medium text-gray-700 mb-1">Country</label><input id="ah-country" class="input-field" value="Nigeria"></div>
      <div><label class="block text-sm font-medium text-gray-700 mb-1">Phone</label><input id="ah-phone" class="input-field"></div>
      <div><label class="block text-sm font-medium text-gray-700 mb-1">Email</label><input id="ah-email" class="input-field"></div>
      <div><label class="block text-sm font-medium text-gray-700 mb-1">Currency</label><input id="ah-cur" class="input-field" value="₦"></div>
    </div>
    <button onclick="createHotel()" class="btn btn-primary w-full justify-center">Create Hotel</button>
  </div>`, 'lg');
}

async function createHotel() {
  const name = $('#ah-name').value; if (!name) return showToast('Name required', 'error');
  await post('/hotels', { name, code: $('#ah-code').value, address: $('#ah-addr').value, city: $('#ah-city').value, country: $('#ah-country').value, phone: $('#ah-phone').value, email: $('#ah-email').value, currency: $('#ah-cur').value });
  closeAllModals(); showToast('Hotel created!');
  const h = await api('/hotels'); APP.hotels = h; localStorage.setItem('ps_hotels', JSON.stringify(h));
  renderHotels();
}

async function showEditHotel(id) {
  const hotels = await api('/hotels');
  const h = hotels.find(x => x.id === id); if (!h) return;
  showModal('Edit Hotel', `<div class="space-y-4">
    <div class="grid grid-cols-2 gap-4">
      <div><label class="block text-sm font-medium text-gray-700 mb-1">Name</label><input id="eh-name" class="input-field" value="${h.name}"></div>
      <div><label class="block text-sm font-medium text-gray-700 mb-1">Code</label><input id="eh-code" class="input-field" value="${h.code}"></div>
      <div><label class="block text-sm font-medium text-gray-700 mb-1">Address</label><input id="eh-addr" class="input-field" value="${h.address||''}"></div>
      <div><label class="block text-sm font-medium text-gray-700 mb-1">City</label><input id="eh-city" class="input-field" value="${h.city||''}"></div>
      <div><label class="block text-sm font-medium text-gray-700 mb-1">Country</label><input id="eh-country" class="input-field" value="${h.country||''}"></div>
      <div><label class="block text-sm font-medium text-gray-700 mb-1">Phone</label><input id="eh-phone" class="input-field" value="${h.phone||''}"></div>
      <div><label class="block text-sm font-medium text-gray-700 mb-1">Email</label><input id="eh-email" class="input-field" value="${h.email||''}"></div>
      <div><label class="block text-sm font-medium text-gray-700 mb-1">Currency</label><input id="eh-cur" class="input-field" value="${h.currency||'₦'}"></div>
    </div>
    <button onclick="updateHotel(${id})" class="btn btn-primary w-full justify-center">Update</button>
  </div>`, 'lg');
}

async function updateHotel(id) {
  await put(`/hotels/${id}`, { name: $('#eh-name').value, code: $('#eh-code').value, address: $('#eh-addr').value, city: $('#eh-city').value, country: $('#eh-country').value, phone: $('#eh-phone').value, email: $('#eh-email').value, currency: $('#eh-cur').value });
  closeAllModals(); showToast('Hotel updated!');
  const h = await api('/hotels'); APP.hotels = h; localStorage.setItem('ps_hotels', JSON.stringify(h)); renderHotels();
}

async function deleteHotel(id) {
  if (!await confirmAction('Delete this hotel?')) return;
  await del(`/hotels/${id}`); showToast('Hotel deleted'); renderHotels();
}

// ==================== DASHBOARD ====================
async function renderDashboard() {
  const d = await api('/dashboard');
  APP.data.dashboard = d;
  const mc = $('#main-content');
  const totalRooms = d.roomStats.total || 1;
  const occPct = Math.round((d.roomStats.occupied / totalRooms) * 100);
  const roomsByType = {};
  (d.rooms || []).forEach(r => { if (!roomsByType[r.type_name]) roomsByType[r.type_name] = { rooms: [], color: r.type_color }; roomsByType[r.type_name].rooms.push(r); });

  mc.innerHTML = `<div class="fade-in">
    <div class="mb-6 card p-5 flex flex-wrap items-center justify-between gap-4" style="background:linear-gradient(120deg,#6C63FF 0%,#564fcc 100%);border:none;">
      <div>
        <h2 class="text-2xl font-bold text-white">Welcome back, ${APP.user.full_name.split(' ')[0]}! <i class="fas fa-hand-sparkles ml-1"></i></h2>
        <p class="text-white/80 flex items-center gap-2 mt-1"><i class="fas fa-building"></i> ${APP.hotelName}${APP.hotelCity?', '+APP.hotelCity:''}</p>
      </div>
      <div class="text-right">
        <p id="dash-live-time" class="text-3xl font-extrabold text-white tabular-nums"></p>
        <p id="dash-live-date" class="text-white/70 text-sm"></p>
      </div>
    </div>
    <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-6">
      <div class="stat-card"><div class="w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center mb-3"><i class="fas fa-plane-arrival text-primary"></i></div><p class="text-2xl font-bold">${d.arrivals}</p><p class="text-xs text-gray-500">Arrivals Today</p><button onclick="navigate('arrivals')" class="text-xs text-primary font-medium mt-1">View →</button></div>
      <div class="stat-card"><div class="w-11 h-11 rounded-xl bg-green-50 flex items-center justify-center mb-3"><i class="fas fa-plane-departure text-success"></i></div><p class="text-2xl font-bold">${d.departures}</p><p class="text-xs text-gray-500">Departures</p></div>
      <div class="stat-card"><div class="w-11 h-11 rounded-xl bg-blue-50 flex items-center justify-center mb-3"><i class="fas fa-door-open text-info"></i></div><p class="text-2xl font-bold">${d.inhouse||0}</p><p class="text-xs text-gray-500">In-House</p><button onclick="navigate('inhouse')" class="text-xs text-info font-medium mt-1">View →</button></div>
      <div class="stat-card"><div class="w-11 h-11 rounded-xl bg-purple-50 flex items-center justify-center mb-3"><i class="fas fa-bed text-purple-500"></i></div><p class="text-2xl font-bold">${d.roomStats.occupied||0}</p><p class="text-xs text-gray-500">Occupied (${occPct}%)</p></div>
      <div class="stat-card"><div class="w-11 h-11 rounded-xl bg-yellow-50 flex items-center justify-center mb-3"><i class="fas fa-key text-warning"></i></div><p class="text-2xl font-bold">${d.roomStats.available||0}</p><p class="text-xs text-gray-500">Available</p></div>
      <div class="stat-card"><div class="w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center mb-3"><i class="fas fa-money-bill-wave text-primary"></i></div><p class="text-2xl font-bold">${fmt(d.revenue)}</p><p class="text-xs text-gray-500">Revenue Today</p></div>
    </div>
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <div class="lg:col-span-2 space-y-6">
        <div class="card p-5">
          <div class="flex items-center justify-between mb-4"><h3 class="font-bold text-gray-800">Room Overview</h3>
            <div class="flex items-center gap-4 text-xs"><span class="flex items-center gap-1.5"><span class="w-3 h-3 rounded-full bg-primary"></span>Occupied</span><span class="flex items-center gap-1.5"><span class="w-3 h-3 rounded-full bg-success"></span>Available</span><span class="flex items-center gap-1.5"><span class="w-3 h-3 rounded-full bg-warning"></span>Reserved</span><span class="flex items-center gap-1.5"><span class="w-3 h-3 rounded-full bg-gray-400"></span>Maintenance</span></div>
          </div>
          ${Object.entries(roomsByType).map(([type, data]) => `<div class="flex items-start gap-4 mb-3"><div class="w-28 flex-shrink-0 pt-1"><p class="font-semibold text-sm">${type}</p><p class="text-xs text-gray-400">(${data.rooms.length} rooms)</p></div><div class="flex flex-wrap gap-2">${data.rooms.map(r => `<button onclick="showRoomDetail(${r.id})" class="room-pill ${r.status}">${r.room_number}</button>`).join('')}</div></div>`).join('')}
        </div>
        <div class="card p-5">
          <div class="flex items-center justify-between mb-4"><h3 class="font-bold text-gray-800">Recent Reservations</h3><button onclick="navigate('reservations')" class="text-xs text-primary font-medium">View All →</button></div>
          <table class="w-full"><thead><tr class="text-left text-xs text-gray-500 border-b"><th class="pb-3">GUEST</th><th class="pb-3">ROOM</th><th class="pb-3">DATES</th><th class="pb-3">STATUS</th><th class="pb-3">PAYMENT</th></tr></thead>
          <tbody>${(d.recentReservations || []).map(r => `<tr class="table-row border-b border-gray-50 cursor-pointer" onclick="showReservationDetail(${r.id})">
            <td class="py-3 text-sm font-medium">${r.first_name} ${r.last_name}</td>
            <td class="py-3 text-sm text-gray-600">${r.room_number || '-'} (${r.room_type_name})</td>
            <td class="py-3 text-sm text-gray-600">${fmtDate(r.check_in_date)} - ${fmtDate(r.check_out_date)}</td>
            <td class="py-3"><span class="badge ${r.status==='checked-in'?'badge-success':r.status==='reserved'?'badge-warning':r.status==='checked-out'?'badge-info':'badge-danger'}">${r.status}</span></td>
            <td class="py-3"><span class="badge ${(r.paid_amount||0)>=r.total_amount?'badge-success':'badge-warning'}">${(r.paid_amount||0)>=r.total_amount?'PAID':'PENDING'}</span></td>
          </tr>`).join('')}</tbody></table>
        </div>
      </div>
      <div class="space-y-6">
        <div class="card p-5"><div class="flex items-center justify-between mb-4"><h3 class="font-bold">Schedule</h3></div>
          ${(d.schedule || []).map(s => `<div class="flex gap-3 mb-3"><div class="text-xs font-medium text-primary whitespace-nowrap pt-0.5">${fmtTime(s.event_time)}</div><div><p class="text-sm font-medium">${s.title}</p><p class="text-xs text-gray-500">${s.description}</p></div></div>`).join('')}
          ${(d.schedule||[]).length===0?'<p class="text-sm text-gray-400 text-center py-4">No events today</p>':''}
        </div>
        <div class="card p-5"><div class="flex items-center justify-between mb-4"><h3 class="font-bold">Current Shift</h3>
          ${d.currentShift?'<span class="badge badge-success">OPEN</span>':'<span class="badge badge-danger">NONE</span>'}</div>
          ${d.currentShift?`<div class="space-y-2 text-sm"><div class="flex justify-between"><span class="text-gray-500">Staff</span><span class="font-medium">${d.currentShift.user_name}</span></div><div class="flex justify-between"><span class="text-gray-500">Payments</span><span class="font-medium">${fmt(d.currentShift.total_payments)}</span></div><div class="flex justify-between border-t pt-2"><span class="text-gray-700 font-medium">Expected</span><span class="font-bold text-primary">${fmt(d.currentShift.expected_balance)}</span></div></div><button onclick="showCloseShift(${d.currentShift.id})" class="btn btn-primary w-full justify-center mt-4 btn-sm">Close Shift</button>`:`<p class="text-sm text-gray-400 text-center py-4">No active shift</p><button onclick="showOpenShift()" class="btn btn-success w-full justify-center mt-2 btn-sm">Start Shift</button>`}
        </div>
        <div class="card p-5"><h3 class="font-bold mb-4">Quick Actions</h3>
          <div class="grid grid-cols-3 gap-3">
            <button onclick="showNewReservation()" class="text-center p-3 bg-gray-50 rounded-xl hover:bg-primary/5 transition-all"><i class="fas fa-calendar-plus text-primary text-lg"></i><p class="text-[10px] font-medium text-gray-600 mt-1">New Res.</p></button>
            <button onclick="navigate('walkin')" class="text-center p-3 bg-gray-50 rounded-xl hover:bg-primary/5 transition-all"><i class="fas fa-walking text-success text-lg"></i><p class="text-[10px] font-medium text-gray-600 mt-1">Walk-in</p></button>
            <button onclick="navigate('pos')" class="text-center p-3 bg-gray-50 rounded-xl hover:bg-primary/5 transition-all"><i class="fas fa-cash-register text-red-500 text-lg"></i><p class="text-[10px] font-medium text-gray-600 mt-1">POS</p></button>
          </div>
        </div>
        <div class="card p-5" id="dash-app-install-card">
          <div class="flex items-center gap-3 mb-3"><div class="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center"><i class="fas fa-mobile-screen-button text-primary"></i></div><div><h3 class="font-bold text-sm">Get the App</h3><p class="text-xs text-gray-400">Install PCH PMS on this device</p></div></div>
          <p class="text-xs text-gray-500 mb-3">Install PCH PMS as a desktop/mobile app for faster access, offline support, and a full-screen experience — no app store needed.</p>
          <button onclick="installPWA()" id="dash-install-btn" class="btn btn-primary btn-sm w-full justify-center"><i class="fas fa-download"></i> Install App</button>
          <div class="grid grid-cols-2 gap-2 mt-2 text-[10px] text-gray-400">
            <div><i class="fas fa-desktop mr-1"></i> Desktop: click ⋮ then "Install"</div>
            <div><i class="fas fa-mobile mr-1"></i> Mobile: "Add to Home Screen"</div>
          </div>
        </div>
      </div>
    </div>
  </div>`;
  startDashboardClock();
}

let _dashClockTimer = null;
function startDashboardClock() {
  if (_dashClockTimer) clearInterval(_dashClockTimer);
  const update = () => {
    const t = $('#dash-live-time'); const d = $('#dash-live-date');
    if (!t) { clearInterval(_dashClockTimer); _dashClockTimer = null; return; }
    const now = new Date();
    t.textContent = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    d.textContent = now.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' });
  };
  update();
  _dashClockTimer = setInterval(update, 1000);
}

async function showRoomDetail(roomId) {
  const rooms = APP.data.dashboard?.rooms || await api('/rooms');
  const room = (Array.isArray(rooms)?rooms:rooms).find(r => r.id === roomId);
  if (!room) return;
  showModal(`Room ${room.room_number}`, `<div class="space-y-4">
    <div class="grid grid-cols-2 gap-4">
      <div class="p-4 bg-gray-50 rounded-xl"><p class="text-xs text-gray-500">Type</p><p class="font-semibold">${room.type_name}</p></div>
      <div class="p-4 bg-gray-50 rounded-xl"><p class="text-xs text-gray-500">Floor</p><p class="font-semibold">${room.floor}</p></div>
      <div class="p-4 bg-gray-50 rounded-xl"><p class="text-xs text-gray-500">Status</p><p class="font-semibold capitalize">${room.status}</p></div>
      <div class="p-4 bg-gray-50 rounded-xl"><p class="text-xs text-gray-500">Rate</p><p class="font-semibold">${fmt(room.base_price)}/night</p></div>
    </div>
    <div><label class="block text-sm font-medium mb-1">Change Status</label>
      <select id="room-status-select" class="input-field"><option value="available" ${room.status==='available'?'selected':''}>Available</option><option value="occupied" ${room.status==='occupied'?'selected':''}>Occupied</option><option value="reserved" ${room.status==='reserved'?'selected':''}>Reserved</option><option value="maintenance" ${room.status==='maintenance'?'selected':''}>Maintenance</option></select>
    </div>
    <button onclick="updateRoomStatus(${room.id})" class="btn btn-primary w-full justify-center">Update</button>
  </div>`, 'sm');
}
async function updateRoomStatus(id) { await put(`/rooms/${id}/status`, { status: $('#room-status-select').value }); closeAllModals(); showToast('Updated'); renderDashboard(); }

// ==================== ARRIVALS ====================
async function renderArrivals() {
  const data = await api('/arrivals');
  APP.data.arrivals = data;
  const mc = $('#main-content');
  mc.innerHTML = `<div class="fade-in">
    <div class="flex items-center justify-between mb-6">
      <div><h2 class="text-2xl font-bold text-gray-800">Today's Arrivals</h2><p class="text-gray-500 text-sm">${data.length} expected arrivals for ${fullDate()}</p></div>
      <div class="flex gap-2">${exportBtns('exportArrivalsPDF','exportArrivalsCSV')}</div>
    </div>
    <div class="card p-5">
      <table class="w-full"><thead><tr class="text-left text-xs text-gray-500 border-b">
        <th class="pb-3">GUEST</th><th class="pb-3">ROOM</th><th class="pb-3">NIGHTS</th><th class="pb-3">VIP</th><th class="pb-3">AMOUNT</th><th class="pb-3">PAYMENT</th><th class="pb-3">STATUS</th><th class="pb-3">ACTIONS</th>
      </tr></thead>
      <tbody>${data.map(r => {
        const nights = Math.ceil((new Date(r.check_out_date) - new Date(r.check_in_date)) / 86400000);
        return `<tr class="table-row border-b border-gray-50">
          <td class="py-3"><p class="text-sm font-medium">${r.first_name} ${r.last_name}</p><p class="text-xs text-gray-400">${r.guest_phone||''}</p></td>
          <td class="py-3 text-sm">${r.room_number||'<span class=text-orange-500>Unassigned</span>'} <span class="text-gray-400">(${r.room_type_name})</span></td>
          <td class="py-3 text-sm">${nights}</td>
          <td class="py-3">${r.vip_status?'<span class="badge badge-gold">VIP</span>':''}</td>
          <td class="py-3 text-sm font-bold">${fmt(r.total_amount)}</td>
          <td class="py-3"><span class="badge ${(r.paid_amount||0)>=r.total_amount?'badge-success':'badge-warning'}">${(r.paid_amount||0)>=r.total_amount?'PAID':'PENDING'}</span></td>
          <td class="py-3"><span class="badge ${r.status==='checked-in'?'badge-success':'badge-warning'}">${r.status}</span></td>
          <td class="py-3">${r.status==='reserved'?`<button onclick="showCheckInFlow(${r.id})" class="btn btn-success btn-sm"><i class="fas fa-sign-in-alt"></i> Check In</button>`:'<span class="text-xs text-gray-400">Checked In</span>'}</td>
        </tr>`;
      }).join('')}</tbody></table>
      ${data.length===0?'<p class="text-center py-8 text-gray-400">No arrivals today</p>':''}
    </div>
  </div>`;
}

function exportArrivalsPDF() {
  const data = APP.data.arrivals || [];
  generatePDF('Arrivals Report - ' + fullDate(), ['Guest', 'Room', 'Type', 'Amount', 'Status'],
    data.map(r => [`${r.first_name} ${r.last_name}`, r.room_number||'TBA', r.room_type_name, fmt(r.total_amount), r.status]),
    { summary: `${data.length} arrivals` });
}
function exportArrivalsCSV() {
  const data = APP.data.arrivals || [];
  generateCSV('Arrivals Report', ['Guest','Phone','Room','Type','Nights','Amount','Status'],
    data.map(r => [`${r.first_name} ${r.last_name}`, r.guest_phone||'', r.room_number||'TBA', r.room_type_name, Math.ceil((new Date(r.check_out_date)-new Date(r.check_in_date))/86400000), r.total_amount, r.status]));
}

// ==================== IN-HOUSE ====================
async function renderInHouse() {
  const data = await api('/inhouse');
  APP.data.inhouse = data;
  const mc = $('#main-content');
  mc.innerHTML = `<div class="fade-in">
    <div class="flex items-center justify-between mb-6">
      <div><h2 class="text-2xl font-bold text-gray-800">In-House Guests</h2><p class="text-gray-500 text-sm">${data.length} guests currently in hotel</p></div>
      <div class="flex gap-2">${exportBtns('exportInHousePDF','exportInHouseCSV')}</div>
    </div>
    <div class="card p-5">
      <table class="w-full"><thead><tr class="text-left text-xs text-gray-500 border-b">
        <th class="pb-3">ROOM</th><th class="pb-3">GUEST</th><th class="pb-3">CHECK-IN</th><th class="pb-3">CHECK-OUT</th><th class="pb-3">VIP</th><th class="pb-3">BALANCE</th><th class="pb-3">ACTIONS</th>
      </tr></thead>
      <tbody>${data.map(r => {
        const bal = r.total_amount - (r.paid_amount||0);
        return `<tr class="table-row border-b border-gray-50">
          <td class="py-3"><span class="font-bold text-primary">${r.room_number}</span><br><span class="text-xs text-gray-400">${r.room_type_name}</span></td>
          <td class="py-3"><p class="text-sm font-medium">${r.first_name} ${r.last_name}</p><p class="text-xs text-gray-400">${r.guest_phone||''}</p></td>
          <td class="py-3 text-sm">${fmtDate(r.check_in_date)}</td>
          <td class="py-3 text-sm">${fmtDate(r.check_out_date)}</td>
          <td class="py-3">${r.vip_status?'<span class="badge badge-gold">VIP</span>':''}</td>
          <td class="py-3 text-sm ${bal>0?'text-red-500 font-bold':'text-green-500'}">${bal>0?fmt(bal):'Paid'}</td>
          <td class="py-3 flex gap-1">
            <button onclick="showReservationDetail(${r.id})" class="btn btn-outline btn-sm"><i class="fas fa-eye"></i></button>
            <button onclick="doCheckOut(${r.id})" class="btn btn-primary btn-sm"><i class="fas fa-sign-out-alt"></i> Out</button>
          </td>
        </tr>`;
      }).join('')}</tbody></table>
      ${data.length===0?'<p class="text-center py-8 text-gray-400">No in-house guests</p>':''}
    </div>
  </div>`;
}

function exportInHousePDF() {
  const data = APP.data.inhouse || [];
  generatePDF('In-House Guest List', ['Room', 'Guest', 'Check-In', 'Check-Out', 'Balance'],
    data.map(r => [r.room_number, `${r.first_name} ${r.last_name}`, fmtDate(r.check_in_date), fmtDate(r.check_out_date), fmt(r.total_amount - (r.paid_amount||0))]),
    { summary: `${data.length} guests in-house` });
}
function exportInHouseCSV() {
  const data = APP.data.inhouse || [];
  generateCSV('In-House Guest List', ['Room','Guest','Phone','Check-In','Check-Out','Total','Paid','Balance'],
    data.map(r => [r.room_number, `${r.first_name} ${r.last_name}`, r.guest_phone||'', r.check_in_date, r.check_out_date, r.total_amount, r.paid_amount||0, r.total_amount - (r.paid_amount||0)]));
}

// ==================== CHECK-IN FLOW with Key Assignment ====================
async function showCheckInFlow(resId) {
  const r = await api(`/reservations/${resId}`);
  const rooms = await api('/rooms');
  const available = rooms.filter(rm => rm.room_type_id == r.room_type_id && rm.status === 'available');
  const nights = Math.ceil((new Date(r.check_out_date) - new Date(r.check_in_date)) / 86400000);
  const balance = r.total_amount - (r.paid_amount || 0);
  
  showModal('Check-In Guest', `<div class="space-y-5">
    <div class="p-4 bg-gray-50 rounded-xl">
      <p class="font-bold text-lg">${r.first_name} ${r.last_name}</p>
      <p class="text-sm text-gray-500">${r.reservation_code} · ${r.room_type_name}</p>
    </div>
    <div class="grid grid-cols-2 md:grid-cols-4 gap-3">
      <div class="p-3 bg-primary/5 rounded-lg"><p class="text-xs text-gray-500">Check-in</p><p class="font-semibold text-primary">${fmtDate(r.check_in_date)}</p></div>
      <div class="p-3 bg-primary/5 rounded-lg"><p class="text-xs text-gray-500">Check-out</p><p class="font-semibold text-primary">${fmtDate(r.check_out_date)}</p></div>
      <div class="p-3 bg-gray-50 rounded-lg"><p class="text-xs text-gray-500">Nights</p><p class="font-semibold">${nights}</p></div>
      <div class="p-3 ${balance > 0 ? 'bg-red-50' : 'bg-green-50'} rounded-lg"><p class="text-xs text-gray-500">Balance</p><p class="font-semibold ${balance > 0 ? 'text-red-500' : 'text-green-500'}">${balance > 0 ? fmt(balance) : 'Paid'}</p></div>
    </div>
    <div><label class="block text-sm font-medium text-gray-700 mb-1">Select Room *</label>
      <select id="ci-room" class="input-field">
        ${r.room_id ? `<option value="${r.room_id}" selected>Room ${r.room_number} (Current)</option>` : '<option value="">Select available room</option>'}
        ${available.map(rm => `<option value="${rm.id}"${!r.room_id && available.indexOf(rm) === 0 ? ' selected' : ''}>Room ${rm.room_number} - Floor ${rm.floor} (${rm.type_name})</option>`).join('')}
      </select>
    </div>
    <div><label class="block text-sm font-medium text-gray-700 mb-1">Key Card Number</label>
      <input id="ci-key" class="input-field" placeholder="e.g. KC-001"></div>
    <div class="p-4 bg-yellow-50 rounded-xl border border-yellow-200">
      <label class="flex items-center gap-3 cursor-pointer">
        <input type="checkbox" id="ci-keyconfirm" class="w-5 h-5 rounded border-gray-300 text-primary">
        <div><p class="font-semibold text-gray-800"><i class="fas fa-key text-yellow-600 mr-1"></i> Confirm Key Assigned</p><p class="text-xs text-gray-500">I confirm that the room key has been programmed and handed to the guest</p></div>
      </label>
    </div>
    <div class="flex gap-3">
      <button onclick="printRegistrationForm(${resId})" class="btn btn-outline flex-1 justify-center"><i class="fas fa-print"></i> Print Reg. Form</button>
      <button onclick="executeCheckIn(${resId})" class="btn btn-success flex-1 justify-center"><i class="fas fa-sign-in-alt"></i> Complete Check-In</button>
    </div>
  </div>`, 'md');
}

async function executeCheckIn(resId) {
  const roomId = $('#ci-room')?.value;
  if (!roomId) return showToast('Please select a room', 'error');
  if (!$('#ci-keyconfirm')?.checked) return showToast('Please confirm key assignment', 'error');
  await post(`/reservations/${resId}/checkin`, { room_id: parseInt(roomId), key_card_number: $('#ci-key')?.value || '' });
  closeAllModals(); showToast('Guest checked in successfully!');
  if (APP.currentPage === 'arrivals') renderArrivals();
  else if (APP.currentPage === 'dashboard') renderDashboard();
  else if (APP.currentPage === 'reservations') loadReservations();
}

function printRegistrationForm(resId) {
  api(`/reservations/${resId}`).then(r => {
    const w = window.open('', '_blank');
    w.document.write(`<!DOCTYPE html><html><head><title>Registration Form</title>
      <style>body{font-family:Arial;margin:20px;font-size:14px}h1{text-align:center;color:#6C63FF}table{width:100%;border-collapse:collapse;margin:15px 0}td,th{border:1px solid #ddd;padding:8px;text-align:left}.sig{height:60px;border-bottom:1px solid #333;margin-top:40px}</style></head>
      <body><h1>PCH PMS - Guest Registration Card</h1><p style="text-align:center">${APP.hotelName} · ${APP.hotelCity}</p><hr>
      <table><tr><td><b>Reservation:</b> ${r.reservation_code}</td><td><b>Date:</b> ${fullDate()}</td></tr>
      <tr><td><b>Guest Name:</b> ${r.first_name} ${r.last_name}</td><td><b>Nationality:</b> ${r.nationality||'-'}</td></tr>
      <tr><td><b>Phone:</b> ${r.guest_phone||'-'}</td><td><b>Email:</b> ${r.guest_email||'-'}</td></tr>
      <tr><td><b>ID Type:</b> ${r.id_type||'-'}</td><td><b>ID Number:</b> ${r.id_number||'-'}</td></tr>
      <tr><td><b>Address:</b> ${r.guest_address||'-'}, ${r.guest_city||'-'}, ${r.guest_country||'-'}</td><td><b>Company:</b> ${r.company||'-'}</td></tr>
      <tr><td><b>Room:</b> ${r.room_number||'TBA'} (${r.room_type_name})</td><td><b>Rate:</b> ${fmt(r.rate_per_night)}/night</td></tr>
      <tr><td><b>Check-in:</b> ${fmtDate(r.check_in_date)}</td><td><b>Check-out:</b> ${fmtDate(r.check_out_date)}</td></tr>
      <tr><td><b>Adults:</b> ${r.adults}</td><td><b>Children:</b> ${r.children}</td></tr>
      <tr><td colspan="2"><b>Special Requests:</b> ${r.special_requests||'None'}</td></tr></table>
      <p style="font-size:12px;color:#666">I agree to the hotel's terms and conditions. I am responsible for all charges incurred during my stay.</p>
      <div class="sig"><p>Guest Signature: _________________________</p></div>
      <div class="sig"><p>Front Desk: _________________________</p></div>
      <script>window.print();window.close();</script></body></html>`);
  });
}

// ==================== RESERVATIONS ====================
async function renderReservations() {
  const mc = $('#main-content');
  mc.innerHTML = `<div class="fade-in">
    <div class="flex items-center justify-between mb-6">
      <div><h2 class="text-2xl font-bold text-gray-800">Reservations</h2></div>
      <button onclick="showNewReservation()" class="btn btn-primary"><i class="fas fa-plus"></i> New Reservation</button>
    </div>
    <div class="card p-5">
      <div class="flex flex-wrap items-center gap-3 mb-5">
        <select id="res-status-filter" onchange="loadReservations()" class="input-field w-auto"><option value="all">All</option><option value="reserved">Reserved</option><option value="checked-in">Checked In</option><option value="checked-out">Checked Out</option><option value="cancelled">Cancelled</option></select>
        <input type="text" id="res-date-from" class="input-field w-auto date-picker" placeholder="From">
        <input type="text" id="res-date-to" class="input-field w-auto date-picker" placeholder="To">
        <button onclick="loadReservations()" class="btn btn-outline btn-sm"><i class="fas fa-filter"></i></button>
        <div class="flex gap-2 ml-auto">${exportBtns('exportReservationsPDF','exportReservationsCSV')}</div>
      </div>
      <div id="reservations-table"></div>
    </div>
  </div>`;
  initDatePickers(); loadReservations();
}

async function loadReservations() {
  const status = $('#res-status-filter')?.value || 'all';
  const from = $('#res-date-from')?.value || '';
  const to = $('#res-date-to')?.value || '';
  let url = `/reservations?status=${status}`;
  if (from) url += `&from=${from}`; if (to) url += `&to=${to}`;
  const data = await api(url);
  APP.data.reservations = data;
  const c = $('#reservations-table'); if (!c) return;
  c.innerHTML = `<table class="w-full"><thead><tr class="text-left text-xs text-gray-500 border-b">
    <th class="pb-3">CODE</th><th class="pb-3">GUEST</th><th class="pb-3">ROOM</th><th class="pb-3">CHECK-IN</th><th class="pb-3">CHECK-OUT</th><th class="pb-3">AMOUNT</th><th class="pb-3">STATUS</th><th class="pb-3">PAYMENT</th>
  </tr></thead><tbody>${data.map(r => `<tr class="table-row border-b border-gray-50 cursor-pointer" onclick="showReservationDetail(${r.id})">
    <td class="py-3 text-sm font-mono text-primary font-medium">${r.reservation_code}</td>
    <td class="py-3 text-sm font-medium">${r.first_name} ${r.last_name}</td>
    <td class="py-3 text-sm text-gray-600">${r.room_number||'TBA'} (${r.room_type_name})</td>
    <td class="py-3 text-sm">${fmtDate(r.check_in_date)}</td><td class="py-3 text-sm">${fmtDate(r.check_out_date)}</td>
    <td class="py-3 text-sm font-medium">${fmt(r.total_amount)}</td>
    <td class="py-3"><span class="badge ${r.status==='checked-in'?'badge-success':r.status==='reserved'?'badge-warning':r.status==='checked-out'?'badge-info':'badge-danger'}">${r.status}</span></td>
    <td class="py-3"><span class="badge ${(r.paid_amount||0)>=r.total_amount?'badge-success':'badge-warning'}">${(r.paid_amount||0)>=r.total_amount?'PAID':'PENDING'}</span></td>
  </tr>`).join('')}</tbody></table>${data.length===0?'<p class="text-center py-8 text-gray-400">No reservations found</p>':''}`;
}

async function showReservationDetail(id) {
  const r = await api(`/reservations/${id}`);
  const actions = [];
  if (r.status === 'reserved') actions.push(`<button onclick="showCheckInFlow(${r.id})" class="btn btn-success btn-sm"><i class="fas fa-sign-in-alt"></i> Check In</button>`);
  if (r.status === 'checked-in') actions.push(`<button onclick="doCheckOut(${r.id})" class="btn btn-primary btn-sm"><i class="fas fa-sign-out-alt"></i> Check Out</button>`);
  if (r.status !== 'cancelled' && r.status !== 'checked-out') actions.push(`<button onclick="showChangeRoom(${r.id})" class="btn btn-warning btn-sm"><i class="fas fa-exchange-alt"></i> Change Room</button>`);
  if (r.status === 'reserved') actions.push(`<button onclick="doCancelReservation(${r.id})" class="btn btn-danger btn-sm"><i class="fas fa-times"></i> Cancel</button>`);
  actions.push(`<button onclick="printRegistrationForm(${r.id})" class="btn btn-outline btn-sm"><i class="fas fa-print"></i> Reg Form</button>`);
  actions.push(`<button onclick="generateFolioPDF(${r.id})" class="btn btn-outline btn-sm"><i class="fas fa-file-invoice"></i> Folio</button>`);

  showModal(`${r.reservation_code}`, `<div class="space-y-5">
    <div class="flex flex-wrap gap-2">${actions.join('')}</div>
    <div class="grid grid-cols-2 md:grid-cols-3 gap-4">
      <div class="p-4 bg-gray-50 rounded-xl"><p class="text-xs text-gray-500">Guest</p><p class="font-semibold">${r.first_name} ${r.last_name}</p><p class="text-xs text-gray-400">${r.guest_phone||''} · ${r.guest_email||''}</p></div>
      <div class="p-4 bg-gray-50 rounded-xl"><p class="text-xs text-gray-500">Room</p><p class="font-semibold">${r.room_number||'Unassigned'}</p><p class="text-xs text-gray-400">${r.room_type_name}</p></div>
      <div class="p-4 bg-gray-50 rounded-xl"><p class="text-xs text-gray-500">Status</p><p class="font-semibold capitalize">${r.status}</p>${r.key_assigned?'<p class="text-xs text-green-500"><i class="fas fa-key"></i> Key assigned</p>':''}</div>
      <div class="p-4 bg-gray-50 rounded-xl"><p class="text-xs text-gray-500">Check In</p><p class="font-semibold">${fmtDate(r.check_in_date)}</p></div>
      <div class="p-4 bg-gray-50 rounded-xl"><p class="text-xs text-gray-500">Check Out</p><p class="font-semibold">${fmtDate(r.check_out_date)}</p></div>
      <div class="p-4 bg-gray-50 rounded-xl"><p class="text-xs text-gray-500">Rate</p><p class="font-semibold">${fmt(r.rate_per_night)}/night</p></div>
      <div class="p-4 bg-primary/5 rounded-xl"><p class="text-xs text-gray-500">Total</p><p class="font-bold text-primary text-lg">${fmt(r.total_amount)}</p></div>
      <div class="p-4 bg-green-50 rounded-xl"><p class="text-xs text-gray-500">Paid</p><p class="font-bold text-success text-lg">${fmt(r.paid_amount)}</p></div>
      <div class="p-4 ${(r.total_amount-(r.paid_amount||0))>0?'bg-red-50':'bg-green-50'} rounded-xl"><p class="text-xs text-gray-500">Balance</p><p class="font-bold ${(r.total_amount-(r.paid_amount||0))>0?'text-danger':'text-success'} text-lg">${fmt(r.total_amount-(r.paid_amount||0))}</p></div>
    </div>
    ${r.special_requests?`<div class="p-4 bg-yellow-50 rounded-xl"><p class="text-xs text-gray-500">Special Requests</p><p class="text-sm">${r.special_requests}</p></div>`:''}
    <h4 class="font-semibold text-sm">Payments</h4>
    ${(r.payments||[]).map(p => `<div class="flex items-center justify-between p-3 bg-gray-50 rounded-xl text-sm"><div><span class="font-medium">${fmt(p.amount)}</span> <span class="text-gray-400">via ${p.payment_method}</span></div><span class="text-xs text-gray-400">${fmtDateTime(p.created_at)}</span></div>`).join('')}
    ${(r.payments||[]).length===0?'<p class="text-gray-400 text-sm">No payments</p>':''}
    ${r.status!=='cancelled'&&r.status!=='checked-out'?`<button onclick="showAddPaymentForRes(${r.id},${r.guest_id})" class="btn btn-success btn-sm"><i class="fas fa-plus"></i> Add Payment</button>`:''}
  </div>`, 'lg');
}

async function generateFolioPDF(resId) {
  const r = await api(`/reservations/${resId}`);
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF();
  doc.setFillColor(108,99,255); doc.rect(0,0,220,40,'F');
  doc.setTextColor(255); doc.setFontSize(24); doc.setFont('helvetica','bold');
  doc.text('GUEST FOLIO',14,20); doc.setFontSize(12); doc.text(r.reservation_code,14,30);
  doc.setFontSize(10); doc.setFont('helvetica','normal');
  doc.text(APP.hotelName,196,15,{align:'right'}); doc.text(APP.hotelCity,196,22,{align:'right'});
  doc.text(`Date: ${fullDate()}`,196,30,{align:'right'});
  doc.setTextColor(50); doc.setFontSize(11); doc.setFont('helvetica','bold');
  doc.text('Guest:',14,52); doc.setFont('helvetica','normal');
  doc.text(`${r.first_name} ${r.last_name}`,14,59);
  if (r.guest_email) doc.text(r.guest_email,14,65);
  if (r.guest_phone) doc.text(r.guest_phone,14,71);
  doc.setFont('helvetica','bold'); doc.text('Room:',120,52); doc.setFont('helvetica','normal');
  doc.text(`${r.room_number||'TBA'} (${r.room_type_name})`,120,59);
  doc.text(`${fmtDate(r.check_in_date)} - ${fmtDate(r.check_out_date)}`,120,65);
  const nights = Math.ceil((new Date(r.check_out_date)-new Date(r.check_in_date))/86400000);
  const rows = [[`Room Charge (${nights} nights x ${fmt(r.rate_per_night)})`, nights, fmt(r.rate_per_night), fmt(r.total_amount)]];
  doc.autoTable({head:[['Description','Qty','Rate','Total']],body:rows,startY:80,styles:{fontSize:10},headStyles:{fillColor:[108,99,255]}});
  const fy = doc.lastAutoTable.finalY + 10;
  doc.setFontSize(14); doc.setFont('helvetica','bold'); doc.setTextColor(108,99,255);
  doc.text(`Total: ${fmt(r.total_amount)}`,140,fy);
  doc.setTextColor(50); doc.setFontSize(10); doc.setFont('helvetica','normal');
  doc.text(`Paid: ${fmt(r.paid_amount)}`,140,fy+8);
  doc.text(`Balance: ${fmt(r.total_amount-(r.paid_amount||0))}`,140,fy+16);
  doc.save(`Folio_${r.reservation_code}_${today()}.pdf`);
  showToast('Folio downloaded!');
}

// Store pre-selected dates for reservation form
let _preselectedDates = { checkin: null, checkout: null };

async function showNewReservation(preselectedCheckin, preselectedCheckout) {
  // Save pre-selected dates
  _preselectedDates.checkin = preselectedCheckin || null;
  _preselectedDates.checkout = preselectedCheckout || null;
  
  const checkinVal = preselectedCheckin || today();
  const checkoutVal = preselectedCheckout || '';
  
  const [roomTypes, guests] = await Promise.all([api('/room-types'), api('/guests')]);
  showModal('New Reservation', `<div class="space-y-4">
    <div class="grid grid-cols-2 gap-4">
      <div><label class="block text-sm font-medium mb-1">Guest *</label>
        <select id="nr-guest" class="input-field"><option value="">Select guest</option>${guests.map(g=>`<option value="${g.id}">${g.first_name} ${g.last_name} - ${g.phone||g.email||''}</option>`).join('')}</select>
        <button onclick="showQuickGuest()" class="text-xs text-primary mt-1">+ New Guest</button></div>
      <div><label class="block text-sm font-medium mb-1">Room Type *</label>
        <select id="nr-type" class="input-field" onchange="updateNRRooms()">${roomTypes.map(t=>`<option value="${t.id}" data-price="${t.base_price}">${t.name} - ${fmt(t.base_price)}/night</option>`).join('')}</select></div>
      <div><label class="block text-sm font-medium mb-1">Room</label><select id="nr-room" class="input-field"><option value="">Auto-assign</option></select></div>
      <div><label class="block text-sm font-medium mb-1">Source</label>
        <select id="nr-source" class="input-field"><option value="walk-in">Walk-in</option><option value="online">Online</option><option value="phone">Phone</option><option value="agent">Agent</option></select></div>
      <div><label class="block text-sm font-medium mb-1">Check-in *</label><input id="nr-checkin" type="text" class="input-field date-picker" value="${checkinVal}"></div>
      <div><label class="block text-sm font-medium mb-1">Check-out *</label><input id="nr-checkout" type="text" class="input-field date-picker" value="${checkoutVal}"></div>
      <div><label class="block text-sm font-medium mb-1">Adults</label><input id="nr-adults" type="number" class="input-field" value="1" min="1"></div>
      <div><label class="block text-sm font-medium mb-1">Children</label><input id="nr-children" type="number" class="input-field" value="0" min="0"></div>
    </div>
    <div><label class="block text-sm font-medium mb-1">Rate/Night</label><input id="nr-rate" type="number" class="input-field" value="${roomTypes[0]?.base_price||0}"></div>
    <div><label class="block text-sm font-medium mb-1">Special Requests</label><textarea id="nr-requests" class="input-field" rows="2"></textarea></div>
    <div class="flex gap-3">
      <button onclick="createRes('reserved')" class="btn btn-primary flex-1 justify-center"><i class="fas fa-calendar-check"></i> Reserve</button>
      <button onclick="createRes('checked-in')" class="btn btn-success flex-1 justify-center"><i class="fas fa-sign-in-alt"></i> Reserve & Check In</button>
    </div>
  </div>`, 'lg');
  initDatePickers(); updateNRRooms();
}

async function updateNRRooms() {
  const typeId = $('#nr-type')?.value; if (!typeId) return;
  const rooms = await api('/rooms');
  const avail = rooms.filter(r => r.room_type_id == typeId && r.status === 'available');
  const sel = $('#nr-room');
  if (sel) sel.innerHTML = `<option value="">Auto-assign</option>${avail.map(r=>`<option value="${r.id}">Room ${r.room_number} - Floor ${r.floor}</option>`).join('')}`;
  const opt = $(`#nr-type option[value="${typeId}"]`);
  if (opt && $('#nr-rate')) $('#nr-rate').value = opt.dataset.price;
}

async function createRes(status) {
  const gid = $('#nr-guest').value; if (!gid) return showToast('Select guest', 'error');
  // Use flatpickr's internal value or DOM value, with pre-selected fallback
  const ciEl = $('#nr-checkin');
  const coEl = $('#nr-checkout');
  const ci = (ciEl && ciEl._flatpickr ? ciEl._flatpickr.selectedDates[0] : null) 
    ? ciEl._flatpickr.formatDate(ciEl._flatpickr.selectedDates[0], 'Y-m-d')
    : ciEl?.value || _preselectedDates.checkin || '';
  const co = (coEl && coEl._flatpickr ? coEl._flatpickr.selectedDates[0] : null)
    ? coEl._flatpickr.formatDate(coEl._flatpickr.selectedDates[0], 'Y-m-d')
    : coEl?.value || _preselectedDates.checkout || '';
  if (!ci || !co) return showToast('Select dates', 'error');
  if (new Date(co) <= new Date(ci)) return showToast('Check-out must be after check-in', 'error');
  const d = { guest_id: parseInt(gid), room_type_id: parseInt($('#nr-type').value), room_id: $('#nr-room').value ? parseInt($('#nr-room').value) : null, check_in_date: ci, check_out_date: co, adults: parseInt($('#nr-adults').value)||1, children: parseInt($('#nr-children').value)||0, rate_per_night: parseFloat($('#nr-rate').value)||0, source: $('#nr-source').value, special_requests: $('#nr-requests').value, status, created_by: APP.user.id };
  if (!d.room_id) {
    const rooms = await api('/rooms');
    const avail = rooms.find(r => r.room_type_id == d.room_type_id && r.status === 'available');
    if (!avail && status === 'checked-in') return showToast('No available rooms', 'error');
    if (avail) d.room_id = avail.id;
  }
  const result = await post('/reservations', d);
  _preselectedDates = { checkin: null, checkout: null }; // Reset
  closeAllModals(); showToast(`Reservation ${result.code} created!`);
  if (APP.currentPage === 'reservations') loadReservations(); else navigate(APP.currentPage);
}

function showQuickGuest() {
  closeAllModals();
  showModal('Quick Guest', `<div class="space-y-4">
    <div class="grid grid-cols-2 gap-4">
      <div><label class="block text-sm font-medium mb-1">First Name *</label><input id="qg-fn" class="input-field"></div>
      <div><label class="block text-sm font-medium mb-1">Last Name *</label><input id="qg-ln" class="input-field"></div>
      <div><label class="block text-sm font-medium mb-1">Phone</label><input id="qg-phone" class="input-field"></div>
      <div><label class="block text-sm font-medium mb-1">Email</label><input id="qg-email" class="input-field"></div>
    </div>
    <button onclick="createQG()" class="btn btn-primary w-full justify-center">Create & Continue</button>
  </div>`, 'sm');
}
async function createQG() {
  const fn=$('#qg-fn').value, ln=$('#qg-ln').value; if (!fn||!ln) return showToast('Name required','error');
  const r = await post('/guests',{first_name:fn,last_name:ln,phone:$('#qg-phone').value,email:$('#qg-email').value});
  closeAllModals(); showToast('Guest created!'); showNewReservation();
  setTimeout(()=>{const s=$('#nr-guest');if(s)s.value=r.id;},500);
}

async function doCheckOut(resId) {
  if (!await confirmAction('Check out this guest?')) return;
  await post(`/reservations/${resId}/checkout`, {});
  closeAllModals(); showToast('Checked out!'); navigate(APP.currentPage);
}

async function showChangeRoom(resId) {
  const rooms = await api('/rooms');
  const avail = rooms.filter(r => r.status === 'available');
  closeAllModals();
  showModal('Change Room', `<div class="space-y-4">
    <div><label class="block text-sm font-medium mb-1">New Room</label>
      <select id="cr-room" class="input-field">${avail.map(r=>`<option value="${r.id}">${r.room_number} - ${r.type_name} (${fmt(r.base_price)})</option>`).join('')}</select></div>
    <div><label class="block text-sm font-medium mb-1">Reason</label><textarea id="cr-reason" class="input-field" rows="2"></textarea></div>
    <button onclick="doChangeRoom(${resId})" class="btn btn-primary w-full justify-center">Change</button>
  </div>`, 'sm');
}
async function doChangeRoom(resId) { await post(`/reservations/${resId}/change-room`, { new_room_id: parseInt($('#cr-room').value), reason: $('#cr-reason').value }); closeAllModals(); showToast('Room changed!'); navigate(APP.currentPage); }
async function doCancelReservation(resId) { if (!await confirmAction('Cancel this reservation?')) return; await post(`/reservations/${resId}/cancel`, {}); closeAllModals(); showToast('Cancelled'); navigate(APP.currentPage); }

function exportReservationsPDF() {
  const data = APP.data.reservations || [];
  generatePDF('Reservations Report', ['Code','Guest','Room','Check In','Check Out','Amount','Status'],
    data.map(r=>[r.reservation_code,`${r.first_name} ${r.last_name}`,r.room_number||'-',fmtDate(r.check_in_date),fmtDate(r.check_out_date),fmt(r.total_amount),r.status]), {summary:`${data.length} reservations`});
}
function exportReservationsCSV() {
  const data = APP.data.reservations || [];
  generateCSV('Reservations Report', ['Code','Guest','Phone','Room','Room Type','Check In','Check Out','Adults','Children','Rate/Night','Total','Paid','Balance','Status','Source'],
    data.map(r=>[r.reservation_code,`${r.first_name} ${r.last_name}`,r.guest_phone||'',r.room_number||'',r.room_type_name||'',r.check_in_date,r.check_out_date,r.adults,r.children,r.rate_per_night,r.total_amount,r.paid_amount||0,r.total_amount-(r.paid_amount||0),r.status,r.source]));
}

// ==================== WALK-IN ====================
async function renderWalkin() {
  const [roomTypes, rooms] = await Promise.all([api('/room-types'), api('/rooms')]);
  const mc = $('#main-content');
  mc.innerHTML = `<div class="fade-in">
    <div class="mb-6"><h2 class="text-2xl font-bold text-gray-800">Walk-in Check-in</h2></div>
    <div class="card p-6">
      <div class="space-y-4">
        <div class="grid grid-cols-2 md:grid-cols-3 gap-4">
          <div><label class="block text-sm font-medium mb-1">First Name *</label><input id="wi-fn" class="input-field"></div>
          <div><label class="block text-sm font-medium mb-1">Last Name *</label><input id="wi-ln" class="input-field"></div>
          <div><label class="block text-sm font-medium mb-1">Phone *</label><input id="wi-phone" class="input-field"></div>
          <div><label class="block text-sm font-medium mb-1">Email</label><input id="wi-email" class="input-field"></div>
          <div><label class="block text-sm font-medium mb-1">ID Type</label><select id="wi-idtype" class="input-field"><option value="">Select</option><option value="passport">Passport</option><option value="national_id">National ID</option><option value="driver_license">Driver's License</option></select></div>
          <div><label class="block text-sm font-medium mb-1">ID Number</label><input id="wi-idnum" class="input-field"></div>
          <div><label class="block text-sm font-medium mb-1">Address</label><input id="wi-addr" class="input-field"></div>
          <div><label class="block text-sm font-medium mb-1">City</label><input id="wi-city" class="input-field"></div>
          <div><label class="block text-sm font-medium mb-1">Country</label><input id="wi-country" class="input-field" value="Nigeria"></div>
        </div>
        <div class="grid grid-cols-2 md:grid-cols-3 gap-4">
          <div><label class="block text-sm font-medium mb-1">Room Type *</label>
            <select id="wi-type" class="input-field" onchange="updateWiRooms()">${roomTypes.map(t=>`<option value="${t.id}" data-price="${t.base_price}">${t.name} - ${fmt(t.base_price)}/night</option>`).join('')}</select></div>
          <div><label class="block text-sm font-medium mb-1">Room *</label><select id="wi-room" class="input-field"></select></div>
          <div><label class="block text-sm font-medium mb-1">Check-out *</label><input id="wi-checkout" type="text" class="input-field date-picker"></div>
          <div><label class="block text-sm font-medium mb-1">Rate/Night</label><input id="wi-rate" type="number" class="input-field" value="${roomTypes[0]?.base_price||0}"></div>
          <div><label class="block text-sm font-medium mb-1">Payment</label><select id="wi-payment" class="input-field"><option value="cash">Cash</option><option value="card">Card</option><option value="transfer">Transfer</option></select></div>
        </div>
        <button onclick="processWalkin()" class="btn btn-success w-full justify-center py-3"><i class="fas fa-check-circle"></i> Register & Check In</button>
      </div>
    </div>
  </div>`;
  initDatePickers(); updateWiRooms();
}

async function updateWiRooms() {
  const typeId = $('#wi-type')?.value;
  const rooms = await api('/rooms');
  const avail = rooms.filter(r => r.room_type_id == typeId && r.status === 'available');
  const sel = $('#wi-room');
  if (sel) sel.innerHTML = avail.map(r=>`<option value="${r.id}">Room ${r.room_number}</option>`).join('');
  const opt = $(`#wi-type option[value="${typeId}"]`);
  if (opt && $('#wi-rate')) $('#wi-rate').value = opt.dataset.price;
}

async function processWalkin() {
  const fn=$('#wi-fn').value, ln=$('#wi-ln').value;
  if (!fn||!ln) return showToast('Name required','error');
  if (!$('#wi-room').value) return showToast('No room available','error');
  // Get check-out date from flatpickr or DOM value
  const coEl = $('#wi-checkout');
  const checkout = (coEl && coEl._flatpickr && coEl._flatpickr.selectedDates[0])
    ? coEl._flatpickr.formatDate(coEl._flatpickr.selectedDates[0], 'Y-m-d')
    : coEl?.value || '';
  if (!checkout) return showToast('Check-out date required','error');
  if (new Date(checkout) <= new Date(today())) return showToast('Check-out must be after today', 'error');
  const guest = await post('/guests', {first_name:fn,last_name:ln,phone:$('#wi-phone').value,email:$('#wi-email').value,id_type:$('#wi-idtype').value,id_number:$('#wi-idnum').value,address:$('#wi-addr').value,city:$('#wi-city').value,country:$('#wi-country').value});
  await post('/reservations', {guest_id:guest.id,room_type_id:parseInt($('#wi-type').value),room_id:parseInt($('#wi-room').value),check_in_date:today(),check_out_date:checkout,rate_per_night:parseFloat($('#wi-rate').value),status:'checked-in',source:'walk-in',created_by:APP.user.id});
  showToast('Walk-in checked in!'); renderWalkin();
}

// ==================== GUESTS ====================
async function renderGuests() {
  const mc = $('#main-content');
  mc.innerHTML = `<div class="fade-in">
    <div class="flex items-center justify-between mb-6">
      <div><h2 class="text-2xl font-bold text-gray-800">Guests</h2></div>
      <button onclick="showNewGuestModal()" class="btn btn-primary"><i class="fas fa-plus"></i> Add Guest</button>
    </div>
    <div class="card p-5">
      <div class="flex items-center gap-3 mb-5">
        <div class="relative flex-1 max-w-md"><i class="fas fa-search absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400"></i><input id="guest-search" type="text" class="input-field pl-10" placeholder="Search guests..."></div>
        ${exportBtns('exportGuestsPDF','exportGuestsCSV')}
      </div>
      <div id="guests-table"></div>
    </div>
  </div>`;
  let st; $('#guest-search').addEventListener('input', (e) => { clearTimeout(st); st = setTimeout(() => loadGuests(e.target.value), 300); });
  loadGuests();
}

async function loadGuests(search = '') {
  const guests = await api(`/guests?search=${encodeURIComponent(search)}`);
  APP.data.guests = guests;
  const c = $('#guests-table'); if (!c) return;
  c.innerHTML = `<table class="w-full"><thead><tr class="text-left text-xs text-gray-500 border-b">
    <th class="pb-3">NAME</th><th class="pb-3">PHONE</th><th class="pb-3">EMAIL</th><th class="pb-3">VIP</th><th class="pb-3">LOYALTY</th><th class="pb-3">ACTIONS</th>
  </tr></thead><tbody>${guests.map(g=>`<tr class="table-row border-b border-gray-50">
    <td class="py-3 text-sm font-medium cursor-pointer" onclick="showGuestProfile(${g.id})">${g.first_name} ${g.last_name}</td>
    <td class="py-3 text-sm text-gray-600">${g.phone||'-'}</td>
    <td class="py-3 text-sm text-gray-600">${g.email||'-'}</td>
    <td class="py-3">${g.vip_status?'<span class="badge badge-gold">VIP</span>':''}</td>
    <td class="py-3"><span class="badge badge-${g.loyalty_tier||'bronze'}">${(g.loyalty_tier||'bronze').toUpperCase()} · ${g.loyalty_points||0}pts</span></td>
    <td class="py-3 flex gap-1">
      <button onclick="showEditGuest(${g.id})" class="btn btn-outline btn-sm"><i class="fas fa-edit"></i></button>
      <button onclick="deleteGuest(${g.id})" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></button>
    </td>
  </tr>`).join('')}</tbody></table>${guests.length===0?'<p class="text-center py-8 text-gray-400">No guests</p>':''}`;
}

async function showGuestProfile(id) {
  const g = await api(`/guests/${id}`);
  showModal(`${g.first_name} ${g.last_name}`, `<div class="space-y-5">
    <div class="flex items-center gap-4 p-4 bg-gray-50 rounded-xl">
      <div class="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center"><span class="text-primary font-bold text-2xl">${g.first_name[0]}${g.last_name[0]}</span></div>
      <div class="flex-1">
        <h3 class="text-lg font-bold">${g.first_name} ${g.last_name} ${g.vip_status?'<span class="badge badge-gold ml-2">VIP</span>':''}</h3>
        <p class="text-gray-500 text-sm">${g.phone||''} · ${g.email||''}</p>
        <p class="text-gray-400 text-xs">${g.address||''} ${g.city||''} ${g.country||''}</p>
      </div>
      <div class="text-center p-3 bg-primary/5 rounded-xl">
        <p class="text-2xl font-bold text-primary">${g.loyalty_points||0}</p>
        <p class="text-xs text-gray-500">${(g.loyalty_tier||'bronze').toUpperCase()}</p>
      </div>
    </div>
    <h4 class="font-semibold text-sm">Reservations & Stays</h4>
    ${(g.reservations||[]).map(r=>{
      const bal = r.total_amount - (r.paid_amount||0);
      return `<div class="p-3 bg-gray-50 rounded-xl mb-2">
        <div class="flex items-center justify-between">
          <div class="cursor-pointer" onclick="closeAllModals();showReservationDetail(${r.id})">
            <span class="font-mono text-primary font-medium">${r.reservation_code}</span>
            <span class="text-gray-400 text-sm ml-2">${r.room_number||'TBA'} (${r.room_type_name})</span>
          </div>
          <span class="badge ${r.status==='checked-in'?'badge-success':r.status==='reserved'?'badge-warning':r.status==='checked-out'?'badge-info':'badge-danger'}">${r.status}</span>
        </div>
        <div class="flex items-center gap-4 mt-2 text-xs text-gray-500">
          <span>${fmtDate(r.check_in_date)} → ${fmtDate(r.check_out_date)}</span>
          <span class="font-medium">${fmt(r.total_amount)}</span>
          <span class="${bal>0?'text-red-500':'text-green-500'}">${bal>0?'Bal: '+fmt(bal):'Paid'}</span>
        </div>
        <div class="flex gap-2 mt-2">
          <button onclick="printGuestFolio(${r.id})" class="btn btn-outline btn-sm"><i class="fas fa-print"></i> Print Folio</button>
          <button onclick="generateFolioPDF(${r.id})" class="btn btn-outline btn-sm"><i class="fas fa-file-pdf"></i> PDF Folio</button>
        </div>
      </div>`;
    }).join('')}
    ${(g.reservations||[]).length===0?'<p class="text-gray-400 text-sm">No reservations</p>':''}
    <h4 class="font-semibold text-sm">Loyalty History</h4>
    ${(g.loyalty||[]).map(l=>`<div class="flex items-center justify-between p-2 text-sm"><span>${l.description}</span><span class="${l.type==='earn'?'text-green-500':'text-red-500'} font-medium">${l.type==='earn'?'+':'-'}${l.points} pts</span></div>`).join('')}
  </div>`, 'lg');
}

async function printGuestFolio(resId) {
  const r = await api('/folio/' + resId);
  const nights = Math.ceil((new Date(r.check_out_date)-new Date(r.check_in_date))/86400000);
  const bal = r.total_amount - (r.paid_amount||0);
  const posCharges = (r.pos_orders||[]).reduce((s,o)=>s+o.total,0);
  const w = window.open('','_blank');
  w.document.write(`<!DOCTYPE html><html><head><title>Guest Folio</title>
    <style>body{font-family:Arial,sans-serif;margin:0;padding:20px;font-size:13px;color:#333}
    .header{text-align:center;border-bottom:3px solid #6C63FF;padding-bottom:15px;margin-bottom:15px}
    .header h1{color:#6C63FF;margin:0;font-size:24px}
    .header p{margin:2px 0;color:#666;font-size:12px}
    table{width:100%;border-collapse:collapse;margin:10px 0}
    td,th{border:1px solid #ddd;padding:8px;text-align:left;font-size:12px}
    th{background:#f8f8ff;font-weight:600}
    .total-row{font-weight:bold;background:#f0effe}
    .info-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:10px 0}
    .info-box{background:#f8f8ff;padding:10px;border-radius:8px}
    .info-box label{font-size:10px;color:#888;display:block}
    .info-box span{font-size:13px;font-weight:600}
    .sig-area{margin-top:40px;border-top:1px solid #ddd;padding-top:20px}
    .sig-line{border-bottom:1px solid #333;height:40px;margin:20px 0 5px 0}
    @media print{body{margin:0;padding:15px}}</style></head>
    <body>
    <div class="header">
      <h1>${r.hotel_name||APP.hotelName}</h1>
      <p>${r.hotel_address||''}, ${r.hotel_city||''}, ${r.hotel_country||''}</p>
      <p>Tel: ${r.hotel_phone||''} | Email: ${r.hotel_email||''}</p>
      <h2 style="margin-top:10px;color:#333">GUEST FOLIO</h2>
    </div>
    <div class="info-grid">
      <div class="info-box"><label>Guest</label><span>${r.first_name} ${r.last_name}</span></div>
      <div class="info-box"><label>Reservation</label><span>${r.reservation_code}</span></div>
      <div class="info-box"><label>Room</label><span>${r.room_number||'TBA'} (${r.room_type_name})</span></div>
      <div class="info-box"><label>Status</label><span>${r.status}</span></div>
      <div class="info-box"><label>Check-in</label><span>${r.check_in_date}</span></div>
      <div class="info-box"><label>Check-out</label><span>${r.check_out_date}</span></div>
      <div class="info-box"><label>Phone</label><span>${r.guest_phone||'-'}</span></div>
      <div class="info-box"><label>Email</label><span>${r.guest_email||'-'}</span></div>
    </div>
    <h3 style="margin-top:15px;color:#6C63FF">Charges</h3>
    <table>
      <thead><tr><th>Date</th><th>Description</th><th>Qty</th><th>Rate</th><th>Amount</th></tr></thead>
      <tbody>
        <tr><td>${r.check_in_date}</td><td>Room Charge - ${r.room_type_name}</td><td>${nights}</td><td>${APP.currency}${Number(r.rate_per_night).toLocaleString()}</td><td>${APP.currency}${Number(r.total_amount).toLocaleString()}</td></tr>
        ${(r.pos_orders||[]).map(o=>`<tr><td>${o.created_at?.split('T')[0]||'-'}</td><td>F&B / POS Order #${o.order_number}</td><td>1</td><td>${APP.currency}${Number(o.total).toLocaleString()}</td><td>${APP.currency}${Number(o.total).toLocaleString()}</td></tr>`).join('')}
        <tr class="total-row"><td colspan="4" style="text-align:right">TOTAL CHARGES</td><td>${APP.currency}${Number(r.total_amount+posCharges).toLocaleString()}</td></tr>
      </tbody>
    </table>
    <h3 style="color:#6C63FF">Payments</h3>
    <table>
      <thead><tr><th>Date</th><th>Method</th><th>Reference</th><th>Amount</th></tr></thead>
      <tbody>
        ${(r.payments||[]).map(p=>`<tr><td>${p.created_at?.split('T')[0]||'-'}</td><td>${p.payment_method}</td><td>${p.reference_number||'-'}</td><td>${APP.currency}${Number(p.amount).toLocaleString()}</td></tr>`).join('')}
        <tr class="total-row"><td colspan="3" style="text-align:right">TOTAL PAID</td><td>${APP.currency}${Number(r.paid_amount||0).toLocaleString()}</td></tr>
        <tr style="font-weight:bold;color:${bal>0?'red':'green'}"><td colspan="3" style="text-align:right">BALANCE DUE</td><td>${APP.currency}${Number(bal).toLocaleString()}</td></tr>
      </tbody>
    </table>
    <p style="font-size:11px;color:#888;text-align:center;margin-top:20px">Thank you for staying with us!</p>
    <script>window.print();</script></body></html>`);
}

function showNewGuestModal() {
  showModal('New Guest', `<div class="space-y-4">
    <div class="grid grid-cols-2 gap-4">
      <div><label class="block text-sm font-medium mb-1">First Name *</label><input id="ng-fn" class="input-field"></div>
      <div><label class="block text-sm font-medium mb-1">Last Name *</label><input id="ng-ln" class="input-field"></div>
      <div><label class="block text-sm font-medium mb-1">Phone</label><input id="ng-phone" class="input-field"></div>
      <div><label class="block text-sm font-medium mb-1">Email</label><input id="ng-email" class="input-field"></div>
      <div><label class="block text-sm font-medium mb-1">ID Type</label><select id="ng-idtype" class="input-field"><option value="">Select</option><option value="passport">Passport</option><option value="national_id">National ID</option><option value="driver_license">Driver's License</option></select></div>
      <div><label class="block text-sm font-medium mb-1">ID Number</label><input id="ng-idnum" class="input-field"></div>
      <div><label class="block text-sm font-medium mb-1">Address</label><input id="ng-addr" class="input-field"></div>
      <div><label class="block text-sm font-medium mb-1">City</label><input id="ng-city" class="input-field"></div>
      <div><label class="block text-sm font-medium mb-1">Country</label><input id="ng-country" class="input-field" value="Nigeria"></div>
      <div><label class="block text-sm font-medium mb-1">Nationality</label><input id="ng-nat" class="input-field" value="Nigerian"></div>
      <div><label class="block text-sm font-medium mb-1">Date of Birth</label><input id="ng-dob" type="text" class="input-field date-picker"></div>
      <div><label class="block text-sm font-medium mb-1">Gender</label><select id="ng-gender" class="input-field"><option value="">Select</option><option value="male">Male</option><option value="female">Female</option></select></div>
    </div>
    <label class="flex items-center gap-2"><input type="checkbox" id="ng-vip" class="rounded"><span class="text-sm font-medium">VIP Guest</span></label>
    <button onclick="createNewGuest()" class="btn btn-primary w-full justify-center">Create Guest</button>
  </div>`, 'lg');
  initDatePickers();
}

async function createNewGuest() {
  const fn=$('#ng-fn').value, ln=$('#ng-ln').value; if (!fn||!ln) return showToast('Name required','error');
  await post('/guests', {first_name:fn,last_name:ln,phone:$('#ng-phone').value,email:$('#ng-email').value,id_type:$('#ng-idtype').value,id_number:$('#ng-idnum').value,nationality:$('#ng-nat').value,address:$('#ng-addr').value,city:$('#ng-city').value,country:$('#ng-country').value,date_of_birth:$('#ng-dob')?.value||'',gender:$('#ng-gender')?.value||'',vip_status:$('#ng-vip').checked});
  closeAllModals(); showToast('Guest created!'); loadGuests();
}

async function showEditGuest(id) {
  const g = await api(`/guests/${id}`);
  closeAllModals();
  showModal('Edit Guest', `<div class="space-y-4">
    <div class="grid grid-cols-2 gap-4">
      <div><label class="block text-sm font-medium mb-1">First Name</label><input id="eg-fn" class="input-field" value="${g.first_name}"></div>
      <div><label class="block text-sm font-medium mb-1">Last Name</label><input id="eg-ln" class="input-field" value="${g.last_name}"></div>
      <div><label class="block text-sm font-medium mb-1">Phone</label><input id="eg-phone" class="input-field" value="${g.phone||''}"></div>
      <div><label class="block text-sm font-medium mb-1">Email</label><input id="eg-email" class="input-field" value="${g.email||''}"></div>
      <div><label class="block text-sm font-medium mb-1">Address</label><input id="eg-addr" class="input-field" value="${g.address||''}"></div>
      <div><label class="block text-sm font-medium mb-1">City</label><input id="eg-city2" class="input-field" value="${g.city||''}"></div>
      <div><label class="block text-sm font-medium mb-1">Country</label><input id="eg-country" class="input-field" value="${g.country||''}"></div>
      <div><label class="block text-sm font-medium mb-1">Nationality</label><input id="eg-nat" class="input-field" value="${g.nationality||''}"></div>
    </div>
    <label class="flex items-center gap-2"><input type="checkbox" id="eg-vip" class="rounded" ${g.vip_status?'checked':''}><span class="text-sm font-medium">VIP</span></label>
    <button onclick="updateGuest(${id})" class="btn btn-primary w-full justify-center">Update</button>
  </div>`);
}
async function updateGuest(id) { await put(`/guests/${id}`, {first_name:$('#eg-fn').value,last_name:$('#eg-ln').value,phone:$('#eg-phone').value,email:$('#eg-email').value,address:$('#eg-addr').value,city:$('#eg-city2').value,country:$('#eg-country').value,nationality:$('#eg-nat').value,vip_status:$('#eg-vip').checked}); closeAllModals(); showToast('Updated!'); loadGuests(); }
async function deleteGuest(id) { if (!await confirmAction('Delete this guest?')) return; await del(`/guests/${id}`); showToast('Deleted'); loadGuests(); }
function exportGuestsPDF() { const d=APP.data.guests||[]; generatePDF('Guest Directory',['Name','Phone','Email','Nationality','VIP','Loyalty'],d.map(g=>[`${g.first_name} ${g.last_name}`,g.phone||'-',g.email||'-',g.nationality||'-',g.vip_status?'Yes':'No',`${g.loyalty_tier||''} ${g.loyalty_points||0}pts`]),{summary:`${d.length} guests`}); }
function exportGuestsCSV() { const d=APP.data.guests||[]; generateCSV('Guest Directory',['First Name','Last Name','Phone','Email','ID Type','ID Number','Nationality','Address','City','Country','VIP','Loyalty Tier','Loyalty Points','Total Stays','Total Spent'],d.map(g=>[g.first_name,g.last_name,g.phone||'',g.email||'',g.id_type||'',g.id_number||'',g.nationality||'',g.address||'',g.city||'',g.country||'',g.vip_status?'Yes':'No',g.loyalty_tier||'bronze',g.loyalty_points||0,g.total_stays||0,g.total_spent||0])); }

// ==================== ROOMS / UNITS (hotel rooms + shortlet apartments) ====================
const COMMON_FEATURES = ['WiFi','Air Conditioning','TV','Kitchenette','Living Room','Balcony','Parking','Hot Water','Washing Machine','Pool Access','Gym Access','Generator/Backup Power','Work Desk','Safe Box','Wardrobe'];

async function renderRooms() {
  const [rooms, types] = await Promise.all([api('/rooms'), api('/room-types')]);
  APP.data.rooms = rooms; APP.data.roomTypes = types;
  const mc = $('#main-content');
  mc.innerHTML = `<div class="fade-in">
    <div class="flex items-center justify-between mb-6 flex-wrap gap-3">
      <div><h2 class="text-2xl font-bold text-gray-800">Rooms &amp; Units</h2><p class="text-gray-500 text-sm">Hotel rooms, suites, or shortlet apartments with features &amp; photos</p></div>
      <div class="flex gap-3"><button onclick="showAddRoomType()" class="btn btn-outline"><i class="fas fa-layer-group"></i> Unit Types</button><button onclick="showAddRoom()" class="btn btn-primary"><i class="fas fa-plus"></i> Add Room/Unit</button></div>
    </div>
    <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">${types.map(t=>{
      const feats = (()=>{try{return JSON.parse(t.features||'[]')}catch{return []}})();
      return `<div class="card p-4 cursor-pointer" onclick="showEditRoomType(${t.id})" style="border-left:4px solid ${t.color}">
      <div class="flex items-center justify-between"><h4 class="font-bold">${t.name}</h4><span class="badge badge-primary">${(t.unit_kind||'room').replace('_',' ')}</span></div>
      <p class="text-primary font-bold">${fmt(t.base_price)}/night</p>
      <p class="text-xs text-gray-400">${t.room_count} units · Max ${t.max_occupancy} guests${t.unit_kind==='apartment'?` · ${t.bedrooms||1}BR/${t.bathrooms||1}BA`:''}</p>
      ${feats.length?`<div class="flex flex-wrap gap-1 mt-2">${feats.slice(0,3).map(f=>`<span class="feature-chip">${f}</span>`).join('')}${feats.length>3?`<span class="feature-chip">+${feats.length-3}</span>`:''}</div>`:''}
    </div>`}).join('')}
    ${types.length===0?'<p class="text-gray-400 col-span-4 text-center py-4">No unit types yet. Create one to get started.</p>':''}</div>
    <div class="card p-5">
      <div class="flex items-center justify-between mb-4 flex-wrap gap-2">
        <div class="flex items-center gap-4 text-xs flex-wrap"><span class="flex items-center gap-1.5"><span class="w-3 h-3 rounded-full bg-primary"></span>Occupied</span><span class="flex items-center gap-1.5"><span class="w-3 h-3 rounded-full bg-success"></span>Available</span><span class="flex items-center gap-1.5"><span class="w-3 h-3 rounded-full bg-warning"></span>Reserved</span><span class="flex items-center gap-1.5"><span class="w-3 h-3 rounded-full bg-gray-400"></span>Maintenance</span></div>
        <div class="flex items-center gap-2">
          <select id="room-filter" class="input-field w-auto text-sm" onchange="filterRG()"><option value="all">All Status</option><option value="available">Available</option><option value="occupied">Occupied</option><option value="reserved">Reserved</option><option value="maintenance">Maintenance</option></select>
          <div class="flex rounded-lg overflow-hidden border border-gray-200">
            <button onclick="roomViewMode='grid';filterRG()" id="rv-grid" class="px-3 py-1.5 text-xs font-medium bg-primary text-white"><i class="fas fa-th"></i></button>
            <button onclick="roomViewMode='cards';filterRG()" id="rv-cards" class="px-3 py-1.5 text-xs font-medium bg-white text-gray-600"><i class="fas fa-images"></i></button>
          </div>
        </div>
      </div>
      <div id="room-grid"></div>
    </div>
  </div>`;
  filterRG();
}

let roomViewMode = 'grid';
function filterRG() {
  const f=$('#room-filter')?.value||'all'; const rooms=APP.data.rooms||[]; const types=APP.data.roomTypes||[];
  const filtered=f==='all'?rooms:rooms.filter(r=>r.status===f);
  const grouped={}; types.forEach(t=>grouped[t.name]={type:t,rooms:[]}); filtered.forEach(r=>{if(grouped[r.type_name])grouped[r.type_name].rooms.push(r);});
  const c=$('#room-grid'); if(!c) return;
  $('#rv-grid')?.classList.toggle('bg-primary', roomViewMode==='grid'); $('#rv-grid')?.classList.toggle('text-white', roomViewMode==='grid'); $('#rv-grid')?.classList.toggle('bg-white', roomViewMode!=='grid'); $('#rv-grid')?.classList.toggle('text-gray-600', roomViewMode!=='grid');
  $('#rv-cards')?.classList.toggle('bg-primary', roomViewMode==='cards'); $('#rv-cards')?.classList.toggle('text-white', roomViewMode==='cards'); $('#rv-cards')?.classList.toggle('bg-white', roomViewMode!=='cards'); $('#rv-cards')?.classList.toggle('text-gray-600', roomViewMode!=='cards');

  if (roomViewMode === 'grid') {
    c.innerHTML = Object.entries(grouped).map(([name,data])=>`<div class="mb-4"><div class="flex items-center gap-3 mb-2"><div class="w-3 h-3 rounded-full" style="background:${data.type.color}"></div><h4 class="font-semibold text-gray-700">${name}</h4><span class="text-xs text-gray-400">(${data.rooms.length})</span></div><div class="flex flex-wrap gap-2">${data.rooms.map(r=>`<button onclick="showRoomActions(${r.id})" class="room-pill ${r.status}">${r.room_number}</button>`).join('')}${data.rooms.length===0?'<span class="text-xs text-gray-400">None</span>':''}</div></div>`).join('');
  } else {
    c.innerHTML = Object.entries(grouped).map(([name,data])=>`<div class="mb-6"><div class="flex items-center gap-3 mb-3"><div class="w-3 h-3 rounded-full" style="background:${data.type.color}"></div><h4 class="font-semibold text-gray-700">${name}</h4><span class="text-xs text-gray-400">(${data.rooms.length})</span></div>
    <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">${data.rooms.map(r=>`<div class="card p-3 cursor-pointer" onclick="showRoomActions(${r.id})">
      ${r.primary_image?`<img src="${r.primary_image}" class="room-thumb mb-2">`:`<div class="room-thumb mb-2 flex items-center justify-center text-gray-300"><i class="fas fa-image text-2xl"></i></div>`}
      <div class="flex items-center justify-between"><span class="font-bold text-sm">${r.room_number}</span><span class="badge ${r.status==='occupied'?'badge-primary':r.status==='available'?'badge-success':r.status==='reserved'?'badge-warning':'badge-danger'}">${r.status}</span></div>
      <p class="text-xs text-gray-400 mt-0.5">Floor ${r.floor}</p>
    </div>`).join('')}${data.rooms.length===0?'<p class="text-xs text-gray-400 col-span-full">None</p>':''}</div></div>`).join('');
  }
}

async function showRoomActions(roomId) {
  const room = await api(`/rooms/${roomId}`);
  const types = APP.data.roomTypes||[];
  const ownFeatures = (()=>{try{return JSON.parse(room.features||'[]')}catch{return []}})();
  const typeFeatures = (()=>{try{return JSON.parse(room.type_features||'[]')}catch{return []}})();
  const allFeatures = [...new Set([...typeFeatures, ...ownFeatures])];
  const images = room.images||[];
  showModal(`${room.unit_kind==='apartment'?'Apartment':'Room'} ${room.room_number}`, `<div class="space-y-5">
    <div class="grid grid-cols-2 md:grid-cols-4 gap-3">
      <div class="p-3 bg-gray-50 rounded-xl"><p class="text-xs text-gray-500">Type</p><p class="font-semibold text-sm">${room.type_name}</p></div>
      <div class="p-3 bg-gray-50 rounded-xl"><p class="text-xs text-gray-500">Status</p><p class="font-semibold text-sm capitalize">${room.status}</p></div>
      <div class="p-3 bg-gray-50 rounded-xl"><p class="text-xs text-gray-500">Floor</p><p class="font-semibold text-sm">${room.floor}</p></div>
      <div class="p-3 bg-primary/5 rounded-xl"><p class="text-xs text-gray-500">Rate</p><p class="font-semibold text-sm">${fmt(room.base_price)}/night</p></div>
    </div>
    ${room.unit_kind==='apartment'?`<div class="flex gap-4 text-sm text-gray-600"><span><i class="fas fa-bed text-primary mr-1"></i> ${room.type_bedrooms||1} Bedroom(s)</span><span><i class="fas fa-bath text-primary mr-1"></i> ${room.type_bathrooms||1} Bathroom(s)</span></div>`:''}
    ${allFeatures.length?`<div><p class="text-xs font-medium text-gray-500 mb-2">Features</p><div class="flex flex-wrap gap-1.5">${allFeatures.map(f=>`<span class="feature-chip"><i class="fas fa-check"></i> ${f}</span>`).join('')}</div></div>`:''}
    ${room.description?`<div><p class="text-xs font-medium text-gray-500 mb-1">Description</p><p class="text-sm text-gray-700">${room.description}</p></div>`:''}

    <div>
      <p class="text-xs font-medium text-gray-500 mb-2">Photos</p>
      <div class="grid grid-cols-3 md:grid-cols-4 gap-2 mb-2" id="room-img-gallery">
        ${images.map(img=>`<div class="relative group">
          <img src="${img.image_url}" class="room-thumb" style="height:80px">
          ${img.is_primary?'<span class="absolute top-1 left-1 badge badge-primary" style="font-size:9px;padding:2px 6px">PRIMARY</span>':`<button onclick="setPrimaryImage(${room.id},${img.id})" class="absolute top-1 left-1 bg-white/90 rounded px-1.5 py-0.5 text-[9px] font-semibold opacity-0 group-hover:opacity-100">Set Primary</button>`}
          <button onclick="deleteRoomImage(${room.id},${img.id})" class="absolute top-1 right-1 w-5 h-5 rounded-full bg-red-500 text-white text-[10px] flex items-center justify-center opacity-0 group-hover:opacity-100"><i class="fas fa-times"></i></button>
        </div>`).join('')}
      </div>
      <div class="img-upload-drop" onclick="document.getElementById('room-img-input').click()">
        <input type="file" id="room-img-input" accept="image/*" class="hidden" onchange="uploadRoomImage(${room.id}, this)">
        <i class="fas fa-cloud-upload-alt text-2xl text-gray-400 mb-1"></i>
        <p class="text-xs text-gray-500">Click to upload a photo</p>
      </div>
    </div>

    <div class="border-t pt-4 space-y-3">
      <p class="text-xs font-medium text-gray-500">Edit Unit</p>
      <div class="grid grid-cols-2 gap-3">
        <div><label class="block text-xs font-medium mb-1">Room/Unit Number</label><input id="ra-num" class="input-field" value="${room.room_number}"></div>
        <div><label class="block text-xs font-medium mb-1">Type</label><select id="ra-type" class="input-field">${types.map(t=>`<option value="${t.id}" ${t.id===room.room_type_id?'selected':''}>${t.name}</option>`).join('')}</select></div>
        <div><label class="block text-xs font-medium mb-1">Floor</label><input id="ra-floor" type="number" class="input-field" value="${room.floor}"></div>
        <div><label class="block text-xs font-medium mb-1">Status</label><select id="ra-status" class="input-field"><option value="available" ${room.status==='available'?'selected':''}>Available</option><option value="occupied" ${room.status==='occupied'?'selected':''}>Occupied</option><option value="reserved" ${room.status==='reserved'?'selected':''}>Reserved</option><option value="maintenance" ${room.status==='maintenance'?'selected':''}>Maintenance</option></select></div>
      </div>
      <div><label class="block text-xs font-medium mb-1">Description</label><textarea id="ra-desc" class="input-field" rows="2">${room.description||''}</textarea></div>
      <div><label class="block text-xs font-medium mb-1">Unit-specific Features</label>
        <div class="flex flex-wrap gap-2 p-2 border rounded-xl">${COMMON_FEATURES.map(f=>`<label class="flex items-center gap-1 text-xs"><input type="checkbox" class="ra-feature" value="${f}" ${ownFeatures.includes(f)?'checked':''}> ${f}</label>`).join('')}</div>
      </div>
    </div>

    <div class="border-t pt-4">
      <div class="flex items-center justify-between mb-2">
        <p class="text-xs font-medium text-gray-500"><i class="fas fa-satellite-dish text-primary mr-1"></i> Room iCal Sync</p>
        <button onclick="showAddRoomIcalFeed(${room.id})" class="btn btn-outline btn-sm"><i class="fas fa-plus"></i> Add Feed</button>
      </div>
      <div id="room-ical-list"><div class="text-xs text-gray-400 py-2">Loading feeds...</div></div>
    </div>

    <div class="flex gap-3"><button onclick="updateRoomFull(${room.id})" class="btn btn-primary flex-1 justify-center"><i class="fas fa-save"></i> Save Changes</button><button onclick="deleteRoom(${room.id})" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></button></div>
  </div>`, 'lg');
  loadRoomIcalFeeds(room.id);
}

// ---- Per-room iCal feeds (independent of hotel-wide Channel Manager connections) ----
async function loadRoomIcalFeeds(roomId) {
  const feeds = await api(`/room-ical/room/${roomId}`).catch(() => []);
  APP.data.roomIcalFeeds = feeds;
  const c = $('#room-ical-list'); if (!c) return;
  if (feeds.length === 0) { c.innerHTML = "<p class=\"text-xs text-gray-400 py-2\">No iCal feeds yet. Add one to auto-import bookings from an OTA, or export this room's availability.</p>"; return; }
  c.innerHTML = feeds.map(f => `<div class="flex items-center justify-between p-2.5 bg-gray-50 rounded-xl mb-2">
    <div class="flex items-center gap-2 min-w-0">
      <div class="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0"><i class="fas fa-calendar-alt text-primary text-xs"></i></div>
      <div class="min-w-0"><p class="text-xs font-semibold truncate">${f.label || f.source_name}</p><p class="text-[10px] text-gray-400">${f.last_sync_at ? 'Synced ' + fmtDateTime(f.last_sync_at) : 'Never synced'}</p></div>
    </div>
    <div class="flex items-center gap-1 flex-shrink-0">
      <span class="badge ${f.status==='connected'?'badge-success':f.status==='error'?'badge-danger':'badge-warning'}" style="font-size:9px;padding:2px 8px">${f.status}</span>
      <button onclick="syncRoomIcalFeed(${f.id}, ${roomId})" class="btn btn-outline btn-sm" title="Sync now"><i class="fas fa-sync"></i></button>
      <button onclick="showExportRoomIcal(${f.id})" class="btn btn-outline btn-sm" title="Export URL"><i class="fas fa-link"></i></button>
      <button onclick="deleteRoomIcalFeed(${f.id}, ${roomId})" class="btn btn-danger btn-sm" title="Remove"><i class="fas fa-trash"></i></button>
    </div>
  </div>`).join('');
}
function showAddRoomIcalFeed(roomId) {
  showModal('Add Room iCal Feed', `<div class="space-y-4">
    <p class="text-xs text-gray-500">Paste this room/unit's OTA iCal export URL (e.g. from Booking.com or Airbnb listing calendar settings) so PCH PMS can automatically pull new, modified and cancelled bookings for this specific room.</p>
    <div><label class="block text-sm font-medium mb-1">Source</label><select id="rif-source" class="input-field"><option>Booking.com</option><option>Airbnb</option><option>Expedia</option><option>Agoda</option><option>Vrbo</option><option>Other</option></select></div>
    <div><label class="block text-sm font-medium mb-1">Label</label><input id="rif-label" class="input-field" placeholder="e.g. Main Airbnb listing"></div>
    <div><label class="block text-sm font-medium mb-1">iCal Import URL</label><input id="rif-url" class="input-field" placeholder="https://.../calendar.ics"></div>
    <p class="text-xs text-gray-400">Leave the URL blank to add the feed now and paste the link in later — you can also add it manually any time.</p>
    <button onclick="createRoomIcalFeed(${roomId})" class="btn btn-primary w-full justify-center"><i class="fas fa-plus"></i> Add Feed</button>
  </div>`, 'md');
}
async function createRoomIcalFeed(roomId) {
  await post('/room-ical', { room_id: roomId, source_name: $('#rif-source').value, label: $('#rif-label').value, import_url: $('#rif-url').value, created_by: APP.user.id });
  closeAllModals(); showToast('iCal feed added!'); showRoomActions(roomId);
}
async function syncRoomIcalFeed(feedId, roomId) {
  showToast('Syncing room calendar...', 'warning');
  const r = await post(`/room-ical/${feedId}/sync`, {});
  showToast(r.success ? `Synced: ${r.created} new, ${r.updated} updated, ${r.cancelled} cancelled` : `Sync issue: ${r.message}`, r.success ? 'success' : 'warning');
  loadRoomIcalFeeds(roomId);
}
async function deleteRoomIcalFeed(feedId, roomId) {
  if (!await confirmAction('Remove this iCal feed?')) return;
  await del(`/room-ical/${feedId}`); showToast('Feed removed'); loadRoomIcalFeeds(roomId);
}
function showExportRoomIcal(feedId) {
  const url = `${location.origin}/api/room-ical/${feedId}/export.ics`;
  showModal('Export This Room (iCal)', `<div class="space-y-3">
    <p class="text-sm text-gray-500">Paste this URL into the OTA's "import calendar" field so it always sees this room's live availability:</p>
    <input class="input-field" readonly value="${url}" onclick="this.select()">
    <button onclick="navigator.clipboard.writeText('${url}');showToast('Copied!')" class="btn btn-primary w-full justify-center"><i class="fas fa-copy"></i> Copy Link</button>
  </div>`, 'md');
}

async function updateRoomFull(id) {
  const features = Array.from(document.querySelectorAll('.ra-feature:checked')).map(el=>el.value);
  await put(`/rooms/${id}`, {
    room_number: $('#ra-num').value, room_type_id: parseInt($('#ra-type').value), floor: parseInt($('#ra-floor').value)||1,
    status: $('#ra-status').value, description: $('#ra-desc').value, features
  });
  closeAllModals(); showToast('Room updated!'); renderRooms();
}

async function uploadRoomImage(roomId, input) {
  const file = input.files[0]; if (!file) return;
  const fd = new FormData(); fd.append('file', file);
  try {
    const headers = {}; if (APP.hotelId) headers['X-Hotel-Id'] = APP.hotelId;
    const r = await fetch(`/api/rooms/${roomId}/images`, { method: 'POST', headers, body: fd });
    const d = await r.json();
    if (!r.ok) throw new Error(d.error || 'Upload failed');
    showToast('Photo uploaded!');
    showRoomActions(roomId);
  } catch (e) { showToast(e.message, 'error'); }
}
async function setPrimaryImage(roomId, imageId) { await put(`/rooms/${roomId}/images/${imageId}/primary`, {}); showRoomActions(roomId); }
async function deleteRoomImage(roomId, imageId) { if (!await confirmAction('Remove this photo?')) return; await del(`/rooms/${roomId}/images/${imageId}`); showRoomActions(roomId); }

function showAddRoom() {
  const types = APP.data.roomTypes||[];
  showModal('Add Room / Unit', `<div class="space-y-4"><div class="grid grid-cols-2 gap-4">
    <div><label class="block text-sm font-medium mb-1">Room/Unit Number *</label><input id="ar-num" class="input-field" placeholder="e.g. 101 or Apt-A"></div>
    <div><label class="block text-sm font-medium mb-1">Type *</label><select id="ar-type" class="input-field">${types.map(t=>`<option value="${t.id}">${t.name} (${t.unit_kind||'room'})</option>`).join('')}</select></div>
    <div><label class="block text-sm font-medium mb-1">Floor</label><input id="ar-floor" type="number" class="input-field" value="1"></div>
  </div>
  <div><label class="block text-sm font-medium mb-1">Description</label><textarea id="ar-desc" class="input-field" rows="2" placeholder="Short description of this unit"></textarea></div>
  <div><label class="block text-sm font-medium mb-1">Features</label><div class="flex flex-wrap gap-2 p-2 border rounded-xl">${COMMON_FEATURES.map(f=>`<label class="flex items-center gap-1 text-xs"><input type="checkbox" class="arf-feature" value="${f}"> ${f}</label>`).join('')}</div></div>
  <button onclick="createRoom()" class="btn btn-primary w-full justify-center">Add</button></div>`, 'md');
  if (types.length===0) showToast('Create a unit type first', 'warning');
}
async function createRoom() {
  if(!$('#ar-num').value) return showToast('Number required','error');
  const features = Array.from(document.querySelectorAll('.arf-feature:checked')).map(el=>el.value);
  await post('/rooms',{room_number:$('#ar-num').value,room_type_id:parseInt($('#ar-type').value),floor:parseInt($('#ar-floor').value)||1,description:$('#ar-desc').value,features});
  closeAllModals(); showToast('Added!'); renderRooms();
}
async function deleteRoom(id) { if(!await confirmAction('Delete this room? This also removes its photos.')) return; await del(`/rooms/${id}`); closeAllModals(); showToast('Removed'); renderRooms(); }

function showAddRoomType() {
  showModal('Add Unit Type', `<div class="space-y-4">
    <div class="grid grid-cols-2 gap-4">
      <div><label class="block text-sm font-medium mb-1">Name *</label><input id="rt-name" class="input-field" placeholder="e.g. Deluxe Room, 2-Bed Apartment"></div>
      <div><label class="block text-sm font-medium mb-1">Kind</label><select id="rt-kind" class="input-field" onchange="toggleAptFields('rt')"><option value="room">Hotel Room</option><option value="studio">Studio</option><option value="apartment">Shortlet Apartment</option><option value="suite">Suite</option></select></div>
      <div><label class="block text-sm font-medium mb-1">Price/night *</label><input id="rt-price" type="number" class="input-field"></div>
      <div><label class="block text-sm font-medium mb-1">Max Occupancy</label><input id="rt-occ" type="number" class="input-field" value="2"></div>
      <div id="rt-apt-fields" class="hidden contents">
        <div><label class="block text-sm font-medium mb-1">Bedrooms</label><input id="rt-bed" type="number" class="input-field" value="1"></div>
        <div><label class="block text-sm font-medium mb-1">Bathrooms</label><input id="rt-bath" type="number" class="input-field" value="1"></div>
      </div>
      <div><label class="block text-sm font-medium mb-1">Color</label><input id="rt-color" type="color" class="input-field h-[42px]" value="#6C63FF"></div>
    </div>
    <div><label class="block text-sm font-medium mb-1">Description</label><textarea id="rt-desc" class="input-field" rows="2"></textarea></div>
    <div><label class="block text-sm font-medium mb-1">Default Features (applies to all units of this type)</label><div class="flex flex-wrap gap-2 p-2 border rounded-xl">${COMMON_FEATURES.map(f=>`<label class="flex items-center gap-1 text-xs"><input type="checkbox" class="rtf-feature" value="${f}"> ${f}</label>`).join('')}</div></div>
    <button onclick="createRoomType()" class="btn btn-primary w-full justify-center">Create</button></div>`,'lg');
}
function toggleAptFields(prefix) {
  const kind = $(`#${prefix}-kind`)?.value;
  const fields = $(`#${prefix}-apt-fields`);
  if (fields) fields.classList.toggle('hidden', kind !== 'apartment');
}
async function createRoomType() {
  if(!$('#rt-name').value) return showToast('Name required','error');
  const features = Array.from(document.querySelectorAll('.rtf-feature:checked')).map(el=>el.value);
  await post('/room-types',{
    name:$('#rt-name').value, base_price:parseFloat($('#rt-price').value)||0, max_occupancy:parseInt($('#rt-occ').value)||2,
    color:$('#rt-color').value, unit_kind:$('#rt-kind').value, bedrooms:parseInt($('#rt-bed')?.value)||1, bathrooms:parseInt($('#rt-bath')?.value)||1,
    description:$('#rt-desc').value, features
  });
  closeAllModals(); showToast('Unit type created!'); renderRooms();
}
async function showEditRoomType(id) {
  const t=(APP.data.roomTypes||[]).find(x=>x.id===id); if(!t)return;
  const existingFeatures = (()=>{try{return JSON.parse(t.features||'[]')}catch{return []}})();
  showModal('Edit Unit Type',`<div class="space-y-4">
    <div class="grid grid-cols-2 gap-4">
      <div><label class="block text-sm font-medium mb-1">Name</label><input id="ert-name" class="input-field" value="${t.name}"></div>
      <div><label class="block text-sm font-medium mb-1">Kind</label><select id="ert-kind" class="input-field" onchange="toggleAptFields('ert')">
        <option value="room" ${t.unit_kind==='room'?'selected':''}>Hotel Room</option>
        <option value="studio" ${t.unit_kind==='studio'?'selected':''}>Studio</option>
        <option value="apartment" ${t.unit_kind==='apartment'?'selected':''}>Shortlet Apartment</option>
        <option value="suite" ${t.unit_kind==='suite'?'selected':''}>Suite</option></select></div>
      <div><label class="block text-sm font-medium mb-1">Price</label><input id="ert-price" type="number" class="input-field" value="${t.base_price}"></div>
      <div><label class="block text-sm font-medium mb-1">Max Occ.</label><input id="ert-occ" type="number" class="input-field" value="${t.max_occupancy}"></div>
      <div id="ert-apt-fields" class="${t.unit_kind==='apartment'?'':'hidden'} contents">
        <div><label class="block text-sm font-medium mb-1">Bedrooms</label><input id="ert-bed" type="number" class="input-field" value="${t.bedrooms||1}"></div>
        <div><label class="block text-sm font-medium mb-1">Bathrooms</label><input id="ert-bath" type="number" class="input-field" value="${t.bathrooms||1}"></div>
      </div>
      <div><label class="block text-sm font-medium mb-1">Color</label><input id="ert-color" type="color" class="input-field h-[42px]" value="${t.color}"></div>
    </div>
    <div><label class="block text-sm font-medium mb-1">Description</label><textarea id="ert-desc" class="input-field" rows="2">${t.description||''}</textarea></div>
    <div><label class="block text-sm font-medium mb-1">Default Features</label><div class="flex flex-wrap gap-2 p-2 border rounded-xl">${COMMON_FEATURES.map(f=>`<label class="flex items-center gap-1 text-xs"><input type="checkbox" class="ertf-feature" value="${f}" ${existingFeatures.includes(f)?'checked':''}> ${f}</label>`).join('')}</div></div>
    <div class="flex gap-3"><button onclick="updateRoomType(${t.id})" class="btn btn-primary flex-1 justify-center">Update</button><button onclick="deleteRoomType(${t.id})" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></button></div></div>`,'lg');
}
async function updateRoomType(id) {
  const features = Array.from(document.querySelectorAll('.ertf-feature:checked')).map(el=>el.value);
  await put(`/room-types/${id}`,{
    name:$('#ert-name').value, base_price:parseFloat($('#ert-price').value), max_occupancy:parseInt($('#ert-occ').value),
    color:$('#ert-color').value, unit_kind:$('#ert-kind').value, bedrooms:parseInt($('#ert-bed')?.value)||1, bathrooms:parseInt($('#ert-bath')?.value)||1,
    description:$('#ert-desc').value, features
  });
  closeAllModals(); showToast('Updated!'); renderRooms();
}
async function deleteRoomType(id) { if(!await confirmAction('Delete type?')) return; await del(`/room-types/${id}`); closeAllModals(); showToast('Removed'); renderRooms(); }

// ==================== HOUSEKEEPING ====================
async function renderHousekeeping() {
  const tasks = await api('/housekeeping');
  const mc = $('#main-content');
  mc.innerHTML = `<div class="fade-in">
    <div class="flex items-center justify-between mb-6">
      <div><h2 class="text-2xl font-bold text-gray-800">Housekeeping</h2></div>
      <div class="flex gap-2">${exportBtns('exportHKPDF','exportHKCSV')}${!isHousekeeping()?`<button onclick="showNewHKTask()" class="btn btn-primary"><i class="fas fa-plus"></i> New Task</button>`:''}</div>
    </div>
    <div class="grid grid-cols-4 gap-4 mb-6">
      <div class="stat-card"><p class="text-2xl font-bold">${tasks.filter(t=>t.status==='pending').length}</p><p class="text-xs text-gray-500">Pending</p></div>
      <div class="stat-card"><p class="text-2xl font-bold text-blue-500">${tasks.filter(t=>t.status==='in-progress').length}</p><p class="text-xs text-gray-500">In Progress</p></div>
      <div class="stat-card"><p class="text-2xl font-bold text-green-500">${tasks.filter(t=>t.status==='completed').length}</p><p class="text-xs text-gray-500">Completed</p></div>
      <div class="stat-card"><p class="text-2xl font-bold text-red-500">${tasks.filter(t=>t.priority==='high'||t.priority==='urgent').length}</p><p class="text-xs text-gray-500">High Priority</p></div>
    </div>
    <div class="card p-5"><table class="w-full"><thead><tr class="text-left text-xs text-gray-500 border-b"><th class="pb-3">ROOM</th><th class="pb-3">TASK</th><th class="pb-3">PRIORITY</th><th class="pb-3">ASSIGNED</th><th class="pb-3">STATUS</th><th class="pb-3">ACTIONS</th></tr></thead>
    <tbody>${tasks.map(t=>`<tr class="table-row border-b border-gray-50">
      <td class="py-3 text-sm font-medium">${t.room_number}</td>
      <td class="py-3 text-sm capitalize">${t.task_type}</td>
      <td class="py-3"><span class="badge ${t.priority==='high'||t.priority==='urgent'?'badge-danger':'badge-warning'}">${t.priority}</span></td>
      <td class="py-3 text-sm">${t.assigned_to_name||'Unassigned'}</td>
      <td class="py-3"><span class="badge ${t.status==='completed'?'badge-success':t.status==='in-progress'?'badge-info':'badge-warning'}">${t.status}</span></td>
      <td class="py-3 flex gap-1">
        ${t.status!=='completed'?`<button onclick="updateHKStatus(${t.id},'in-progress')" class="btn btn-outline btn-sm"><i class="fas fa-play"></i></button><button onclick="updateHKStatus(${t.id},'completed')" class="btn btn-success btn-sm"><i class="fas fa-check"></i></button>`:''}
        ${!isHousekeeping()?`<button onclick="deleteHKTask(${t.id})" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></button>`:''}
      </td>
    </tr>`).join('')}</tbody></table>${tasks.length===0?'<p class="text-center py-8 text-gray-400">No tasks</p>':''}</div>
  </div>`;
}
async function showNewHKTask() {
  const [rooms,users] = await Promise.all([api('/rooms'),api('/users')]);
  const hkStaff = users.filter(u=>u.role==='housekeeping'||u.role==='admin'||u.role==='manager');
  showModal('New Task',`<div class="space-y-4"><div class="grid grid-cols-2 gap-4"><div><label class="block text-sm font-medium mb-1">Room *</label><select id="hk-room" class="input-field">${rooms.map(r=>`<option value="${r.id}">${r.room_number} (${r.type_name})</option>`).join('')}</select></div><div><label class="block text-sm font-medium mb-1">Type</label><select id="hk-type" class="input-field"><option value="cleaning">Cleaning</option><option value="turndown">Turndown</option><option value="maintenance">Maintenance</option><option value="deep_clean">Deep Clean</option></select></div><div><label class="block text-sm font-medium mb-1">Priority</label><select id="hk-priority" class="input-field"><option value="normal">Normal</option><option value="high">High</option><option value="urgent">Urgent</option></select></div><div><label class="block text-sm font-medium mb-1">Assign</label><select id="hk-assign" class="input-field"><option value="">Unassigned</option>${hkStaff.map(u=>`<option value="${u.id}">${u.full_name}</option>`).join('')}</select></div></div><div><label class="block text-sm font-medium mb-1">Notes</label><textarea id="hk-notes" class="input-field" rows="2"></textarea></div><button onclick="createHKTask()" class="btn btn-primary w-full justify-center">Create</button></div>`,'md');
}
async function createHKTask() { await post('/housekeeping',{room_id:parseInt($('#hk-room').value),task_type:$('#hk-type').value,priority:$('#hk-priority').value,assigned_to:$('#hk-assign').value?parseInt($('#hk-assign').value):null,notes:$('#hk-notes').value}); closeAllModals(); showToast('Created!'); renderHousekeeping(); }
async function updateHKStatus(id,status) { await put(`/housekeeping/${id}`,{status}); showToast(status==='completed'?'Completed!':'Started!'); renderHousekeeping(); }
async function deleteHKTask(id) { if(!await confirmAction('Delete task?')) return; await del(`/housekeeping/${id}`); showToast('Deleted'); renderHousekeeping(); }
async function exportHKPDF() { const d=await api('/housekeeping'); generatePDF('Housekeeping Tasks',['Room','Task','Priority','Assigned','Status'],d.map(t=>[t.room_number,t.task_type,t.priority,t.assigned_to_name||'Unassigned',t.status]),{summary:`${d.length} tasks`}); }
async function exportHKCSV() { const d=await api('/housekeeping'); generateCSV('Housekeeping Tasks',['Room','Task Type','Priority','Assigned To','Status','Notes','Created At'],d.map(t=>[t.room_number,t.task_type,t.priority,t.assigned_to_name||'',t.status,t.notes||'',t.created_at])); }

// ==================== PAYMENTS ====================
async function renderPayments() {
  const mc = $('#main-content');
  mc.innerHTML = `<div class="fade-in"><div class="flex items-center justify-between mb-6"><div><h2 class="text-2xl font-bold text-gray-800">Payments</h2></div><button onclick="showAddPayment()" class="btn btn-primary"><i class="fas fa-plus"></i> Add</button></div>
    <div class="card p-5"><div class="flex items-center gap-3 mb-5"><input type="text" id="pay-from" class="input-field w-auto date-picker" placeholder="From"><input type="text" id="pay-to" class="input-field w-auto date-picker" placeholder="To"><button onclick="loadPayments()" class="btn btn-outline btn-sm"><i class="fas fa-filter"></i></button><div class="flex gap-2 ml-auto">${exportBtns('exportPaymentsPDF','exportPaymentsCSV')}</div></div><div id="payments-table"></div></div></div>`;
  initDatePickers(); loadPayments();
}
async function loadPayments() {
  const from=$('#pay-from')?.value||'', to=$('#pay-to')?.value||'';
  let url='/payments?'; if(from)url+=`from=${from}&`; if(to)url+=`to=${to}`;
  const data=await api(url); APP.data.payments=data;
  const c=$('#payments-table'); if(!c) return;
  const total=data.reduce((s,p)=>s+(p.amount||0),0);
  c.innerHTML=`<div class="mb-4 p-4 bg-primary/5 rounded-xl flex items-center justify-between"><span class="font-medium">Total</span><span class="text-xl font-bold text-primary">${fmt(total)}</span></div>
  <table class="w-full"><thead><tr class="text-left text-xs text-gray-500 border-b"><th class="pb-3">DATE</th><th class="pb-3">GUEST</th><th class="pb-3">RESERVATION</th><th class="pb-3">AMOUNT</th><th class="pb-3">METHOD</th><th class="pb-3">TYPE</th></tr></thead>
  <tbody>${data.map(p=>`<tr class="table-row border-b border-gray-50"><td class="py-3 text-sm">${fmtDateTime(p.created_at)}</td><td class="py-3 text-sm font-medium">${p.first_name?p.first_name+' '+p.last_name:'-'}</td><td class="py-3 text-sm font-mono text-primary">${p.reservation_code||'-'}</td><td class="py-3 text-sm font-bold">${fmt(p.amount)}</td><td class="py-3"><span class="badge ${p.payment_method==='cash'?'badge-success':p.payment_method==='card'?'badge-info':'badge-primary'}">${p.payment_method}</span></td><td class="py-3 text-sm capitalize">${(p.payment_type||'').replace('_',' ')}</td></tr>`).join('')}</tbody></table>${data.length===0?'<p class="text-center py-8 text-gray-400">No payments</p>':''}`;
}

async function showAddPayment() {
  const res=await api('/reservations?status=checked-in'); const shift=await api('/shifts/current');
  showModal('Add Payment',`<div class="space-y-4"><div><label class="block text-sm font-medium mb-1">Reservation</label><select id="ap-res" class="input-field"><option value="">Select</option>${res.map(r=>`<option value="${r.id}" data-guest="${r.guest_id}">${r.reservation_code} - ${r.first_name} ${r.last_name} (${r.room_number||''})</option>`).join('')}</select></div>
  <div class="grid grid-cols-2 gap-4"><div><label class="block text-sm font-medium mb-1">Amount *</label><input id="ap-amount" type="number" class="input-field"></div><div><label class="block text-sm font-medium mb-1">Method</label><select id="ap-method" class="input-field"><option value="cash">Cash</option><option value="card">Card</option><option value="transfer">Transfer</option></select></div></div>
  <div><label class="block text-sm font-medium mb-1">Type</label><select id="ap-type" class="input-field"><option value="room_charge">Room Charge</option><option value="deposit">Deposit</option><option value="extras">Extras</option><option value="restaurant">Restaurant</option></select></div>
  <div><label class="block text-sm font-medium mb-1">Notes</label><textarea id="ap-notes" class="input-field" rows="2"></textarea></div>
  <button onclick="createPayment(${shift?.id||'null'})" class="btn btn-primary w-full justify-center">Record Payment</button></div>`,'md');
}
async function createPayment(shiftId) {
  const resOpt=$('#ap-res'); const resId=resOpt?.value?parseInt(resOpt.value):null; const guestId=resOpt?.selectedOptions[0]?.dataset.guest?parseInt(resOpt.selectedOptions[0].dataset.guest):null;
  const amount=parseFloat($('#ap-amount').value); if(!amount) return showToast('Amount required','error');
  await post('/payments',{reservation_id:resId,guest_id:guestId,amount,payment_method:$('#ap-method').value,payment_type:$('#ap-type')?.value||'room_charge',notes:$('#ap-notes').value,shift_id:shiftId,received_by:APP.user.id});
  closeAllModals(); showToast('Recorded!'); if(APP.currentPage==='payments')loadPayments();
}
async function showAddPaymentForRes(resId,guestId) {
  closeAllModals(); const shift=await api('/shifts/current');
  showModal('Add Payment',`<div class="space-y-4"><div class="grid grid-cols-2 gap-4"><div><label class="block text-sm font-medium mb-1">Amount *</label><input id="ap-amount" type="number" class="input-field"></div><div><label class="block text-sm font-medium mb-1">Method</label><select id="ap-method" class="input-field"><option value="cash">Cash</option><option value="card">Card</option><option value="transfer">Transfer</option></select></div></div><div><label class="block text-sm font-medium mb-1">Notes</label><textarea id="ap-notes" class="input-field" rows="2"></textarea></div>
  <button onclick="createPaymentDirect(${resId},${guestId},${shift?.id||'null'})" class="btn btn-primary w-full justify-center">Record</button></div>`,'sm');
}
async function createPaymentDirect(resId,guestId,shiftId) { const amount=parseFloat($('#ap-amount').value); if(!amount)return showToast('Amount required','error'); await post('/payments',{reservation_id:resId,guest_id:guestId,amount,payment_method:$('#ap-method').value,payment_type:'room_charge',notes:$('#ap-notes').value,shift_id:shiftId,received_by:APP.user.id}); closeAllModals(); showToast('Recorded!'); }
function exportPaymentsPDF() { const d=APP.data.payments||[]; const total=d.reduce((s,p)=>s+(p.amount||0),0); generatePDF('Payments Report',['Date','Guest','Reservation','Amount','Method'],d.map(p=>[fmtDateTime(p.created_at),p.first_name?`${p.first_name} ${p.last_name}`:'-',p.reservation_code||'-',fmt(p.amount),p.payment_method]),{summary:`Total: ${fmt(total)} · ${d.length} transactions`}); }
function exportPaymentsCSV() { const d=APP.data.payments||[]; generateCSV('Payments Report',['Date','Guest','Reservation','Amount','Method','Type','Reference'],d.map(p=>[p.created_at,p.first_name?`${p.first_name} ${p.last_name}`:'',p.reservation_code||'',p.amount,p.payment_method,p.payment_type||'',p.reference_number||''])); }

// ==================== INVOICES ====================
async function renderInvoices() {
  const invoices=await api('/invoices'); const mc=$('#main-content');
  mc.innerHTML=`<div class="fade-in"><div class="flex items-center justify-between mb-6"><div><h2 class="text-2xl font-bold text-gray-800">Invoices</h2></div><div class="flex gap-2">${exportBtns('exportInvoicesPDF','exportInvoicesCSV')}<button onclick="showNewInvoice()" class="btn btn-primary"><i class="fas fa-plus"></i> New Invoice</button></div></div>
  <div class="card p-5"><table class="w-full"><thead><tr class="text-left text-xs text-gray-500 border-b"><th class="pb-3">INVOICE #</th><th class="pb-3">GUEST</th><th class="pb-3">TOTAL</th><th class="pb-3">PAID</th><th class="pb-3">BALANCE</th><th class="pb-3">STATUS</th><th class="pb-3">ACTIONS</th></tr></thead>
  <tbody>${invoices.map(i=>`<tr class="table-row border-b border-gray-50">
    <td class="py-3 text-sm font-mono text-primary cursor-pointer" onclick="showInvoiceDetail(${i.id})">${i.invoice_number}</td>
    <td class="py-3 text-sm">${i.first_name} ${i.last_name}</td>
    <td class="py-3 text-sm font-bold">${fmt(i.total_amount)}</td>
    <td class="py-3 text-sm text-green-600">${fmt(i.amount_paid)}</td>
    <td class="py-3 text-sm ${i.balance_due>0?'text-red-500':'text-green-500'}">${fmt(i.balance_due)}</td>
    <td class="py-3"><span class="badge ${i.status==='paid'?'badge-success':'badge-warning'}">${i.status}</span></td>
    <td class="py-3 flex gap-1"><button onclick="downloadInvoicePDF(${i.id})" class="btn btn-outline btn-sm"><i class="fas fa-download"></i></button><button onclick="deleteInvoice(${i.id})" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></button></td>
  </tr>`).join('')}</tbody></table>${invoices.length===0?'<p class="text-center py-8 text-gray-400">No invoices</p>':''}</div></div>`;
}

async function showInvoiceDetail(id) {
  const inv=await api(`/invoices/${id}`); const items=typeof inv.items==='string'?JSON.parse(inv.items||'[]'):(inv.items||[]);
  showModal(`Invoice ${inv.invoice_number}`,`<div class="space-y-4">
    <div class="flex justify-between items-start"><div><h3 class="text-2xl font-bold text-primary">${inv.invoice_number}</h3><p class="text-gray-500">${fmtDate(inv.created_at)}</p></div><span class="badge ${inv.status==='paid'?'badge-success':'badge-warning'}">${inv.status}</span></div>
    <div class="grid grid-cols-2 gap-4">
      <div class="p-4 bg-gray-50 rounded-xl"><p class="text-xs text-gray-500">Guest</p><p class="font-semibold">${inv.first_name} ${inv.last_name}</p></div>
      <div class="p-4 bg-gray-50 rounded-xl"><p class="text-xs text-gray-500">Room</p><p class="font-semibold">${inv.room_number||'-'}</p></div>
    </div>
    ${items.length>0?`<table class="w-full text-sm"><thead><tr class="border-b"><th class="text-left py-2">Item</th><th class="text-right py-2">Qty</th><th class="text-right py-2">Price</th><th class="text-right py-2">Total</th></tr></thead><tbody>${items.map(it=>`<tr class="border-b border-gray-50"><td class="py-2">${it.description}</td><td class="text-right py-2">${it.qty||1}</td><td class="text-right py-2">${fmt(it.price)}</td><td class="text-right py-2">${fmt((it.qty||1)*it.price)}</td></tr>`).join('')}</tbody></table>`:''}
    <div class="space-y-2 text-sm">
      <div class="flex justify-between"><span class="text-gray-500">Subtotal</span><span>${fmt(inv.subtotal)}</span></div>
      <div class="flex justify-between"><span class="text-gray-500">Tax</span><span>${fmt(inv.tax_amount)}</span></div>
      <div class="flex justify-between border-t pt-2 font-bold text-lg"><span>Total</span><span class="text-primary">${fmt(inv.total_amount)}</span></div>
      <div class="flex justify-between"><span class="text-gray-500">Paid</span><span class="text-green-600">${fmt(inv.amount_paid)}</span></div>
      <div class="flex justify-between font-bold ${inv.balance_due>0?'text-red-500':'text-green-500'}"><span>Balance</span><span>${fmt(inv.balance_due)}</span></div>
    </div>
    <div class="flex gap-3">
      <button onclick="downloadInvoicePDF(${inv.id})" class="btn btn-primary flex-1 justify-center"><i class="fas fa-file-pdf"></i> Download PDF</button>
      ${inv.status!=='paid'?`<button onclick="markInvoicePaid(${inv.id})" class="btn btn-success"><i class="fas fa-check"></i> Paid</button>`:''}
    </div>
  </div>`,'md');
}

async function downloadInvoicePDF(id) {
  const inv=await api(`/invoices/${id}`); const items=typeof inv.items==='string'?JSON.parse(inv.items||'[]'):(inv.items||[]);
  const {jsPDF}=window.jspdf; const doc=new jsPDF();
  doc.setFillColor(108,99,255);doc.rect(0,0,220,40,'F');doc.setTextColor(255);doc.setFontSize(24);doc.setFont('helvetica','bold');
  doc.text('INVOICE',14,20);doc.setFontSize(12);doc.text(inv.invoice_number,14,30);doc.setFontSize(10);doc.setFont('helvetica','normal');
  doc.text(inv.hotel_name||APP.hotelName,196,15,{align:'right'});doc.text(`Date: ${fmtDate(inv.created_at)}`,196,22,{align:'right'});
  doc.setTextColor(50);doc.setFontSize(11);doc.setFont('helvetica','bold');doc.text('Bill To:',14,52);doc.setFont('helvetica','normal');
  doc.text(`${inv.first_name} ${inv.last_name}`,14,59);if(inv.email)doc.text(inv.email,14,65);
  const rows=items.map(it=>[it.description,it.qty||1,fmt(it.price),fmt((it.qty||1)*it.price)]);
  doc.autoTable({head:[['Description','Qty','Price','Total']],body:rows,startY:75,headStyles:{fillColor:[108,99,255]}});
  const fy=doc.lastAutoTable.finalY+10;
  doc.text(`Subtotal: ${fmt(inv.subtotal)}`,140,fy);doc.text(`Tax: ${fmt(inv.tax_amount)}`,140,fy+7);
  doc.setFontSize(14);doc.setFont('helvetica','bold');doc.setTextColor(108,99,255);doc.text(`Total: ${fmt(inv.total_amount)}`,140,fy+18);
  doc.setTextColor(50);doc.setFontSize(10);doc.setFont('helvetica','normal');doc.text(`Paid: ${fmt(inv.amount_paid)}`,140,fy+26);doc.text(`Balance: ${fmt(inv.balance_due)}`,140,fy+33);
  doc.save(`Invoice_${inv.invoice_number}_${today()}.pdf`);showToast('Downloaded!');
}
async function markInvoicePaid(id) { const inv=await api(`/invoices/${id}`); await put(`/invoices/${id}`,{status:'paid',amount_paid:inv.total_amount,balance_due:0}); closeAllModals(); showToast('Marked paid'); renderInvoices(); }
async function exportInvoicesPDF() { const d=await api('/invoices'); generatePDF('Invoices Report',['Invoice #','Guest','Total','Paid','Balance','Status'],d.map(i=>[i.invoice_number,`${i.first_name} ${i.last_name}`,fmt(i.total_amount),fmt(i.amount_paid),fmt(i.balance_due),i.status]),{summary:`${d.length} invoices`}); }
async function exportInvoicesCSV() { const d=await api('/invoices'); generateCSV('Invoices Report',['Invoice #','Guest','Room','Subtotal','Tax','Discount','Total','Paid','Balance','Status'],d.map(i=>[i.invoice_number,`${i.first_name} ${i.last_name}`,i.room_number||'',i.subtotal,i.tax_amount,i.discount_amount,i.total_amount,i.amount_paid,i.balance_due,i.status])); }
async function showNewInvoice() {
  const res=await api('/reservations?status=checked-in');
  showModal('New Invoice',`<div class="space-y-4"><div><label class="block text-sm font-medium mb-1">Reservation *</label><select id="ni-res" class="input-field" onchange="popInvItems()"><option value="">Select</option>${res.map(r=>`<option value="${r.id}" data-guest="${r.guest_id}" data-total="${r.total_amount}" data-paid="${r.paid_amount||0}">${r.reservation_code} - ${r.first_name} ${r.last_name} (${r.room_number||''}) - ${fmt(r.total_amount)}</option>`).join('')}</select></div>
  <div class="grid grid-cols-3 gap-4"><div><label class="block text-sm font-medium mb-1">Subtotal</label><input id="ni-sub" class="input-field" type="number" value="0"></div><div><label class="block text-sm font-medium mb-1">Tax</label><input id="ni-tax" class="input-field" type="number" value="0"></div><div><label class="block text-sm font-medium mb-1">Discount</label><input id="ni-disc" class="input-field" type="number" value="0"></div></div>
  <button onclick="createInvoice()" class="btn btn-primary w-full justify-center">Create</button></div>`,'lg');
}
function popInvItems() { const opt=$('#ni-res').selectedOptions[0]; if(!opt?.value)return; const t=parseFloat(opt.dataset.total||0); $('#ni-sub').value=t; $('#ni-tax').value=Math.round(t*0.075); }
async function createInvoice() { const opt=$('#ni-res').selectedOptions[0]; if(!opt?.value)return showToast('Select reservation','error'); const sub=parseFloat($('#ni-sub').value)||0; const tax=parseFloat($('#ni-tax').value)||0; const disc=parseFloat($('#ni-disc').value)||0; const total=sub+tax-disc; const paid=parseFloat(opt.dataset.paid||0); await post('/invoices',{reservation_id:parseInt(opt.value),guest_id:parseInt(opt.dataset.guest),subtotal:sub,tax_amount:tax,discount_amount:disc,total_amount:total,amount_paid:paid,balance_due:total-paid,status:paid>=total?'paid':'draft',items:[{description:'Room Charge',qty:1,price:sub}],created_by:APP.user.id}); closeAllModals(); showToast('Created!'); renderInvoices(); }
async function deleteInvoice(id) { if(!await confirmAction('Delete invoice?')) return; await del(`/invoices/${id}`); showToast('Deleted'); renderInvoices(); }

// ==================== POS ====================
let posCart = [];
async function renderPOS() {
  const [items,orders]=await Promise.all([api('/pos/items'),api('/pos/orders')]);
  const res=await api('/reservations?status=checked-in');
  const cats=[...new Set(items.map(i=>i.category))];
  const mc=$('#main-content');
  mc.innerHTML=`<div class="fade-in"><div class="flex items-center justify-between mb-6"><div><h2 class="text-2xl font-bold text-gray-800">Point of Sale</h2></div><button onclick="showAddPOSItem()" class="btn btn-outline"><i class="fas fa-plus"></i> Menu Item</button></div>
  <div class="grid grid-cols-1 lg:grid-cols-3 gap-6"><div class="lg:col-span-2">
    <div class="flex gap-2 mb-4"><button onclick="filterPOS('all')" class="btn btn-sm btn-primary" data-cat="all">All</button>${cats.map(c=>`<button onclick="filterPOS('${c}')" class="btn btn-sm btn-outline" data-cat="${c}">${c}</button>`).join('')}</div>
    <div id="pos-items-grid" class="grid grid-cols-2 md:grid-cols-3 gap-3">${items.map(i=>`<button onclick="addCart(${i.id},'${esc(i.name)}',${i.price},'${i.category}')" class="card p-4 text-left hover:border-primary pos-item" data-category="${i.category}"><p class="font-semibold text-sm">${i.name}</p><p class="text-primary font-bold text-sm mt-1">${fmt(i.price)}</p></button>`).join('')}</div></div>
    <div class="card p-5 h-fit sticky top-6"><h3 class="font-bold mb-4"><i class="fas fa-shopping-cart text-primary mr-2"></i>Order</h3>
      <div><label class="block text-sm font-medium mb-1">Charge to</label><select id="pos-res" class="input-field"><option value="">Walk-in</option>${res.map(r=>`<option value="${r.id}" data-guest="${r.guest_id}" data-room="${r.room_id}">${r.room_number||''} - ${r.first_name} ${r.last_name}</option>`).join('')}</select></div>
      <div id="pos-cart" class="mt-4 space-y-2 max-h-64 overflow-y-auto"></div>
      <div class="border-t mt-4 pt-4 space-y-2"><div class="flex justify-between text-sm"><span class="text-gray-500">Subtotal</span><span id="pos-sub">${APP.currency}0</span></div><div class="flex justify-between text-sm"><span class="text-gray-500">Tax</span><span id="pos-tax">${APP.currency}0</span></div><div class="flex justify-between text-lg font-bold border-t pt-2"><span>Total</span><span id="pos-total" class="text-primary">${APP.currency}0</span></div></div>
      <div class="grid grid-cols-2 gap-2 mt-4"><select id="pos-pay" class="input-field"><option value="cash">Cash</option><option value="card">Card</option><option value="room_charge">Room Charge</option></select><button onclick="submitPOS()" class="btn btn-success justify-center"><i class="fas fa-check"></i> Place</button></div>
      <button onclick="posCart=[];renderCartUI()" class="btn btn-outline w-full justify-center mt-2 btn-sm">Clear</button>
    </div>
  </div></div>`;
  posCart = [];
}
function filterPOS(cat) { $$('[data-cat]').forEach(b=>{b.className=`btn btn-sm ${b.dataset.cat===cat?'btn-primary':'btn-outline'}`}); $$('.pos-item').forEach(el=>{el.style.display=cat==='all'||el.dataset.category===cat?'':'none'}); }
function addCart(id,name,price,cat) { const ex=posCart.find(i=>i.id===id); if(ex)ex.qty++; else posCart.push({id,name,price,cat,qty:1}); renderCartUI(); }
function renderCartUI() {
  const c=$('#pos-cart'); if(!c)return;
  const sub=posCart.reduce((s,i)=>s+i.price*i.qty,0); const tax=Math.round(sub*0.075);
  c.innerHTML=posCart.length===0?'<p class="text-gray-400 text-sm text-center py-4">Empty</p>':posCart.map(i=>`<div class="flex items-center justify-between p-2 bg-gray-50 rounded-lg"><div class="flex-1"><p class="text-sm font-medium">${i.name}</p><p class="text-xs text-gray-400">${fmt(i.price)}</p></div><div class="flex items-center gap-2"><button onclick="posCart.find(x=>x.id===${i.id}).qty--;if(posCart.find(x=>x.id===${i.id}).qty<=0)posCart=posCart.filter(x=>x.id!==${i.id});renderCartUI()" class="w-6 h-6 rounded bg-gray-200 flex items-center justify-center text-xs">-</button><span class="text-sm font-medium w-6 text-center">${i.qty}</span><button onclick="posCart.find(x=>x.id===${i.id}).qty++;renderCartUI()" class="w-6 h-6 rounded bg-gray-200 flex items-center justify-center text-xs">+</button><span class="text-sm font-bold w-16 text-right">${fmt(i.price*i.qty)}</span></div></div>`).join('');
  $('#pos-sub').textContent=fmt(sub); $('#pos-tax').textContent=fmt(tax); $('#pos-total').textContent=fmt(sub+tax);
}
async function submitPOS() {
  if(posCart.length===0)return showToast('Empty cart','error');
  const opt=$('#pos-res')?.selectedOptions[0]; const sub=posCart.reduce((s,i)=>s+i.price*i.qty,0); const tax=Math.round(sub*0.075);
  const shift=await api('/shifts/current');
  await post('/pos/orders',{reservation_id:opt?.value?parseInt(opt.value):null,guest_id:opt?.dataset.guest?parseInt(opt.dataset.guest):null,room_id:opt?.dataset.room?parseInt(opt.dataset.room):null,items:posCart,subtotal:sub,tax,total:sub+tax,payment_method:$('#pos-pay').value,payment_status:'paid',shift_id:shift?.id||null,created_by:APP.user.id});
  if(shift)await post('/payments',{reservation_id:opt?.value?parseInt(opt.value):null,guest_id:opt?.dataset.guest?parseInt(opt.dataset.guest):null,amount:sub+tax,payment_method:$('#pos-pay').value,payment_type:'restaurant',shift_id:shift.id,received_by:APP.user.id});
  posCart=[]; showToast('Order placed!'); renderPOS();
}
function showAddPOSItem() { showModal('Add Menu Item',`<div class="space-y-4"><div class="grid grid-cols-2 gap-4"><div><label class="block text-sm font-medium mb-1">Name *</label><input id="pi-name" class="input-field"></div><div><label class="block text-sm font-medium mb-1">Price *</label><input id="pi-price" type="number" class="input-field"></div><div><label class="block text-sm font-medium mb-1">Category</label><select id="pi-cat" class="input-field"><option value="food">Food</option><option value="beverage">Beverage</option><option value="service">Service</option></select></div></div><button onclick="createPOSItem()" class="btn btn-primary w-full justify-center">Add</button></div>`,'md'); }
async function createPOSItem() { await post('/pos/items',{name:$('#pi-name').value,price:parseFloat($('#pi-price').value),category:$('#pi-cat').value}); closeAllModals(); showToast('Added!'); renderPOS(); }

// ==================== REPORTS ====================
async function renderReports() {
  const mc=$('#main-content');
  mc.innerHTML=`<div class="fade-in"><div class="mb-6"><h2 class="text-2xl font-bold text-gray-800">Reports</h2></div>
  <div class="flex items-center gap-3 mb-6"><input type="text" id="rpt-from" class="input-field w-auto date-picker" placeholder="From"><input type="text" id="rpt-to" class="input-field w-auto date-picker" placeholder="To"><button onclick="loadRptData()" class="btn btn-primary btn-sm"><i class="fas fa-sync"></i> Refresh</button></div>
  <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6"><div class="card p-5"><h3 class="font-bold mb-4">Revenue</h3><canvas id="chart-revenue" height="220"></canvas></div><div class="card p-5"><h3 class="font-bold mb-4">Occupancy</h3><canvas id="chart-occ" height="220"></canvas></div></div>
  <div class="card p-5"><h3 class="font-bold mb-4">Download Reports</h3><div class="grid grid-cols-2 md:grid-cols-4 gap-4">
    <button onclick="dlOccRpt()" class="card p-4 text-center hover:border-primary"><i class="fas fa-bed text-2xl text-primary mb-2"></i><p class="text-sm font-medium">Occupancy</p></button>
    <button onclick="dlRevRpt()" class="card p-4 text-center hover:border-primary"><i class="fas fa-chart-line text-2xl text-success mb-2"></i><p class="text-sm font-medium">Revenue</p></button>
    <button onclick="dlGuestRpt()" class="card p-4 text-center hover:border-primary"><i class="fas fa-users text-2xl text-info mb-2"></i><p class="text-sm font-medium">Guests</p></button>
    <button onclick="dlShiftRpt()" class="card p-4 text-center hover:border-primary"><i class="fas fa-clock text-2xl text-warning mb-2"></i><p class="text-sm font-medium">Shifts</p></button>
  </div></div>
  <div class="card p-5 mt-6"><h3 class="font-bold mb-4">Download Reports (CSV)</h3><div class="grid grid-cols-2 md:grid-cols-4 gap-4">
    <button onclick="dlOccRptCSV()" class="card p-4 text-center hover:border-primary"><i class="fas fa-bed text-2xl text-primary mb-2"></i><p class="text-sm font-medium">Occupancy</p></button>
    <button onclick="dlRevRptCSV()" class="card p-4 text-center hover:border-primary"><i class="fas fa-chart-line text-2xl text-success mb-2"></i><p class="text-sm font-medium">Revenue</p></button>
    <button onclick="dlGuestRptCSV()" class="card p-4 text-center hover:border-primary"><i class="fas fa-users text-2xl text-info mb-2"></i><p class="text-sm font-medium">Guests</p></button>
    <button onclick="dlShiftRptCSV()" class="card p-4 text-center hover:border-primary"><i class="fas fa-clock text-2xl text-warning mb-2"></i><p class="text-sm font-medium">Shifts</p></button>
  </div></div></div>`;
  initDatePickers(); loadRptData();
}
async function loadRptData() {
  const from=$('#rpt-from')?.value||'', to=$('#rpt-to')?.value||'';
  const params=from&&to?`?from=${from}&to=${to}`:'';
  const [rev,occ]=await Promise.all([api(`/reports/revenue${params}`),api('/reports/occupancy')]);
  const revCtx=document.getElementById('chart-revenue');
  if(revCtx)new Chart(revCtx,{type:'bar',data:{labels:(rev.daily||[]).map(d=>d.date).reverse().slice(-7),datasets:[{label:'Revenue',data:(rev.daily||[]).map(d=>d.total).reverse().slice(-7),backgroundColor:'rgba(108,99,255,0.6)',borderRadius:8}]},options:{responsive:true,plugins:{legend:{display:false}}}});
  const occCtx=document.getElementById('chart-occ');
  if(occCtx){const o=occ.overall||[];new Chart(occCtx,{type:'doughnut',data:{labels:o.map(x=>x.status),datasets:[{data:o.map(x=>x.count),backgroundColor:['#6C63FF','#00C9A7','#FF9800','#9E9E9E']}]},options:{responsive:true,cutout:'65%'}});}
}
async function dlOccRpt() { const d=await api('/reports/occupancy'); generatePDF('Occupancy Report',['Type','Total','Occupied','Available','Reserved','Maintenance'],(d.byType||[]).map(t=>[t.name,t.total,t.occupied,t.available,t.reserved,t.maintenance])); }
async function dlRevRpt() { const f=$('#rpt-from')?.value||'',t=$('#rpt-to')?.value||'';const p=f&&t?`?from=${f}&to=${t}`:'';const d=await api(`/reports/revenue${p}`);generatePDF('Revenue Report',['Date','Revenue'],(d.daily||[]).map(x=>[x.date,fmt(x.total)]),{summary:`Total: ${fmt(d.total)}`}); }
async function dlGuestRpt() { const d=await api('/reports/guests');generatePDF('Guest Report',['Name','Reservations','Revenue'],(d.topGuests||[]).map(g=>[`${g.first_name} ${g.last_name}`,g.total_reservations,fmt(g.total_revenue)])); }
async function dlShiftRpt() { const f=$('#rpt-from')?.value||'',t=$('#rpt-to')?.value||'';const p=f&&t?`?from=${f}&to=${t}`:'';const d=await api(`/reports/shifts${p}`);generatePDF('Shift Report',['Staff','Start','End','Opening','Payments','Variance'],d.map(s=>[s.user_name,fmtDateTime(s.start_time),fmtDateTime(s.end_time),fmt(s.opening_cash),fmt(s.total_payments),fmt(s.variance)]),{orientation:'l'}); }
async function dlOccRptCSV() { const d=await api('/reports/occupancy'); generateCSV('Occupancy Report',['Type','Total','Occupied','Available','Reserved','Maintenance'],(d.byType||[]).map(t=>[t.name,t.total,t.occupied,t.available,t.reserved,t.maintenance])); }
async function dlRevRptCSV() { const f=$('#rpt-from')?.value||'',t=$('#rpt-to')?.value||'';const p=f&&t?`?from=${f}&to=${t}`:'';const d=await api(`/reports/revenue${p}`);generateCSV('Revenue Report',['Date','Revenue'],(d.daily||[]).map(x=>[x.date,x.total])); }
async function dlGuestRptCSV() { const d=await api('/reports/guests');generateCSV('Guest Report',['Name','Reservations','Revenue'],(d.topGuests||[]).map(g=>[`${g.first_name} ${g.last_name}`,g.total_reservations,g.total_revenue])); }
async function dlShiftRptCSV() { const f=$('#rpt-from')?.value||'',t=$('#rpt-to')?.value||'';const p=f&&t?`?from=${f}&to=${t}`:'';const d=await api(`/reports/shifts${p}`);generateCSV('Shift Report',['Staff','Start','End','Opening Cash','Total Payments','Cash','Card','Transfer','Expected','Actual','Variance','Status'],d.map(s=>[s.user_name,s.start_time,s.end_time||'',s.opening_cash,s.total_payments,s.total_cash,s.total_card,s.total_transfer,s.expected_balance,s.actual_balance||'',s.variance||'',s.status])); }

// ==================== SHIFTS ====================
async function renderShifts() {
  const [shifts,cs]=await Promise.all([api('/shifts'),api('/shifts/current')]);
  const mc=$('#main-content');
  mc.innerHTML=`<div class="fade-in"><div class="flex items-center justify-between mb-6"><div><h2 class="text-2xl font-bold text-gray-800">Shifts</h2></div>${!cs?`<button onclick="showOpenShift()" class="btn btn-success"><i class="fas fa-play"></i> Start</button>`:''}</div>
  ${cs?`<div class="card p-6 mb-6 border-l-4 border-green-500"><div class="flex items-center justify-between mb-4"><h3 class="font-bold text-lg"><i class="fas fa-clock text-green-500 mr-2"></i>Current Shift</h3><span class="badge badge-success">OPEN</span></div>
  <div class="grid grid-cols-2 md:grid-cols-5 gap-4 mb-4"><div class="p-3 bg-gray-50 rounded-xl"><p class="text-xs text-gray-500">Staff</p><p class="font-semibold">${cs.user_name}</p></div><div class="p-3 bg-gray-50 rounded-xl"><p class="text-xs text-gray-500">Started</p><p class="font-semibold">${fmtDateTime(cs.start_time)}</p></div><div class="p-3 bg-gray-50 rounded-xl"><p class="text-xs text-gray-500">Opening</p><p class="font-semibold">${fmt(cs.opening_cash)}</p></div><div class="p-3 bg-gray-50 rounded-xl"><p class="text-xs text-gray-500">Payments</p><p class="font-semibold">${fmt(cs.total_payments)}</p></div><div class="p-3 bg-primary/5 rounded-xl"><p class="text-xs text-gray-500">Expected</p><p class="font-bold text-primary text-lg">${fmt(cs.expected_balance)}</p></div></div>
  <div class="flex gap-3"><button onclick="showShiftReport(${cs.id})" class="btn btn-outline"><i class="fas fa-file-alt"></i> Report</button><button onclick="showCloseShift(${cs.id})" class="btn btn-danger"><i class="fas fa-stop"></i> End Shift</button></div></div>`:''}
  <div class="card p-5"><h3 class="font-bold mb-4">History</h3><table class="w-full"><thead><tr class="text-left text-xs text-gray-500 border-b"><th class="pb-3">STAFF</th><th class="pb-3">START</th><th class="pb-3">END</th><th class="pb-3">OPENING</th><th class="pb-3">PAYMENTS</th><th class="pb-3">VARIANCE</th><th class="pb-3">STATUS</th><th class="pb-3">REPORT</th></tr></thead>
  <tbody>${shifts.map(s=>`<tr class="table-row border-b border-gray-50"><td class="py-3 text-sm font-medium">${s.user_name}</td><td class="py-3 text-sm">${fmtDateTime(s.start_time)}</td><td class="py-3 text-sm">${s.end_time?fmtDateTime(s.end_time):'-'}</td><td class="py-3 text-sm">${fmt(s.opening_cash)}</td><td class="py-3 text-sm">${fmt(s.total_payments)}</td><td class="py-3 text-sm ${(s.variance||0)<0?'text-red-500':(s.variance||0)>0?'text-green-500':''}">${s.variance!=null?fmt(s.variance):'-'}</td><td class="py-3"><span class="badge ${s.status==='open'?'badge-success':'badge-info'}">${s.status}</span></td><td class="py-3"><button onclick="showShiftReport(${s.id})" class="btn btn-outline btn-sm"><i class="fas fa-file-alt"></i> Report</button></td></tr>`).join('')}</tbody></table></div></div>`;
}
function showOpenShift() { showModal('Start Shift',`<div class="space-y-4"><div class="p-4 bg-gray-50 rounded-xl"><p class="text-sm text-gray-500">Starting for</p><p class="font-bold">${APP.user.full_name}</p></div><div><label class="block text-sm font-medium mb-1">Opening Cash *</label><input id="os-cash" type="number" class="input-field" value="0"></div><button onclick="doOpenShift()" class="btn btn-success w-full justify-center py-3"><i class="fas fa-play"></i> Start</button></div>`,'sm'); }
async function doOpenShift() { await post('/shifts/open',{user_id:APP.user.id,opening_cash:parseFloat($('#os-cash').value)||0}); closeAllModals(); showToast('Shift started!'); navigate(APP.currentPage); }
function showCloseShift(shiftId) { showModal('Close Shift',`<div class="space-y-4"><div class="p-4 bg-yellow-50 rounded-xl"><i class="fas fa-exclamation-triangle text-yellow-500 mr-2"></i>Count cash drawer before closing.</div><div><label class="block text-sm font-medium mb-1">Actual Balance *</label><input id="cs-bal" type="number" class="input-field"></div><div><label class="block text-sm font-medium mb-1">Notes</label><textarea id="cs-notes" class="input-field" rows="2"></textarea></div><button onclick="doCloseShift(${shiftId})" class="btn btn-danger w-full justify-center py-3"><i class="fas fa-stop"></i> End Shift</button></div>`,'sm'); }
async function doCloseShift(shiftId) { const bal=parseFloat($('#cs-bal').value); if(isNaN(bal))return showToast('Enter balance','error'); const r=await post(`/shifts/${shiftId}/close`,{actual_balance:bal,notes:$('#cs-notes').value,closed_by:APP.user.id}); closeAllModals(); showToast(Math.abs(r.variance)<1?'Shift closed - balanced!':r.variance>0?`Overage: ${fmt(r.variance)}`:`Shortage: ${fmt(Math.abs(r.variance))}`); navigate(APP.currentPage); }

// ==================== SHIFT REPORTS ====================
async function showShiftReport(shiftId) {
  const data = await api(`/shifts/${shiftId}/report`);
  const s = data.shift;
  const hotel = data.hotel || {};
  showModal('Shift Report', `<div class="space-y-4" id="shift-report-content">
    <div class="flex justify-between items-center">
      <h3 class="text-xl font-bold text-primary">Shift Activity Report</h3>
      <button onclick="printShiftReport()" class="btn btn-outline btn-sm no-print"><i class="fas fa-print"></i> Print</button>
    </div>
    <div class="p-4 bg-gray-50 rounded-xl">
      <div class="text-center mb-3"><h4 class="text-lg font-bold">${hotel.name||APP.hotelName}</h4><p class="text-sm text-gray-500">${hotel.address||''}, ${hotel.city||''}</p></div>
      <div class="grid grid-cols-2 gap-3 text-sm">
        <div><span class="text-gray-500">Staff:</span> <b>${s.user_name}</b></div>
        <div><span class="text-gray-500">Shift ID:</span> <b>#${s.id}</b></div>
        <div><span class="text-gray-500">Start:</span> <b>${fmtDateTime(s.start_time)}</b></div>
        <div><span class="text-gray-500">End:</span> <b>${s.end_time?fmtDateTime(s.end_time):'Still Open'}</b></div>
        <div><span class="text-gray-500">Opening Cash:</span> <b>${fmt(s.opening_cash)}</b></div>
        <div><span class="text-gray-500">Total Payments:</span> <b>${fmt(s.total_payments)}</b></div>
        <div><span class="text-gray-500">Cash:</span> <b>${fmt(s.total_cash)}</b></div>
        <div><span class="text-gray-500">Card:</span> <b>${fmt(s.total_card)}</b></div>
        <div><span class="text-gray-500">Transfer:</span> <b>${fmt(s.total_transfer)}</b></div>
        <div><span class="text-gray-500">Expected Balance:</span> <b class="text-primary">${fmt(s.expected_balance)}</b></div>
        ${s.status==='closed'?`<div><span class="text-gray-500">Actual Balance:</span> <b>${fmt(s.actual_balance)}</b></div><div><span class="text-gray-500">Variance:</span> <b class="${(s.variance||0)<0?'text-red-500':'text-green-500'}">${fmt(s.variance)}</b></div>`:''}
      </div>
    </div>
    ${(data.checkins||[]).length>0?`<div><h4 class="font-semibold text-sm mb-2"><i class="fas fa-sign-in-alt text-green-500 mr-1"></i> Check-ins (${data.checkins.length})</h4>
    <table class="w-full text-sm"><thead><tr class="border-b"><th class="text-left py-2">Guest</th><th class="text-left py-2">Room</th><th class="text-left py-2">Code</th><th class="text-left py-2">Time</th></tr></thead>
    <tbody>${data.checkins.map(ci=>`<tr class="border-b border-gray-50"><td class="py-2">${ci.first_name} ${ci.last_name}</td><td class="py-2">${ci.room_number||'-'}</td><td class="py-2 font-mono text-primary">${ci.reservation_code}</td><td class="py-2">${fmtDateTime(ci.actual_check_in)}</td></tr>`).join('')}</tbody></table></div>`:''}
    ${(data.checkouts||[]).length>0?`<div><h4 class="font-semibold text-sm mb-2"><i class="fas fa-sign-out-alt text-blue-500 mr-1"></i> Check-outs (${data.checkouts.length})</h4>
    <table class="w-full text-sm"><thead><tr class="border-b"><th class="text-left py-2">Guest</th><th class="text-left py-2">Room</th><th class="text-left py-2">Code</th><th class="text-left py-2">Time</th></tr></thead>
    <tbody>${data.checkouts.map(co=>`<tr class="border-b border-gray-50"><td class="py-2">${co.first_name} ${co.last_name}</td><td class="py-2">${co.room_number||'-'}</td><td class="py-2 font-mono text-primary">${co.reservation_code}</td><td class="py-2">${fmtDateTime(co.actual_check_out)}</td></tr>`).join('')}</tbody></table></div>`:''}
    ${(data.payments||[]).length>0?`<div><h4 class="font-semibold text-sm mb-2"><i class="fas fa-money-bill-wave text-primary mr-1"></i> Payments (${data.payments.length})</h4>
    <table class="w-full text-sm"><thead><tr class="border-b"><th class="text-left py-2">Guest</th><th class="text-left py-2">Reservation</th><th class="text-left py-2">Amount</th><th class="text-left py-2">Method</th></tr></thead>
    <tbody>${data.payments.map(p=>`<tr class="border-b border-gray-50"><td class="py-2">${p.first_name?p.first_name+' '+p.last_name:'-'}</td><td class="py-2 font-mono">${p.reservation_code||'-'}</td><td class="py-2 font-bold">${fmt(p.amount)}</td><td class="py-2">${p.payment_method}</td></tr>`).join('')}</tbody></table></div>`:''}
    ${(data.housekeeping||[]).length>0?`<div><h4 class="font-semibold text-sm mb-2"><i class="fas fa-broom text-yellow-500 mr-1"></i> Housekeeping (${data.housekeeping.length})</h4>
    <table class="w-full text-sm"><thead><tr class="border-b"><th class="text-left py-2">Room</th><th class="text-left py-2">Task</th><th class="text-left py-2">Status</th><th class="text-left py-2">Priority</th></tr></thead>
    <tbody>${data.housekeeping.map(h=>`<tr class="border-b border-gray-50"><td class="py-2">${h.room_number}</td><td class="py-2 capitalize">${h.task_type}</td><td class="py-2">${h.status}</td><td class="py-2">${h.priority}</td></tr>`).join('')}</tbody></table></div>`:''}
    ${(data.activities||[]).length>0?`<div><h4 class="font-semibold text-sm mb-2"><i class="fas fa-history text-gray-500 mr-1"></i> Activity Log (${data.activities.length})</h4>
    <div class="max-h-48 overflow-y-auto space-y-1">${data.activities.map(a=>`<div class="text-xs p-2 bg-gray-50 rounded"><span class="text-gray-400">${fmtDateTime(a.created_at)}</span> - <b>${a.user_name||'System'}</b>: ${a.action} ${a.details||''}</div>`).join('')}</div></div>`:''}
    <div class="border-t-2 border-gray-200 pt-4 mt-6">
      <p class="text-sm text-gray-500 mb-2">Notes: ${s.notes||'No notes'}</p>
      <div class="grid grid-cols-2 gap-8 mt-8">
        <div><div style="border-bottom:1px solid #333;height:50px"></div><p class="text-xs text-gray-500 mt-1 text-center">Staff Signature</p><p class="text-xs text-center font-medium">${s.user_name}</p></div>
        <div><div style="border-bottom:1px solid #333;height:50px"></div><p class="text-xs text-gray-500 mt-1 text-center">Supervisor Signature</p><p class="text-xs text-center font-medium">________________</p></div>
      </div>
      <p class="text-xs text-gray-400 text-center mt-4">Date: ________________ | Report generated: ${fullDate()}</p>
    </div>
  </div>`, 'xl');
}

function printShiftReport() {
  window.print();
}

// ==================== MESSAGING (ENHANCED) ====================
let msgView = 'inbox'; // inbox, trash
async function renderMessaging() {
  const trashed = msgView === 'trash' ? '1' : '0';
  const msgs = await api(`/messages?user_id=${APP.user.id}&trashed=${trashed}`);
  const mc = $('#main-content');
  mc.innerHTML = `<div class="fade-in">
    <div class="flex items-center justify-between mb-6"><div><h2 class="text-2xl font-bold text-gray-800">Messages</h2><p class="text-gray-500 text-sm">Internal staff communication</p></div>
    <button onclick="showComposeMessage()" class="btn btn-primary"><i class="fas fa-pen"></i> Compose</button></div>
    <div class="flex gap-3 mb-4">
      <button onclick="msgView='inbox';renderMessaging()" class="btn btn-sm ${msgView==='inbox'?'btn-primary':'btn-outline'}"><i class="fas fa-inbox"></i> Inbox</button>
      <button onclick="msgView='trash';renderMessaging()" class="btn btn-sm ${msgView==='trash'?'btn-danger':'btn-outline'}"><i class="fas fa-trash"></i> Trash</button>
    </div>
    <div class="card p-5">
      ${msgs.map(m=>`<div class="flex gap-4 p-4 ${m.is_read?'bg-white':'bg-primary/5'} rounded-xl mb-3 cursor-pointer hover:bg-gray-50 transition-all" onclick="viewMessage(${m.id})">
        <div class="w-10 h-10 rounded-xl ${m.priority==='high'?'bg-red-100':'bg-primary/10'} flex items-center justify-center flex-shrink-0"><i class="fas ${m.is_broadcast?'fa-bullhorn':'fa-envelope'} ${m.priority==='high'?'text-red-500':'text-primary'}"></i></div>
        <div class="flex-1 min-w-0"><div class="flex items-center justify-between"><p class="font-semibold text-sm ${!m.is_read?'text-gray-900':'text-gray-600'}">${m.subject||'(No subject)'}</p><span class="text-xs text-gray-400">${fmtDateTime(m.created_at)}</span></div>
        <p class="text-xs text-gray-500">From: ${m.from_name}${m.is_broadcast?' (Broadcast)':m.to_name?' → '+m.to_name:''}</p>
        <p class="text-sm text-gray-600 truncate mt-1">${m.body}</p>
        ${(m.reply_count||0)>0?'<span class="text-xs text-primary mt-1 inline-block"><i class="fas fa-reply"></i> '+(m.reply_count)+' replies</span>':''}</div>
        <div class="flex flex-col items-end gap-1 flex-shrink-0">
          ${m.priority==='high'?'<span class="badge badge-danger">HIGH</span>':''}
          ${!m.is_read?'<span class="w-2 h-2 bg-primary rounded-full"></span>':''}
        </div>
      </div>`).join('')}
      ${msgs.length===0?'<p class="text-center py-8 text-gray-400">'+(msgView==='trash'?'Trash is empty':'No messages')+'</p>':''}
    </div>
  </div>`;
}

async function viewMessage(id) {
  await put(`/messages/${id}/read`, {});
  loadUnreadCount();
  const msg = await api(`/messages/${id}`);
  const replies = msg.replies || [];
  showModal(msg.subject || '(No subject)', `<div class="space-y-4">
    <div class="p-4 bg-gray-50 rounded-xl">
      <div class="flex items-center justify-between mb-2">
        <div class="flex items-center gap-3">
          <div class="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center"><i class="fas fa-user text-primary"></i></div>
          <div><p class="font-semibold">${msg.from_name}</p><p class="text-xs text-gray-500">${msg.is_broadcast?'Broadcast':msg.to_name?'To: '+msg.to_name:'Direct'}</p></div>
        </div>
        <span class="text-xs text-gray-400">${fmtDateTime(msg.created_at)}</span>
      </div>
      <div class="mt-3 text-sm text-gray-700 whitespace-pre-wrap">${msg.body}</div>
    </div>
    ${replies.length>0?'<h4 class="font-semibold text-sm text-gray-600"><i class="fas fa-reply text-primary mr-1"></i> Replies</h4>':''}
    ${replies.map(r=>`<div class="p-3 bg-blue-50 rounded-xl ml-4 border-l-4 border-primary">
      <div class="flex items-center justify-between mb-1"><span class="font-semibold text-sm">${r.from_name}</span><span class="text-xs text-gray-400">${fmtDateTime(r.created_at)}</span></div>
      <p class="text-sm text-gray-700 whitespace-pre-wrap">${r.body}</p>
    </div>`).join('')}
    <div class="border-t pt-4">
      <label class="block text-sm font-medium text-gray-700 mb-1"><i class="fas fa-reply text-primary mr-1"></i> Reply</label>
      <textarea id="reply-body" class="input-field" rows="3" placeholder="Type your reply..."></textarea>
      <div class="flex gap-2 mt-3">
        <button onclick="sendReply(${msg.id},${msg.from_user_id})" class="btn btn-primary"><i class="fas fa-paper-plane"></i> Reply</button>
        ${msgView!=='trash'?`<button onclick="trashMessage(${msg.id})" class="btn btn-outline btn-sm"><i class="fas fa-trash text-red-400"></i> Trash</button>`:`<button onclick="restoreMessage(${msg.id})" class="btn btn-outline btn-sm"><i class="fas fa-undo text-green-500"></i> Restore</button>`}
        ${msgView==='trash'?`<button onclick="permanentDeleteMessage(${msg.id})" class="btn btn-danger btn-sm"><i class="fas fa-times"></i> Delete Forever</button>`:''}
      </div>
    </div>
  </div>`, 'lg');
}

async function sendReply(parentId, toUserId) {
  const body = $('#reply-body')?.value;
  if (!body) return showToast('Reply required', 'error');
  await post('/messages', { from_user_id: APP.user.id, to_user_id: toUserId, subject: 'Re: ', body, priority: 'normal', is_broadcast: false, reply_to: parentId });
  closeAllModals(); showToast('Reply sent!'); viewMessage(parentId);
}

async function trashMessage(id) {
  await put(`/messages/${id}/trash`, {});
  closeAllModals(); showToast('Moved to trash'); renderMessaging();
}

async function restoreMessage(id) {
  await put(`/messages/${id}/restore`, {});
  closeAllModals(); showToast('Restored!'); renderMessaging();
}

async function permanentDeleteMessage(id) {
  if (!await confirmAction('Permanently delete this message?')) return;
  await del(`/messages/${id}`);
  closeAllModals(); showToast('Deleted permanently'); renderMessaging();
}

async function showComposeMessage() {
  const users = await api('/users');
  showModal('Compose Message', `<div class="space-y-4">
    <div class="flex items-center gap-3"><label class="flex items-center gap-2"><input type="radio" name="msg-type" value="direct" checked onchange="$('#msg-to-wrap').style.display=''">Direct</label><label class="flex items-center gap-2"><input type="radio" name="msg-type" value="broadcast" onchange="$('#msg-to-wrap').style.display='none'">Broadcast</label></div>
    <div id="msg-to-wrap"><label class="block text-sm font-medium mb-1">To</label><select id="msg-to" class="input-field">${users.map(u=>`<option value="${u.id}">${u.full_name} (${u.role})</option>`).join('')}</select></div>
    <div><label class="block text-sm font-medium mb-1">Subject</label><input id="msg-subject" class="input-field"></div>
    <div><label class="block text-sm font-medium mb-1">Message *</label><textarea id="msg-body" class="input-field" rows="4"></textarea></div>
    <div><label class="block text-sm font-medium mb-1">Priority</label><select id="msg-priority" class="input-field"><option value="normal">Normal</option><option value="high">High</option></select></div>
    <button onclick="sendMessage()" class="btn btn-primary w-full justify-center"><i class="fas fa-paper-plane"></i> Send</button>
  </div>`, 'md');
}
async function sendMessage() {
  const body=$('#msg-body').value; if(!body) return showToast('Message required','error');
  const isBroadcast = document.querySelector('input[name="msg-type"]:checked')?.value === 'broadcast';
  await post('/messages', { from_user_id: APP.user.id, to_user_id: isBroadcast ? null : parseInt($('#msg-to').value), subject: $('#msg-subject').value, body, priority: $('#msg-priority').value, is_broadcast: isBroadcast });
  closeAllModals(); showToast('Sent!'); renderMessaging();
}

// ==================== RESERVATION CALENDAR (daily/weekly/monthly) ====================
let calState = { mode: 'week', anchor: today() };
function calRangeFor(mode, anchorStr) {
  const anchor = new Date(anchorStr + 'T00:00:00Z');
  let from, days;
  if (mode === 'day') { from = new Date(anchor); days = 1; }
  else if (mode === 'week') { from = new Date(anchor); from.setUTCDate(from.getUTCDate() - from.getUTCDay()); days = 7; }
  else { from = new Date(Date.UTC(anchor.getUTCFullYear(), anchor.getUTCMonth(), 1)); const nextMonth = new Date(Date.UTC(anchor.getUTCFullYear(), anchor.getUTCMonth()+1, 1)); days = Math.round((nextMonth-from)/86400000); }
  const to = new Date(from); to.setUTCDate(to.getUTCDate()+days);
  const fmt2 = (d)=>d.toISOString().split('T')[0];
  return { from: fmt2(from), to: fmt2(to) };
}
function calShift(delta) {
  const a = new Date(calState.anchor + 'T00:00:00Z');
  if (calState.mode === 'day') a.setUTCDate(a.getUTCDate()+delta);
  else if (calState.mode === 'week') a.setUTCDate(a.getUTCDate()+delta*7);
  else a.setUTCMonth(a.getUTCMonth()+delta);
  calState.anchor = a.toISOString().split('T')[0];
  renderCalendarPage();
}
function calSetMode(mode) { calState.mode = mode; renderCalendarPage(); }

async function renderCalendarPage() {
  const { from, to } = calRangeFor(calState.mode, calState.anchor);
  const grid = await api(`/calendar/grid?from=${from}&to=${to}`);
  APP.data.calGrid = grid;
  const mc = $('#main-content');
  const rangeLabel = calState.mode === 'month'
    ? new Date(from+'T00:00:00Z').toLocaleDateString('en-US', { month: 'long', year: 'numeric', timeZone: 'UTC' })
    : `${fmtDate(from)} – ${fmtDate(calRangeFor(calState.mode, calState.anchor).to)}`;
  mc.innerHTML = `<div class="fade-in">
    <div class="flex items-center justify-between mb-6 flex-wrap gap-3">
      <div><h2 class="text-2xl font-bold text-gray-800">Reservation Calendar</h2><p class="text-gray-500 text-sm">Room-by-room availability at a glance</p></div>
      <div class="flex items-center gap-2 flex-wrap">
        <div class="flex rounded-xl overflow-hidden border border-gray-200">
          <button onclick="calSetMode('day')" class="px-3 py-2 text-xs font-semibold ${calState.mode==='day'?'bg-primary text-white':'bg-white text-gray-600'}">Day</button>
          <button onclick="calSetMode('week')" class="px-3 py-2 text-xs font-semibold ${calState.mode==='week'?'bg-primary text-white':'bg-white text-gray-600'}">Week</button>
          <button onclick="calSetMode('month')" class="px-3 py-2 text-xs font-semibold ${calState.mode==='month'?'bg-primary text-white':'bg-white text-gray-600'}">Month</button>
        </div>
        <button onclick="calShift(-1)" class="btn btn-outline btn-sm"><i class="fas fa-chevron-left"></i></button>
        <span class="font-semibold text-sm px-2">${rangeLabel}</span>
        <button onclick="calShift(1)" class="btn btn-outline btn-sm"><i class="fas fa-chevron-right"></i></button>
        <button onclick="calState.anchor=today();renderCalendarPage()" class="btn btn-outline btn-sm">Today</button>
        <button onclick="showBlockDatesModal()" class="btn btn-warning btn-sm"><i class="fas fa-ban"></i> Block Dates</button>
      </div>
    </div>
    <div class="card p-4 overflow-x-auto">
      <table class="w-full border-collapse" style="min-width:${Math.max(700, grid.days.length*60+140)}px">
        <thead><tr>
          <th class="cal-row-label text-left text-xs text-gray-500 p-2 bg-white" style="min-width:140px">Room</th>
          ${grid.days.map(d=>`<th class="text-center text-xs text-gray-500 p-1" style="min-width:${calState.mode==='month'?'34px':'70px'}">${calState.mode==='month'?new Date(d+'T00:00:00Z').getUTCDate():new Date(d+'T00:00:00Z').toLocaleDateString('en-US',{weekday:'short',day:'numeric',timeZone:'UTC'})}</th>`).join('')}
        </tr></thead>
        <tbody>${grid.rooms.map(r=>`<tr>
          <td class="cal-row-label text-sm font-medium p-2 border-t border-gray-50">${r.room_number} <span class="text-gray-400 text-xs block">${r.type_name}</span></td>
          ${grid.days.map(d=>{
            const cell = r.cells[d] || {status:'available'};
            const title = cell.guest_name ? `${cell.guest_name} (${cell.reservation_code})` : (cell.reason || cell.status);
            const onclick = cell.status==='available' ? `showNewReservation('${d}')` : (cell.reservation_id ? `closeAllModals();showReservationDetail(${cell.reservation_id})` : (cell.block_id ? `showUnblockConfirm(${cell.block_id})` : ''));
            return `<td class="p-0.5 border-t border-gray-50"><div class="cal-cell ${cell.status}" title="${esc(title)}" onclick="${onclick}">${cell.is_checkin?'<i class="fas fa-arrow-right" style="font-size:8px"></i>':cell.is_checkout?'<i class="fas fa-arrow-left" style="font-size:8px"></i>':''}</div></td>`;
          }).join('')}
        </tr>`).join('')}</tbody>
      </table>
      ${grid.rooms.length===0?'<p class="text-center py-8 text-gray-400">No rooms configured</p>':''}
    </div>
  </div>`;
}

async function showUnblockConfirm(blockId) {
  if (!await confirmAction('Remove this date block?')) return;
  await del(`/calendar/blocks/${blockId}`); showToast('Block removed'); renderCalendarPage();
}

async function showBlockDatesModal() {
  const [types, rooms] = await Promise.all([api('/room-types'), api('/rooms')]);
  showModal('Block Dates', `<div class="space-y-4">
    <p class="text-sm text-gray-500">Close out dates for maintenance, owner use, or manual holds.</p>
    <div><label class="block text-sm font-medium mb-1">Scope</label>
      <select id="bd-scope" class="input-field" onchange="$('#bd-room-wrap').style.display=this.value==='room'?'':'none';$('#bd-type-wrap').style.display=this.value==='type'?'':'none'">
        <option value="type">Entire unit type</option>
        <option value="room">Specific room/unit</option>
      </select>
    </div>
    <div id="bd-type-wrap"><label class="block text-sm font-medium mb-1">Unit Type</label><select id="bd-type" class="input-field">${types.map(t=>`<option value="${t.id}">${t.name}</option>`).join('')}</select></div>
    <div id="bd-room-wrap" style="display:none"><label class="block text-sm font-medium mb-1">Room/Unit</label><select id="bd-room" class="input-field">${rooms.map(r=>`<option value="${r.id}">${r.room_number} (${r.type_name})</option>`).join('')}</select></div>
    <div class="grid grid-cols-2 gap-4">
      <div><label class="block text-sm font-medium mb-1">From *</label><input id="bd-from" type="text" class="input-field date-picker" value="${today()}"></div>
      <div><label class="block text-sm font-medium mb-1">To *</label><input id="bd-to" type="text" class="input-field date-picker"></div>
    </div>
    <div><label class="block text-sm font-medium mb-1">Reason</label><input id="bd-reason" class="input-field" placeholder="e.g. Maintenance, Owner stay"></div>
    <button onclick="createBlock()" class="btn btn-warning w-full justify-center"><i class="fas fa-ban"></i> Block</button>
  </div>`, 'md');
  initDatePickers();
}
async function createBlock() {
  const scope = $('#bd-scope').value;
  const from = $('#bd-from')._flatpickr?.input.value || $('#bd-from').value;
  const to = $('#bd-to')._flatpickr?.input.value || $('#bd-to').value;
  if (!from || !to) return showToast('Dates required', 'error');
  const body = { start_date: from, end_date: to, reason: $('#bd-reason').value, created_by: APP.user.id };
  if (scope === 'room') body.room_id = parseInt($('#bd-room').value); else body.room_type_id = parseInt($('#bd-type').value);
  await post('/calendar/blocks', body);
  closeAllModals(); showToast('Dates blocked'); renderCalendarPage();
}

// ==================== CHANNEL MANAGER (OTA connections) ====================
async function renderChannelsPage() {
  const [catalog, connections, logs] = await Promise.all([api('/channels/catalog'), api('/channels/connections'), api('/channels/sync-logs')]);
  APP.data.channelCatalog = catalog; APP.data.channelConnections = connections;
  const mc = $('#main-content');
  mc.innerHTML = `<div class="fade-in">
    <div class="flex items-center justify-between mb-6 flex-wrap gap-3">
      <div><h2 class="text-2xl font-bold text-gray-800">Channel Manager</h2><p class="text-gray-500 text-sm">Connect OTAs (Booking.com, Airbnb, Expedia...) to sync availability &amp; bookings</p></div>
      <div class="flex gap-2"><button onclick="syncAllChannels()" class="btn btn-outline"><i class="fas fa-sync"></i> Sync All</button><button onclick="showAddChannelConnection()" class="btn btn-primary"><i class="fas fa-plus"></i> Connect Channel</button></div>
    </div>
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
      ${connections.map(cc=>`<div class="channel-card">
        <div class="flex items-center justify-between mb-3">
          <div class="flex items-center gap-2"><div class="w-9 h-9 rounded-lg flex items-center justify-center" style="background:${cc.channel_color}22"><i class="fas ${cc.channel_icon}" style="color:${cc.channel_color}"></i></div><div><p class="font-bold text-sm">${cc.channel_name}</p><p class="text-xs text-gray-400">${cc.label || cc.room_type_name || 'All units'}</p></div></div>
          <span class="badge ${cc.status==='connected'?'badge-success':cc.status==='error'?'badge-danger':'badge-warning'}">${cc.status}</span>
        </div>
        <p class="text-xs text-gray-400 mb-3">Last sync: ${cc.last_sync_at?fmtDateTime(cc.last_sync_at):'Never'}</p>
        <div class="flex gap-2">
          <button onclick="syncChannel(${cc.id})" class="btn btn-outline btn-sm flex-1 justify-center"><i class="fas fa-sync"></i> Sync</button>
          <button onclick="showExportIcal(${cc.id})" class="btn btn-outline btn-sm"><i class="fas fa-calendar-alt"></i></button>
          <button onclick="deleteChannelConnection(${cc.id})" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></button>
        </div>
      </div>`).join('')}
      ${connections.length===0?'<p class="text-gray-400 col-span-3 text-center py-6">No channels connected yet. Connect Booking.com, Airbnb or others to start syncing.</p>':''}
    </div>
    <div class="card p-5">
      <h3 class="font-bold mb-4">Sync History</h3>
      <table class="w-full text-sm"><thead><tr class="text-left text-xs text-gray-500 border-b"><th class="pb-2">CHANNEL</th><th class="pb-2">STATUS</th><th class="pb-2">FETCHED</th><th class="pb-2">CREATED</th><th class="pb-2">UPDATED</th><th class="pb-2">DUPES</th><th class="pb-2">CONFLICTS</th><th class="pb-2">TIME</th></tr></thead>
      <tbody>${logs.map(l=>`<tr class="border-b border-gray-50"><td class="py-2 font-medium">${l.channel_name}</td><td class="py-2"><span class="badge ${l.status==='success'?'badge-success':'badge-danger'}">${l.status}</span></td><td class="py-2">${l.events_fetched}</td><td class="py-2">${l.reservations_created}</td><td class="py-2">${l.reservations_updated}</td><td class="py-2">${l.duplicates_skipped}</td><td class="py-2">${l.conflicts_detected}</td><td class="py-2 text-gray-400">${fmtDateTime(l.started_at)}</td></tr>`).join('')}</tbody></table>
      ${logs.length===0?'<p class="text-center py-6 text-gray-400">No sync activity yet</p>':''}
    </div>
  </div>`;
}
async function showAddChannelConnection() {
  const [catalog, types] = await Promise.all([api('/channels/catalog'), api('/room-types')]);
  showModal('Connect Channel', `<div class="space-y-4">
    <div><label class="block text-sm font-medium mb-1">Channel *</label><select id="cc-channel" class="input-field">${catalog.map(c=>`<option value="${c.id}">${c.name}</option>`).join('')}</select></div>
    <div><label class="block text-sm font-medium mb-1">Apply to Unit Type</label><select id="cc-type" class="input-field"><option value="">All unit types</option>${types.map(t=>`<option value="${t.id}">${t.name}</option>`).join('')}</select></div>
    <div><label class="block text-sm font-medium mb-1">Label</label><input id="cc-label" class="input-field" placeholder="e.g. Main listing"></div>
    <div><label class="block text-sm font-medium mb-1">iCal Import URL</label><input id="cc-ical" class="input-field" placeholder="https://.../calendar.ics"></div>
    <p class="text-xs text-gray-400">Paste the OTA's iCal export URL to pull bookings &amp; block dates automatically. You can also export your own availability back to the OTA after connecting.</p>
    <button onclick="createChannelConnection()" class="btn btn-primary w-full justify-center">Connect</button>
  </div>`, 'md');
}
async function createChannelConnection() {
  const r = await post('/channels/connections', {
    channel_id: parseInt($('#cc-channel').value), room_type_id: $('#cc-type').value ? parseInt($('#cc-type').value) : null,
    label: $('#cc-label').value, ical_import_url: $('#cc-ical').value, created_by: APP.user.id
  });
  closeAllModals(); showToast('Channel connected!'); renderChannelsPage();
}
async function syncChannel(id) { showToast('Syncing...', 'warning'); const r = await post(`/channels/connections/${id}/sync`, {}); showToast(r.success ? `Synced: ${r.created} new, ${r.updated} updated` : `Sync issue: ${r.message}`, r.success?'success':'warning'); renderChannelsPage(); }
async function syncAllChannels() { showToast('Syncing all channels...', 'warning'); await post('/channels/sync-all', {}); showToast('Sync complete'); renderChannelsPage(); }
async function deleteChannelConnection(id) { if (!await confirmAction('Disconnect this channel?')) return; await del(`/channels/connections/${id}`); showToast('Disconnected'); renderChannelsPage(); }
function showExportIcal(id) {
  const url = `${location.origin}/api/channels/connections/${id}/export.ics`;
  showModal('Export Availability (iCal)', `<div class="space-y-3">
    <p class="text-sm text-gray-500">Paste this URL into the OTA's "import calendar" field so it always sees your latest availability:</p>
    <input class="input-field" readonly value="${url}" onclick="this.select()">
    <button onclick="navigator.clipboard.writeText('${url}');showToast('Copied!')" class="btn btn-primary w-full justify-center"><i class="fas fa-copy"></i> Copy Link</button>
  </div>`, 'md');
}

// ==================== TEAMS (staff grouping + assignment) ====================
async function renderTeamsPage() {
  const [teams, users] = await Promise.all([api('/teams'), api('/users')]);
  APP.data.teams = teams; APP.data.teamUsers = users;
  const mc = $('#main-content');
  mc.innerHTML = `<div class="fade-in">
    <div class="flex items-center justify-between mb-6">
      <div><h2 class="text-2xl font-bold text-gray-800">Teams</h2><p class="text-gray-500 text-sm">Group staff for shifts, housekeeping rounds, and task assignment</p></div>
      <button onclick="showCreateTeam()" class="btn btn-primary"><i class="fas fa-plus"></i> New Team</button>
    </div>
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
      ${teams.map(t=>`<div class="card p-5" style="border-top:4px solid ${t.color}">
        <div class="flex items-center justify-between mb-3"><h3 class="font-bold">${t.name}</h3><div class="flex gap-1"><button onclick="showEditTeam(${t.id})" class="btn btn-outline btn-sm"><i class="fas fa-edit"></i></button><button onclick="deleteTeam(${t.id})" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></button></div></div>
        <p class="text-xs text-gray-500 mb-3">${t.description||'No description'}</p>
        <div class="space-y-2 mb-3">${(t.members||[]).map(m=>`<div class="flex items-center justify-between p-2 bg-gray-50 rounded-lg"><div class="flex items-center gap-2"><div class="w-7 h-7 rounded-lg bg-primary/10 flex items-center justify-center"><span class="text-primary font-bold text-[10px]">${m.full_name.split(' ').map(n=>n[0]).join('')}</span></div><div><p class="text-xs font-medium">${m.full_name}</p><p class="text-[10px] text-gray-400 capitalize">${m.role.replace('_',' ')}</p></div></div><button onclick="removeTeamMember(${t.id},${m.user_id})" class="text-red-400 hover:text-red-600"><i class="fas fa-times text-xs"></i></button></div>`).join('')}
        ${(t.members||[]).length===0?'<p class="text-xs text-gray-400 text-center py-2">No members yet</p>':''}</div>
        <button onclick="showAssignMember(${t.id})" class="btn btn-outline btn-sm w-full justify-center"><i class="fas fa-user-plus"></i> Assign Staff</button>
      </div>`).join('')}
      ${teams.length===0?'<p class="text-gray-400 col-span-3 text-center py-8">No teams yet. Create one to organize your staff.</p>':''}
    </div>
  </div>`;
}
function showCreateTeam() {
  showModal('New Team', `<div class="space-y-4">
    <div><label class="block text-sm font-medium mb-1">Team Name *</label><input id="tm-name" class="input-field" placeholder="e.g. Morning Shift, Housekeeping Crew A"></div>
    <div><label class="block text-sm font-medium mb-1">Description</label><textarea id="tm-desc" class="input-field" rows="2"></textarea></div>
    <div><label class="block text-sm font-medium mb-1">Color</label><input id="tm-color" type="color" class="input-field h-[42px]" value="#6C63FF"></div>
    <button onclick="createTeam()" class="btn btn-primary w-full justify-center">Create Team</button>
  </div>`, 'sm');
}
async function createTeam() {
  if (!$('#tm-name').value) return showToast('Name required', 'error');
  await post('/teams', { name: $('#tm-name').value, description: $('#tm-desc').value, color: $('#tm-color').value, created_by: APP.user.id });
  closeAllModals(); showToast('Team created!'); renderTeamsPage();
}
function showEditTeam(id) {
  const t = (APP.data.teams||[]).find(x=>x.id===id); if (!t) return;
  showModal('Edit Team', `<div class="space-y-4">
    <div><label class="block text-sm font-medium mb-1">Team Name</label><input id="tm-name" class="input-field" value="${t.name}"></div>
    <div><label class="block text-sm font-medium mb-1">Description</label><textarea id="tm-desc" class="input-field" rows="2">${t.description||''}</textarea></div>
    <div><label class="block text-sm font-medium mb-1">Color</label><input id="tm-color" type="color" class="input-field h-[42px]" value="${t.color}"></div>
    <button onclick="updateTeam(${id})" class="btn btn-primary w-full justify-center">Update</button>
  </div>`, 'sm');
}
async function updateTeam(id) { await put(`/teams/${id}`, { name: $('#tm-name').value, description: $('#tm-desc').value, color: $('#tm-color').value }); closeAllModals(); showToast('Updated!'); renderTeamsPage(); }
async function deleteTeam(id) { if (!await confirmAction('Delete this team?')) return; await del(`/teams/${id}`); showToast('Deleted'); renderTeamsPage(); }
function showAssignMember(teamId) {
  const users = APP.data.teamUsers||[];
  const team = (APP.data.teams||[]).find(t=>t.id===teamId);
  const existingIds = (team?.members||[]).map(m=>m.user_id);
  const available = users.filter(u=>!existingIds.includes(u.id));
  showModal('Assign Staff', `<div class="space-y-4">
    <div><label class="block text-sm font-medium mb-1">Staff Member</label><select id="am-user" class="input-field">${available.map(u=>`<option value="${u.id}">${u.full_name} (${u.role})</option>`).join('')}</select></div>
    ${available.length===0?'<p class="text-sm text-gray-400">All staff already assigned to this team.</p>':`<button onclick="assignMember(${teamId})" class="btn btn-primary w-full justify-center">Assign</button>`}
  </div>`, 'sm');
}
async function assignMember(teamId) { await post(`/teams/${teamId}/members`, { user_id: parseInt($('#am-user').value) }); closeAllModals(); showToast('Assigned!'); renderTeamsPage(); }
async function removeTeamMember(teamId, userId) { if (!await confirmAction('Remove from team?')) return; await del(`/teams/${teamId}/members/${userId}`); showToast('Removed'); renderTeamsPage(); }

// ==================== SUPER ADMIN: Property Types & Roles ====================
async function renderSuperAdminPage() {
  const [stats, propTypes, roles] = await Promise.all([api('/admin/stats'), api('/admin/property-types'), api('/admin/roles')]);
  const mc = $('#main-content');
  mc.innerHTML = `<div class="fade-in">
    <div class="mb-6"><h2 class="text-2xl font-bold text-gray-800">Platform Administration</h2><p class="text-gray-500 text-sm">Manage property types &amp; roles available across all hotels</p></div>
    <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
      <div class="stat-card"><p class="text-2xl font-bold text-primary">${stats.hotels}</p><p class="text-xs text-gray-500">Hotels/Properties</p></div>
      <div class="stat-card"><p class="text-2xl font-bold text-success">${stats.rooms}</p><p class="text-xs text-gray-500">Total Rooms/Units</p></div>
      <div class="stat-card"><p class="text-2xl font-bold text-info">${stats.users}</p><p class="text-xs text-gray-500">Staff Accounts</p></div>
      <div class="stat-card"><p class="text-2xl font-bold text-warning">${stats.activeReservations}</p><p class="text-xs text-gray-500">Active Reservations</p></div>
    </div>
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <div class="card p-5">
        <div class="flex items-center justify-between mb-4"><h3 class="font-bold"><i class="fas fa-shapes text-primary mr-2"></i>Property Types</h3><button onclick="showAddPropertyType()" class="btn btn-primary btn-sm"><i class="fas fa-plus"></i> Add</button></div>
        <div class="space-y-2">${propTypes.map(pt=>`<div class="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
          <div class="flex items-center gap-3"><div class="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center"><i class="fas ${pt.icon} text-primary text-sm"></i></div><div><p class="font-medium text-sm">${pt.name}</p><p class="text-xs text-gray-400">${pt.description||''}</p></div></div>
          ${!pt.is_system?`<div class="flex gap-1"><button onclick="showEditPropertyType(${pt.id})" class="btn btn-outline btn-sm"><i class="fas fa-edit"></i></button><button onclick="deletePropertyType(${pt.id})" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></button></div>`:'<span class="badge badge-primary">SYSTEM</span>'}
        </div>`).join('')}</div>
      </div>
      <div class="card p-5">
        <div class="flex items-center justify-between mb-4"><h3 class="font-bold"><i class="fas fa-user-shield text-primary mr-2"></i>Roles</h3><button onclick="showAddRole()" class="btn btn-primary btn-sm"><i class="fas fa-plus"></i> Add</button></div>
        <div class="space-y-2">${roles.map(r=>`<div class="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
          <div><p class="font-medium text-sm">${r.name}</p><p class="text-xs text-gray-400">${r.description||''}</p></div>
          ${!r.is_system?`<div class="flex gap-1"><button onclick="showEditRole(${r.id})" class="btn btn-outline btn-sm"><i class="fas fa-edit"></i></button><button onclick="deleteRole(${r.id})" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></button></div>`:'<span class="badge badge-primary">SYSTEM</span>'}
        </div>`).join('')}</div>
      </div>
    </div>
  </div>`;
}
function showAddPropertyType() {
  showModal('Add Property Type', `<div class="space-y-4">
    <div><label class="block text-sm font-medium mb-1">Name *</label><input id="pt-name" class="input-field" placeholder="e.g. Villa, Lodge"></div>
    <div><label class="block text-sm font-medium mb-1">Description</label><input id="pt-desc" class="input-field"></div>
    <div><label class="block text-sm font-medium mb-1">Icon (FontAwesome class)</label><input id="pt-icon" class="input-field" value="fa-hotel" placeholder="fa-hotel, fa-building, fa-house-chimney..."></div>
    <button onclick="createPropertyType()" class="btn btn-primary w-full justify-center">Create</button>
  </div>`, 'sm');
}
async function createPropertyType() { if (!$('#pt-name').value) return showToast('Name required','error'); await post('/admin/property-types', { name: $('#pt-name').value, description: $('#pt-desc').value, icon: $('#pt-icon').value || 'fa-hotel' }); closeAllModals(); showToast('Created!'); renderSuperAdminPage(); }
async function showEditPropertyType(id) {
  const rows = await api('/admin/property-types'); const pt = rows.find(x=>x.id===id); if (!pt) return;
  showModal('Edit Property Type', `<div class="space-y-4">
    <div><label class="block text-sm font-medium mb-1">Name</label><input id="pt-name" class="input-field" value="${pt.name}"></div>
    <div><label class="block text-sm font-medium mb-1">Description</label><input id="pt-desc" class="input-field" value="${pt.description||''}"></div>
    <div><label class="block text-sm font-medium mb-1">Icon</label><input id="pt-icon" class="input-field" value="${pt.icon}"></div>
    <button onclick="updatePropertyType(${id})" class="btn btn-primary w-full justify-center">Update</button>
  </div>`, 'sm');
}
async function updatePropertyType(id) { await put(`/admin/property-types/${id}`, { name: $('#pt-name').value, description: $('#pt-desc').value, icon: $('#pt-icon').value }); closeAllModals(); showToast('Updated!'); renderSuperAdminPage(); }
async function deletePropertyType(id) { if (!await confirmAction('Delete this property type?')) return; await del(`/admin/property-types/${id}`); showToast('Deleted'); renderSuperAdminPage(); }

function showAddRole() {
  showModal('Add Role', `<div class="space-y-4">
    <div><label class="block text-sm font-medium mb-1">Key * (unique, lowercase_underscore)</label><input id="rl-key" class="input-field" placeholder="e.g. night_auditor"></div>
    <div><label class="block text-sm font-medium mb-1">Display Name *</label><input id="rl-name" class="input-field" placeholder="e.g. Night Auditor"></div>
    <div><label class="block text-sm font-medium mb-1">Description</label><input id="rl-desc" class="input-field"></div>
    <button onclick="createRole()" class="btn btn-primary w-full justify-center">Create</button>
  </div>`, 'sm');
}
async function createRole() { if (!$('#rl-key').value||!$('#rl-name').value) return showToast('Key and name required','error'); await post('/admin/roles', { key: $('#rl-key').value, name: $('#rl-name').value, description: $('#rl-desc').value }); closeAllModals(); showToast('Created!'); renderSuperAdminPage(); }
async function showEditRole(id) {
  const rows = await api('/admin/roles'); const r = rows.find(x=>x.id===id); if (!r) return;
  showModal('Edit Role', `<div class="space-y-4">
    <div><label class="block text-sm font-medium mb-1">Display Name</label><input id="rl-name" class="input-field" value="${r.name}"></div>
    <div><label class="block text-sm font-medium mb-1">Description</label><input id="rl-desc" class="input-field" value="${r.description||''}"></div>
    <button onclick="updateRole(${id})" class="btn btn-primary w-full justify-center">Update</button>
  </div>`, 'sm');
}
async function updateRole(id) { await put(`/admin/roles/${id}`, { name: $('#rl-name').value, description: $('#rl-desc').value }); closeAllModals(); showToast('Updated!'); renderSuperAdminPage(); }
async function deleteRole(id) { if (!await confirmAction('Delete this role?')) return; await del(`/admin/roles/${id}`); showToast('Deleted'); renderSuperAdminPage(); }

// ==================== SUPER ADMIN: Backup & Export ====================
async function renderBackupPage() {
  const mc = $('#main-content');
  mc.innerHTML = `<div class="fade-in">
    <div class="mb-6"><h2 class="text-2xl font-bold text-gray-800">Backup &amp; Export</h2><p class="text-gray-500 text-sm">Download a full snapshot of the platform database</p></div>
    <div class="card p-8 text-center max-w-xl">
      <div class="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-4"><i class="fas fa-database text-3xl text-primary"></i></div>
      <h3 class="font-bold text-lg mb-2">Full System Backup</h3>
      <p class="text-sm text-gray-500 mb-6">Exports all hotels, rooms, reservations, guests, payments, and settings as a single JSON file you can store safely or use to migrate/restore data.</p>
      <button onclick="downloadFullBackup()" class="btn btn-primary justify-center mx-auto"><i class="fas fa-download"></i> Download Backup (.json)</button>
    </div>
  </div>`;
}
// ==================== SUPER ADMIN: License ====================
async function renderLicensePage() {
  const data = await api('/license');
  const lic = data.license; const history = data.history || [];
  const mc = $('#main-content');
  const statusBadge = lic.status === 'active' ? 'badge-success' : lic.status === 'trial' ? 'badge-warning' : 'badge-danger';
  mc.innerHTML = `<div class="fade-in">
    <div class="mb-6"><h2 class="text-2xl font-bold text-gray-800">License</h2><p class="text-gray-500 text-sm">Activate, extend, or manage the platform license</p></div>
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
      <div class="card p-6">
        <div class="flex items-center justify-between mb-4">
          <h3 class="font-bold"><i class="fas fa-key text-primary mr-2"></i>License Status</h3>
          <span class="badge ${statusBadge}">${lic.status}</span>
        </div>
        <div class="grid grid-cols-2 gap-3 mb-4">
          <div class="p-3 bg-gray-50 rounded-xl"><p class="text-xs text-gray-500">Plan</p><p class="font-semibold text-sm capitalize">${lic.plan||'trial'}</p></div>
          <div class="p-3 bg-gray-50 rounded-xl"><p class="text-xs text-gray-500">${lic.status==='trial'?'Days Left':'Expires'}</p><p class="font-semibold text-sm">${lic.status==='trial'?(Math.max(lic.remaining_days||0,0)+' days'):(lic.expires_at?fmtDate(lic.expires_at.split('T')[0]):'—')}</p></div>
          <div class="p-3 bg-gray-50 rounded-xl"><p class="text-xs text-gray-500">Max Hotels</p><p class="font-semibold text-sm">${lic.max_hotels||1}</p></div>
          <div class="p-3 bg-gray-50 rounded-xl"><p class="text-xs text-gray-500">Max Rooms</p><p class="font-semibold text-sm">${lic.max_rooms||50}</p></div>
        </div>
        ${lic.license_key?`<div class="p-3 bg-primary/5 rounded-xl mb-4"><p class="text-xs text-gray-500">License Key</p><p class="font-mono font-semibold text-sm">${lic.license_key}</p></div>`:''}
        ${lic.customer_name?`<p class="text-xs text-gray-500 mb-4">Licensed to: <b>${lic.customer_name}</b> ${lic.customer_email?`(${lic.customer_email})`:''}</p>`:''}
        <div class="flex flex-wrap gap-2">
          <button onclick="showActivateLicense()" class="btn btn-primary btn-sm"><i class="fas fa-unlock"></i> Activate License</button>
          ${lic.status==='trial'?`<button onclick="extendTrial()" class="btn btn-outline btn-sm"><i class="fas fa-calendar-plus"></i> Extend Trial (+7d)</button>`:''}
          ${lic.status==='active'?`<button onclick="deactivateLicense()" class="btn btn-danger btn-sm"><i class="fas fa-ban"></i> Suspend</button>`:''}
          <button onclick="generateDemoKey()" class="btn btn-outline btn-sm"><i class="fas fa-dice"></i> Generate Test Key</button>
        </div>
      </div>
      <div class="card p-6">
        <h3 class="font-bold mb-4"><i class="fas fa-history text-primary mr-2"></i>License History</h3>
        <div class="space-y-2 max-h-80 overflow-y-auto">
          ${history.map(h=>`<div class="flex items-center gap-3 p-3 bg-gray-50 rounded-xl text-sm">
            <div class="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0"><i class="fas fa-key text-primary text-xs"></i></div>
            <div class="flex-1"><span class="font-medium capitalize">${h.action}</span> <span class="text-gray-400 text-xs">${h.note||''}</span></div>
            <span class="text-xs text-gray-400 flex-shrink-0">${fmtDateTime(h.created_at)}</span>
          </div>`).join('')}
          ${history.length===0?'<p class="text-gray-400 text-center py-6 text-sm">No license activity yet</p>':''}
        </div>
      </div>
    </div>
  </div>`;
}
function showActivateLicense() {
  showModal('Activate License', `<div class="space-y-4">
    <div><label class="block text-sm font-medium mb-1">License Key *</label><input id="lk-key" class="input-field font-mono" placeholder="PCH-XXXX-XXXX-XXXX-XXXX"></div>
    <div class="grid grid-cols-2 gap-4">
      <div><label class="block text-sm font-medium mb-1">Customer Name</label><input id="lk-name" class="input-field"></div>
      <div><label class="block text-sm font-medium mb-1">Customer Email</label><input id="lk-email" class="input-field"></div>
    </div>
    <div class="grid grid-cols-2 gap-4">
      <div><label class="block text-sm font-medium mb-1">Plan</label><select id="lk-plan" class="input-field"><option value="pro">Pro</option><option value="business">Business</option><option value="enterprise">Enterprise</option></select></div>
      <div><label class="block text-sm font-medium mb-1">Duration (days)</label><input id="lk-days" type="number" class="input-field" value="365"></div>
    </div>
    <button onclick="activateLicense()" class="btn btn-primary w-full justify-center"><i class="fas fa-unlock"></i> Activate</button>
  </div>`, 'md');
}
async function activateLicense() {
  const key = $('#lk-key').value.trim();
  if (!key) return showToast('License key required', 'error');
  await post('/license/activate', { license_key: key, customer_name: $('#lk-name').value, customer_email: $('#lk-email').value, plan: $('#lk-plan').value, duration_days: parseInt($('#lk-days').value)||365 });
  closeAllModals(); showToast('License activated!'); renderLicensePage();
}
async function extendTrial() { await post('/license/extend-trial', { days: 7 }); showToast('Trial extended by 7 days'); renderLicensePage(); }
async function deactivateLicense() { if (!await confirmAction('Suspend this license?')) return; await post('/license/deactivate', {}); showToast('License suspended'); renderLicensePage(); }
async function generateDemoKey() {
  const r = await post('/license/generate-key', {});
  showModal('Generated Test Key', `<div class="space-y-3 text-center">
    <p class="text-sm text-gray-500">Use this key to test activation (for demo/testing purposes):</p>
    <input class="input-field font-mono text-center" readonly value="${r.license_key}" onclick="this.select()">
    <button onclick="navigator.clipboard.writeText('${r.license_key}');showToast('Copied!')" class="btn btn-primary w-full justify-center"><i class="fas fa-copy"></i> Copy Key</button>
  </div>`, 'sm');
}

// ==================== SUPER ADMIN: Backup & Export ====================
async function downloadFullBackup() {
  showToast('Preparing backup...', 'warning');
  try {
    const headers = {}; if (APP.hotelId) headers['X-Hotel-Id'] = APP.hotelId;
    const r = await fetch('/api/admin/backup', { headers });
    if (!r.ok) throw new Error('Backup failed');
    const blob = await r.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = `pchpms_backup_${today()}.json`; a.click();
    URL.revokeObjectURL(url);
    showToast('Backup downloaded!');
  } catch (e) { showToast(e.message, 'error'); }
}

// ==================== LOYALTY ====================
async function renderLoyalty() {
  const guests = await api('/guests');
  const mc = $('#main-content');
  mc.innerHTML = `<div class="fade-in">
    <div class="mb-6"><h2 class="text-2xl font-bold text-gray-800"><i class="fas fa-award text-primary mr-2"></i>PCH PMS Loyalty Program</h2>
    <p class="text-gray-500 text-sm">Manage guest loyalty points and tiers</p></div>
    <div class="grid grid-cols-4 gap-4 mb-6">
      <div class="stat-card"><div class="w-10 h-10 rounded-xl bg-amber-100 flex items-center justify-center mb-2"><i class="fas fa-gem text-amber-600"></i></div><p class="text-2xl font-bold">${guests.filter(g=>(g.loyalty_tier||'')==='platinum').length}</p><p class="text-xs text-gray-500">Platinum (5000+ pts)</p></div>
      <div class="stat-card"><div class="w-10 h-10 rounded-xl bg-yellow-100 flex items-center justify-center mb-2"><i class="fas fa-crown text-yellow-600"></i></div><p class="text-2xl font-bold">${guests.filter(g=>(g.loyalty_tier||'')==='gold').length}</p><p class="text-xs text-gray-500">Gold (2000+ pts)</p></div>
      <div class="stat-card"><div class="w-10 h-10 rounded-xl bg-gray-200 flex items-center justify-center mb-2"><i class="fas fa-medal text-gray-500"></i></div><p class="text-2xl font-bold">${guests.filter(g=>(g.loyalty_tier||'')==='silver').length}</p><p class="text-xs text-gray-500">Silver (500+ pts)</p></div>
      <div class="stat-card"><div class="w-10 h-10 rounded-xl bg-orange-100 flex items-center justify-center mb-2"><i class="fas fa-star text-orange-600"></i></div><p class="text-2xl font-bold">${guests.filter(g=>!g.loyalty_tier||(g.loyalty_tier||'')==='bronze').length}</p><p class="text-xs text-gray-500">Bronze</p></div>
    </div>
    <div class="card p-5">
      <h3 class="font-bold mb-4">Loyalty Members</h3>
      <table class="w-full"><thead><tr class="text-left text-xs text-gray-500 border-b"><th class="pb-3">GUEST</th><th class="pb-3">TIER</th><th class="pb-3">POINTS</th><th class="pb-3">STAYS</th><th class="pb-3">TOTAL SPENT</th><th class="pb-3">ACTIONS</th></tr></thead>
      <tbody>${guests.filter(g=>(g.loyalty_points||0)>0).sort((a,b)=>(b.loyalty_points||0)-(a.loyalty_points||0)).map(g=>`<tr class="table-row border-b border-gray-50">
        <td class="py-3 text-sm font-medium">${g.first_name} ${g.last_name} ${g.vip_status?'<span class="badge badge-gold ml-1">VIP</span>':''}</td>
        <td class="py-3"><span class="badge badge-${g.loyalty_tier||'bronze'}">${(g.loyalty_tier||'bronze').toUpperCase()}</span></td>
        <td class="py-3 text-sm font-bold text-primary">${g.loyalty_points||0}</td>
        <td class="py-3 text-sm">${g.total_stays||0}</td>
        <td class="py-3 text-sm">${fmt(g.total_spent||0)}</td>
        <td class="py-3"><button onclick="showRedeemPoints(${g.id},'${esc(g.first_name+' '+g.last_name)}',${g.loyalty_points||0})" class="btn btn-outline btn-sm"><i class="fas fa-gift"></i> Redeem</button></td>
      </tr>`).join('')}</tbody></table>
      ${guests.filter(g=>(g.loyalty_points||0)>0).length===0?'<p class="text-center py-8 text-gray-400">No loyalty members yet</p>':''}
    </div>
  </div>`;
}

function showRedeemPoints(guestId, name, points) {
  showModal('Redeem Points', `<div class="space-y-4">
    <div class="p-4 bg-gray-50 rounded-xl"><p class="font-bold">${name}</p><p class="text-sm text-gray-500">Available: <span class="text-primary font-bold">${points} points</span></p></div>
    <div><label class="block text-sm font-medium mb-1">Points to Redeem *</label><input id="rd-pts" type="number" class="input-field" max="${points}" min="1"></div>
    <div><label class="block text-sm font-medium mb-1">Reason</label><input id="rd-desc" class="input-field" placeholder="e.g. Room upgrade, F&B discount"></div>
    <button onclick="doRedeem(${guestId})" class="btn btn-primary w-full justify-center"><i class="fas fa-gift"></i> Redeem</button>
  </div>`, 'sm');
}
async function doRedeem(guestId) {
  const pts = parseInt($('#rd-pts').value); if (!pts || pts <= 0) return showToast('Invalid points', 'error');
  await post('/loyalty/redeem', { guest_id: guestId, points: pts, description: $('#rd-desc').value || 'Points redeemed' });
  closeAllModals(); showToast('Points redeemed!'); renderLoyalty();
}

// ==================== STAFF ====================
async function renderStaff() {
  const users = await api('/users');
  const mc = $('#main-content');
  mc.innerHTML = `<div class="fade-in">
    <div class="flex items-center justify-between mb-6">
      <div><h2 class="text-2xl font-bold text-gray-800">Staff Management</h2></div>
      <button onclick="showAddStaff()" class="btn btn-primary"><i class="fas fa-plus"></i> Add Staff</button>
    </div>
    <div class="card p-5"><table class="w-full"><thead><tr class="text-left text-xs text-gray-500 border-b"><th class="pb-3">NAME</th><th class="pb-3">USERNAME</th><th class="pb-3">ROLE</th><th class="pb-3">EMAIL</th><th class="pb-3">STATUS</th><th class="pb-3">LAST LOGIN</th><th class="pb-3">ACTIONS</th></tr></thead>
    <tbody>${users.map(u=>`<tr class="table-row border-b border-gray-50">
      <td class="py-3 flex items-center gap-3"><div class="w-9 h-9 rounded-xl bg-primary/10 flex items-center justify-center"><span class="text-primary font-bold text-xs">${u.full_name.split(' ').map(n=>n[0]).join('')}</span></div><span class="text-sm font-medium">${u.full_name}</span></td>
      <td class="py-3 text-sm text-gray-500">@${u.username}</td>
      <td class="py-3"><span class="badge ${u.role==='super_admin'?'badge-danger':u.role==='admin'?'badge-primary':u.role==='manager'?'badge-info':u.role==='receptionist'?'badge-success':'badge-warning'}">${u.role.replace('_',' ')}</span></td>
      <td class="py-3 text-sm text-gray-500">${u.email||'-'}</td>
      <td class="py-3"><span class="badge ${u.is_active?'badge-success':'badge-danger'}">${u.is_active?'Active':'Inactive'}</span></td>
      <td class="py-3 text-sm text-gray-400">${u.last_login?fmtDateTime(u.last_login):'Never'}</td>
      <td class="py-3 flex gap-1">
        <button onclick="showEditStaff(${u.id})" class="btn btn-outline btn-sm"><i class="fas fa-edit"></i></button>
        <button onclick="resetStaffPw(${u.id})" class="btn btn-outline btn-sm"><i class="fas fa-key"></i></button>
        ${u.role!=='super_admin'?`<button onclick="toggleStaffActive(${u.id},${u.is_active})" class="btn ${u.is_active?'btn-danger':'btn-success'} btn-sm"><i class="fas ${u.is_active?'fa-ban':'fa-check'}"></i></button>`:''}
      </td>
    </tr>`).join('')}</tbody></table></div>
  </div>`;
}

function showAddStaff() {
  showModal('Add Staff', `<div class="space-y-4"><div class="grid grid-cols-2 gap-4">
    <div><label class="block text-sm font-medium mb-1">Full Name *</label><input id="as-name" class="input-field"></div>
    <div><label class="block text-sm font-medium mb-1">Username *</label><input id="as-user" class="input-field"></div>
    <div><label class="block text-sm font-medium mb-1">Password</label><input id="as-pass" class="input-field" type="password" value="password123"></div>
    <div><label class="block text-sm font-medium mb-1">Role *</label><select id="as-role" class="input-field"><option value="receptionist">Receptionist</option><option value="manager">Manager</option><option value="housekeeping">Housekeeping</option><option value="admin">Admin</option>${isSuperAdmin()?'<option value="super_admin">Super Admin</option>':''}</select></div>
    <div><label class="block text-sm font-medium mb-1">Email</label><input id="as-email" class="input-field"></div>
    <div><label class="block text-sm font-medium mb-1">Phone</label><input id="as-phone" class="input-field"></div>
  </div><button onclick="createStaff()" class="btn btn-primary w-full justify-center">Create</button></div>`, 'md');
}
async function createStaff() {
  const name=$('#as-name').value,user=$('#as-user').value; if(!name||!user)return showToast('Name & username required','error');
  const role=$('#as-role').value;
  const dp = role==='admin'||role==='manager'||role==='super_admin'?{all:true}:role==='receptionist'?{dashboard:true,reservations:true,checkin:true,guests:true,rooms:true,payments:true,invoices:true,shifts:true,pos:true,arrivals:true,inhouse:true,messaging:true}:role==='housekeeping'?{housekeeping:true,rooms_status:true}:{reports:true,payments:true};
  await post('/users',{full_name:name,username:user,password:$('#as-pass').value||'password123',role,email:$('#as-email').value,phone:$('#as-phone').value,permissions:dp,created_by:APP.user.id});
  closeAllModals(); showToast('Created!'); renderStaff();
}
async function showEditStaff(id) {
  const users=await api('/users'); const u=users.find(x=>x.id===id); if(!u)return;
  showModal('Edit Staff',`<div class="space-y-4"><div class="grid grid-cols-2 gap-4"><div><label class="block text-sm font-medium mb-1">Name</label><input id="es-name" class="input-field" value="${u.full_name}"></div><div><label class="block text-sm font-medium mb-1">Role</label><select id="es-role" class="input-field"><option value="receptionist" ${u.role==='receptionist'?'selected':''}>Receptionist</option><option value="manager" ${u.role==='manager'?'selected':''}>Manager</option><option value="housekeeping" ${u.role==='housekeeping'?'selected':''}>Housekeeping</option><option value="admin" ${u.role==='admin'?'selected':''}>Admin</option></select></div><div><label class="block text-sm font-medium mb-1">Email</label><input id="es-email" class="input-field" value="${u.email||''}"></div><div><label class="block text-sm font-medium mb-1">Phone</label><input id="es-phone" class="input-field" value="${u.phone||''}"></div></div><button onclick="updateStaff(${id})" class="btn btn-primary w-full justify-center">Update</button></div>`,'md');
}
async function updateStaff(id) { await put(`/users/${id}`,{full_name:$('#es-name').value,role:$('#es-role').value,email:$('#es-email').value,phone:$('#es-phone').value}); closeAllModals(); showToast('Updated!'); renderStaff(); }
async function resetStaffPw(id) { if(!await confirmAction('Reset password to password123?'))return; await put(`/users/${id}/reset-password`,{new_password:'password123'}); showToast('Password reset'); }
async function toggleStaffActive(id,active) { if(!await confirmAction(`${active?'Deactivate':'Activate'} this user?`))return; await put(`/users/${id}`,{is_active:active?0:1}); showToast(`${active?'Deactivated':'Activated'}!`); renderStaff(); }

// ==================== SETTINGS ====================
async function renderSettings() {
  const prop = await api('/settings/property');
  const mc = $('#main-content');
  mc.innerHTML = `<div class="fade-in"><div class="mb-6"><h2 class="text-2xl font-bold text-gray-800">Settings</h2></div>
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <div class="card p-6"><h3 class="font-bold mb-4 flex items-center justify-between"><span><i class="fas fa-hotel text-primary mr-2"></i>Hotel Information</span><span class="badge badge-primary">Property ID #${prop.id}</span></h3>
        <div class="space-y-4"><div class="grid grid-cols-2 gap-4">
          <div><label class="block text-sm font-medium mb-1">Name</label><input id="sp-name" class="input-field" value="${prop.name||''}"></div>
          <div><label class="block text-sm font-medium mb-1">Address</label><input id="sp-addr" class="input-field" value="${prop.address||''}"></div>
          <div><label class="block text-sm font-medium mb-1">City</label><input id="sp-city" class="input-field" value="${prop.city||''}"></div>
          <div><label class="block text-sm font-medium mb-1">Country</label><input id="sp-country" class="input-field" value="${prop.country||''}"></div>
          <div><label class="block text-sm font-medium mb-1">Phone</label><input id="sp-phone" class="input-field" value="${prop.phone||''}"></div>
          <div><label class="block text-sm font-medium mb-1">Email</label><input id="sp-email" class="input-field" value="${prop.email||''}"></div>
        </div><button onclick="saveSettings()" class="btn btn-primary"><i class="fas fa-save"></i> Save</button></div></div>
      <div class="card p-6"><h3 class="font-bold mb-4"><i class="fas fa-cog text-primary mr-2"></i>System</h3>
        <div class="space-y-4"><div class="grid grid-cols-2 gap-4">
          <div><label class="block text-sm font-medium mb-1">Currency</label><input id="sp-cur" class="input-field" value="${prop.currency||'₦'}"></div>
          <div><label class="block text-sm font-medium mb-1">Tax Rate (%)</label><input id="sp-tax" class="input-field" type="number" value="${prop.tax_rate||7.5}" step="0.1"></div>
          <div><label class="block text-sm font-medium mb-1">Check-in Time</label><input id="sp-ci" class="input-field" type="time" value="${prop.checkin_time||'14:00'}"></div>
          <div><label class="block text-sm font-medium mb-1">Check-out Time</label><input id="sp-co" class="input-field" type="time" value="${prop.checkout_time||'12:00'}"></div>
        </div><button onclick="saveSettings()" class="btn btn-primary"><i class="fas fa-save"></i> Save</button></div></div>
    </div>
    <div class="card p-6 mt-6"><h3 class="font-bold mb-4"><i class="fas fa-history text-primary mr-2"></i>Activity Log</h3><div id="activity-log"></div></div>
  </div>`;
  loadActivityLog();
}
async function saveSettings() {
  const newName = $('#sp-name').value;
  const newCity = $('#sp-city').value;
  const newCountry = $('#sp-country').value;
  const newCurrency = $('#sp-cur').value;
  await put('/settings/property',{name:newName,address:$('#sp-addr').value,city:newCity,country:newCountry,phone:$('#sp-phone').value,email:$('#sp-email').value,currency:newCurrency,tax_rate:parseFloat($('#sp-tax').value),checkin_time:$('#sp-ci').value,checkout_time:$('#sp-co').value});
  APP.currency = newCurrency;
  APP.hotelName = newName;
  APP.hotelCity = newCity + (newCountry ? ', ' + newCountry : '');
  localStorage.setItem('ps_currency', APP.currency);
  localStorage.setItem('ps_hotel_name', APP.hotelName);
  localStorage.setItem('ps_hotel_city', APP.hotelCity);
  // Update user object
  if (APP.user) { APP.user.hotel_name = newName; APP.user.hotel_currency = newCurrency; APP.user.hotel_city = APP.hotelCity; localStorage.setItem('ps_user', JSON.stringify(APP.user)); }
  // Update hotels list if super_admin
  if (isSuperAdmin() && APP.hotels.length > 0) {
    const idx = APP.hotels.findIndex(h => h.id == APP.hotelId);
    if (idx >= 0) { APP.hotels[idx].name = newName; APP.hotels[idx].city = newCity; APP.hotels[idx].country = newCountry; APP.hotels[idx].currency = newCurrency; localStorage.setItem('ps_hotels', JSON.stringify(APP.hotels)); }
  }
  showToast('Settings saved!');
  // Re-render the app to update sidebar and header
  renderApp();
}
async function loadActivityLog() {
  const logs=await api('/activity-log'); const c=$('#activity-log'); if(!c)return;
  c.innerHTML=logs.length===0?'<p class="text-gray-400 text-center py-4">No activity</p>':`<div class="space-y-2 max-h-96 overflow-y-auto">${logs.map(l=>`<div class="flex items-center gap-3 p-3 bg-gray-50 rounded-xl text-sm"><div class="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0"><i class="fas fa-history text-primary text-xs"></i></div><div class="flex-1"><span class="font-medium">${l.user_name||'System'}</span> <span class="text-gray-500">${l.action}</span> <span class="text-gray-400 text-xs">${l.details||''}</span></div><span class="text-xs text-gray-400 flex-shrink-0">${fmtDateTime(l.created_at)}</span></div>`).join('')}</div>`;
}

// ==================== PWA INSTALL ====================
let deferredInstallPrompt = null;
let pwaInstalled = false;

window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  deferredInstallPrompt = e;
  showInstallButton();
});

window.addEventListener('appinstalled', () => {
  pwaInstalled = true;
  deferredInstallPrompt = null;
  hideInstallButton();
  showToast('PCH PMS installed! You can now open it from your desktop.', 'success');
});

function showInstallButton() {
  const btn = document.getElementById('pwa-install-btn');
  if (btn) btn.classList.remove('hidden');
}

function hideInstallButton() {
  const btn = document.getElementById('pwa-install-btn');
  if (btn) btn.classList.add('hidden');
}

async function installPWA() {
  if (!deferredInstallPrompt) {
    showToast('App is already installed or installation is not available', 'warning');
    return;
  }
  deferredInstallPrompt.prompt();
  const { outcome } = await deferredInstallPrompt.userChoice;
  if (outcome === 'accepted') {
    showToast('Installing PCH PMS...', 'success');
  }
  deferredInstallPrompt = null;
}

// ==================== OFFLINE / PWA ====================
const OfflineDB = {
  dbName: 'PCHPMSOffline',
  dbVersion: 1,
  db: null,
  stores: ['rooms', 'reservations', 'guests', 'roomTypes', 'folios', 'housekeeping', 'syncQueue'],

  async init() {
    return new Promise((resolve, reject) => {
      const req = indexedDB.open(this.dbName, this.dbVersion);
      req.onupgradeneeded = (e) => {
        const db = e.target.result;
        this.stores.forEach(name => {
          if (!db.objectStoreNames.contains(name)) {
            const store = db.createObjectStore(name, { keyPath: name === 'syncQueue' ? 'queueId' : 'id' });
            if (name === 'syncQueue') store.createIndex('status', 'status');
          }
        });
      };
      req.onsuccess = (e) => { this.db = e.target.result; resolve(this.db); };
      req.onerror = (e) => reject(e);
    });
  },

  async putAll(storeName, items) {
    if (!this.db) await this.init();
    const tx = this.db.transaction(storeName, 'readwrite');
    const store = tx.objectStore(storeName);
    items.forEach(item => store.put(item));
    return new Promise((resolve, reject) => { tx.oncomplete = resolve; tx.onerror = reject; });
  },

  async getAll(storeName) {
    if (!this.db) await this.init();
    const tx = this.db.transaction(storeName, 'readonly');
    const store = tx.objectStore(storeName);
    return new Promise((resolve, reject) => {
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result);
      req.onerror = reject;
    });
  },

  async put(storeName, item) {
    if (!this.db) await this.init();
    const tx = this.db.transaction(storeName, 'readwrite');
    const store = tx.objectStore(storeName);
    store.put(item);
    return new Promise((resolve, reject) => { tx.oncomplete = resolve; tx.onerror = reject; });
  },

  async addToSyncQueue(op) {
    op.queueId = 'sq_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5);
    op.status = 'pending';
    op.created_at = new Date().toISOString();
    await this.put('syncQueue', op);
    updateSyncBadge();
    return op;
  },

  async getPendingSync() {
    const all = await this.getAll('syncQueue');
    return all.filter(q => q.status === 'pending');
  },

  async markSynced(queueId) {
    if (!this.db) await this.init();
    const tx = this.db.transaction('syncQueue', 'readwrite');
    const store = tx.objectStore('syncQueue');
    const req = store.get(queueId);
    req.onsuccess = () => {
      const item = req.result;
      if (item) { item.status = 'synced'; item.synced_at = new Date().toISOString(); store.put(item); }
    };
  },

  async clearSynced() {
    const all = await this.getAll('syncQueue');
    const tx = this.db.transaction('syncQueue', 'readwrite');
    const store = tx.objectStore('syncQueue');
    all.filter(q => q.status === 'synced').forEach(q => store.delete(q.queueId));
  }
};

// Online/Offline detection
let isOnline = navigator.onLine;
let syncInProgress = false;
let lastSyncTime = localStorage.getItem('ps_last_sync') || null;

function updateOnlineStatus() {
  isOnline = navigator.onLine;
  const bar = document.getElementById('offline-bar');
  if (bar) {
    if (!isOnline) {
      bar.classList.add('show');
      bar.innerHTML = `<div class="flex items-center justify-center gap-3">
        <i class="fas fa-wifi-slash"></i>
        <span>You are offline. Changes will sync when connection returns.</span>
        <span class="ml-auto text-xs opacity-75">${lastSyncTime ? 'Last synced: ' + fmtDateTime(lastSyncTime) : 'Never synced'}</span>
      </div>`;
    } else {
      bar.classList.remove('show');
    }
  }
  updateSyncStatusUI();
  if (isOnline && !syncInProgress) {
    // Small delay to ensure network is stable
    setTimeout(() => syncPendingChanges(), 1000);
  }
}

window.addEventListener('online', () => {
  updateOnlineStatus();
  showToast('Back online! Syncing changes...', 'success');
});
window.addEventListener('offline', () => {
  updateOnlineStatus();
  showToast('You are offline. Changes will be saved locally.', 'warning');
});

// Listen for service worker sync messages
if (navigator.serviceWorker) {
  navigator.serviceWorker.addEventListener('message', (event) => {
    if (event.data?.type === 'SYNC_REQUESTED') {
      syncPendingChanges();
    }
  });
}

function updateSyncStatusUI() {
  // Update the sync status in sidebar/header
  const syncStatus = document.getElementById('sync-status');
  if (syncStatus) {
    OfflineDB.getPendingSync().then(pending => {
      const pendingCount = pending.length;
      const lastSync = localStorage.getItem('ps_last_sync');
      let html = '';
      if (!isOnline) {
        html = `<div class="flex items-center gap-2 text-xs">
          <span class="w-2 h-2 rounded-full bg-red-400 animate-pulse"></span>
          <span class="text-white/60">Offline</span>
          ${pendingCount > 0 ? `<span class="bg-orange-500/80 text-white text-[10px] px-1.5 py-0.5 rounded-full">${pendingCount} pending</span>` : ''}
        </div>`;
      } else {
        html = `<div class="flex items-center gap-2 text-xs">
          <span class="w-2 h-2 rounded-full bg-green-400"></span>
          <span class="text-white/60">Online</span>
          ${pendingCount > 0 ? `<span class="bg-orange-500/80 text-white text-[10px] px-1.5 py-0.5 rounded-full">${pendingCount} syncing</span>` : ''}
        </div>`;
      }
      if (lastSync) {
        html += `<p class="text-[10px] text-white/40 mt-0.5">Synced: ${fmtDateTime(lastSync)}</p>`;
      }
      syncStatus.innerHTML = html;
    }).catch(() => {});
  }
}

async function updateSyncBadge() {
  try {
    const pending = await OfflineDB.getPendingSync();
    const bar = document.getElementById('sync-bar');
    if (bar && pending.length > 0) {
      bar.classList.add('show');
      if (isOnline && syncInProgress) {
        bar.innerHTML = '<i class="fas fa-sync fa-spin"></i> Syncing ' + pending.length + ' changes...';
        bar.style.background = '#FF9800';
      } else if (!isOnline) {
        bar.innerHTML = '<i class="fas fa-clock"></i> ' + pending.length + ' changes pending sync';
        bar.style.background = '#6C63FF';
      } else {
        bar.classList.remove('show');
      }
    } else if (bar) {
      bar.classList.remove('show');
    }
    updateSyncStatusUI();
  } catch(e) {}
}

async function syncPendingChanges() {
  if (syncInProgress || !isOnline) return;
  syncInProgress = true;
  const bar = document.getElementById('sync-bar');
  try {
    const pending = await OfflineDB.getPendingSync();
    if (pending.length === 0) { syncInProgress = false; updateSyncBadge(); return; }
    if (bar) { bar.classList.add('show'); bar.innerHTML = '<i class="fas fa-sync fa-spin"></i> Syncing ' + pending.length + ' changes...'; bar.style.background = '#FF9800'; }
    
    // Sort by timestamp to process in order
    pending.sort((a, b) => new Date(a.created_at) - new Date(b.created_at));
    
    const result = await post('/sync/push', { operations: pending });
    let synced = 0, conflicts = 0;
    for (const r of (result.results || [])) {
      if (r.success) {
        await OfflineDB.markSynced(r.id);
        synced++;
      } else if (r.conflict) {
        // Mark as conflict for admin resolution
        const item = pending.find(p => p.queueId === r.id);
        if (item) { item.status = 'conflict'; item.error = r.error; await OfflineDB.put('syncQueue', item); }
        conflicts++;
      }
    }
    await OfflineDB.clearSynced();
    
    if (synced > 0) showToast(`${synced} changes synced successfully!`);
    if (conflicts > 0) showToast(`${conflicts} conflicts detected - please review`, 'warning');
    
    // Refresh data after sync
    await syncDataFromServer();
    // Refresh current page to show updated data
    if (APP.currentPage) navigate(APP.currentPage);
  } catch (e) {
    console.error('Sync failed:', e);
  } finally {
    syncInProgress = false;
    if (bar) bar.classList.remove('show');
    updateSyncBadge();
  }
}

async function syncDataFromServer() {
  if (!isOnline || !APP.hotelId) return;
  try {
    const data = await api('/sync/data');
    await OfflineDB.init();
    if (data.rooms) await OfflineDB.putAll('rooms', data.rooms);
    if (data.reservations) await OfflineDB.putAll('reservations', data.reservations);
    if (data.guests) await OfflineDB.putAll('guests', data.guests);
    if (data.roomTypes) await OfflineDB.putAll('roomTypes', data.roomTypes);
    lastSyncTime = data.syncedAt;
    localStorage.setItem('ps_last_sync', data.syncedAt);
    updateSyncStatusUI();
  } catch (e) { console.error('Data sync failed:', e); }
}

// Auto-sync every 3 minutes when online
setInterval(() => { 
  if (isOnline && APP.hotelId) {
    syncDataFromServer();
    syncPendingChanges();
  }
  updateSyncBadge();
}, 180000);

// ==================== INIT ====================
document.addEventListener('DOMContentLoaded', async () => {
  // Initialize offline DB
  try { await OfflineDB.init(); } catch(e) { console.log('IndexedDB init error:', e); }
  
  // Update online status
  updateOnlineStatus();
  
  // Register service worker for PWA
  if ('serviceWorker' in navigator) {
    try {
      const reg = await navigator.serviceWorker.register('/static/sw.js');
      // Check for updates
      reg.addEventListener('updatefound', () => {
        const newWorker = reg.installing;
        newWorker.addEventListener('statechange', () => {
          if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
            // New version available
            showToast('New version available! Reload to update.', 'info');
          }
        });
      });
      console.log('Service Worker registered');
    } catch(e) { 
      console.log('SW registration error:', e); 
    }
  }
  
  // Check if app is already installed (standalone mode)
  if (window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone) {
    pwaInstalled = true;
  }
  
  // Render app
  if (APP.user) {
    if (isSuperAdmin() && !APP.hotelId && APP.hotels.length > 0) {
      showHotelSelector(APP.hotels);
    } else {
      renderApp();
      // Sync data in background
      syncDataFromServer();
      // Check for pending syncs
      updateSyncBadge();
    }
  } else {
    renderLogin();
  }
  
  // Show install button if prompt is available
  if (deferredInstallPrompt) showInstallButton();
});
