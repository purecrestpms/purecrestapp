// Live room status computation.
//
// Historically this app stored a single `rooms.status` column that was mutated
// imperatively on every check-in/check-out/cancel. That caused the reported bugs:
// a room booked for *next week* stayed stuck on "reserved" forever (even though
// it's free today), and a room that was checked-out could still show "occupied"
// if a write was missed. Instead, "available / occupied / reserved" are now
// derived live from the reservations + room_blocks tables for a given date
// (normally today). The only thing that is still persisted is
// `rooms.housekeeping_status`, which covers states a computer can't infer on
// its own: vacant_clean, vacant_dirty, and the manual out_of_order override.

export type HousekeepingStatus = 'vacant_clean' | 'vacant_dirty' | 'occupied' | 'reserved' | 'out_of_order';
export const HOUSEKEEPING_STATUSES: HousekeepingStatus[] = ['vacant_clean', 'vacant_dirty', 'occupied', 'reserved', 'out_of_order'];
// Statuses a human can pick manually from the UI; occupied/reserved are always derived.
export const MANUAL_HOUSEKEEPING_STATUSES: HousekeepingStatus[] = ['vacant_clean', 'vacant_dirty', 'out_of_order'];

export interface LiveRoomStatus {
  status: 'available' | 'occupied' | 'reserved' | 'maintenance';
  housekeeping_status: HousekeepingStatus;
}

// Computes the live operational + housekeeping status for every room in a hotel,
// as of `dateStr` (YYYY-MM-DD, defaults to "today"). Call once per request and
// look up by room id - much cheaper than N correlated subqueries.
export async function computeLiveRoomStatuses(db: D1Database, hotelId: number, dateStr: string): Promise<Record<number, LiveRoomStatus>> {
  const roomsRes = await db.prepare(`SELECT id, room_type_id, housekeeping_status FROM rooms WHERE hotel_id = ?`).bind(hotelId).all<any>();
  const rooms = roomsRes.results || [];
  const map: Record<number, LiveRoomStatus> = {};
  for (const r of rooms) {
    const hk: HousekeepingStatus = (r.housekeeping_status || 'vacant_clean') as HousekeepingStatus;
    map[r.id] = { status: hk === 'out_of_order' ? 'maintenance' : 'available', housekeeping_status: hk };
  }

  const resRows = await db.prepare(`
    SELECT room_id, status FROM reservations
    WHERE hotel_id = ? AND room_id IS NOT NULL AND status IN ('reserved','checked-in')
      AND check_in_date <= ? AND check_out_date > ?`).bind(hotelId, dateStr, dateStr).all<any>();
  for (const row of (resRows.results || [])) {
    const entry = map[row.room_id];
    if (!entry || entry.status === 'maintenance') continue; // out-of-order always wins
    entry.status = row.status === 'checked-in' ? 'occupied' : 'reserved';
    entry.housekeeping_status = entry.status as HousekeepingStatus;
  }

  const blockRows = await db.prepare(`
    SELECT room_id, room_type_id FROM room_blocks WHERE hotel_id = ? AND start_date <= ? AND end_date > ?`)
    .bind(hotelId, dateStr, dateStr).all<any>();
  for (const b of (blockRows.results || [])) {
    const targetIds: number[] = b.room_id ? [b.room_id] : rooms.filter((r: any) => r.room_type_id === b.room_type_id).map((r: any) => r.id);
    for (const rid of targetIds) {
      const entry = map[rid];
      if (!entry || entry.status === 'maintenance' || entry.status === 'occupied') continue;
      entry.status = 'reserved';
    }
  }

  return map;
}

// Single-room convenience wrapper (used by the room detail endpoint).
export async function computeLiveRoomStatus(db: D1Database, hotelId: number, roomId: number, dateStr: string): Promise<LiveRoomStatus | null> {
  const all = await computeLiveRoomStatuses(db, hotelId, dateStr);
  return all[roomId] || null;
}
