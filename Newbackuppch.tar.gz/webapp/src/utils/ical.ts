// Minimal iCal (RFC5545) VEVENT parser/generator sufficient for OTA availability feeds
// (Booking.com, Airbnb, Expedia and most channel managers expose simple DTSTART/DTEND/UID/SUMMARY events)

export interface ICalEvent {
  uid: string;
  summary: string;
  dtstart: string; // YYYY-MM-DD
  dtend: string;   // YYYY-MM-DD (exclusive, per iCal convention used by OTAs)
  description?: string;
}

function toDateStr(v: string): string {
  // Handle both DATE (YYYYMMDD) and DATE-TIME (YYYYMMDDTHHMMSSZ) forms
  const digits = v.replace(/[^0-9]/g, '').slice(0, 8);
  if (digits.length < 8) return v;
  return `${digits.slice(0, 4)}-${digits.slice(4, 6)}-${digits.slice(6, 8)}`;
}

export function parseICal(text: string): ICalEvent[] {
  const events: ICalEvent[] = [];
  // Unfold lines (lines starting with space/tab continue the previous line)
  const unfolded = text.replace(/\r\n[ \t]/g, '').replace(/\n[ \t]/g, '');
  const lines = unfolded.split(/\r\n|\n/);
  let cur: any = null;
  for (const raw of lines) {
    const line = raw.trim();
    if (line === 'BEGIN:VEVENT') { cur = {}; continue; }
    if (line === 'END:VEVENT') { if (cur && cur.dtstart && cur.dtend) events.push(cur as ICalEvent); cur = null; continue; }
    if (!cur) continue;
    const idx = line.indexOf(':');
    if (idx === -1) continue;
    const keyPart = line.substring(0, idx);
    const value = line.substring(idx + 1);
    const key = keyPart.split(';')[0].toUpperCase();
    if (key === 'UID') cur.uid = value;
    else if (key === 'SUMMARY') cur.summary = value;
    else if (key === 'DESCRIPTION') cur.description = value;
    else if (key === 'DTSTART') cur.dtstart = toDateStr(value);
    else if (key === 'DTEND') cur.dtend = toDateStr(value);
  }
  return events;
}

export function generateICal(hotelName: string, events: { uid: string; summary: string; start: string; end: string; description?: string }[]): string {
  const lines = [
    'BEGIN:VCALENDAR',
    'VERSION:2.0',
    'PRODID:-//PCH PMS//Channel Manager//EN',
    'CALSCALE:GREGORIAN',
    `X-WR-CALNAME:${hotelName} Availability`,
  ];
  for (const e of events) {
    lines.push('BEGIN:VEVENT');
    lines.push(`UID:${e.uid}`);
    lines.push(`DTSTAMP:${new Date().toISOString().replace(/[-:]/g, '').split('.')[0]}Z`);
    lines.push(`DTSTART;VALUE=DATE:${e.start.replace(/-/g, '')}`);
    lines.push(`DTEND;VALUE=DATE:${e.end.replace(/-/g, '')}`);
    lines.push(`SUMMARY:${e.summary}`);
    if (e.description) lines.push(`DESCRIPTION:${e.description}`);
    lines.push('END:VEVENT');
  }
  lines.push('END:VCALENDAR');
  return lines.join('\r\n');
}
