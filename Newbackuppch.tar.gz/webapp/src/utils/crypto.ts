// Password hashing using Web Crypto API (available in Cloudflare Workers runtime)
// Format stored in DB: `${saltHex}:${hashHex}`

function toHex(buf: ArrayBuffer): string {
  return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join('');
}

function fromHex(hex: string): Uint8Array {
  const bytes = new Uint8Array(hex.length / 2);
  for (let i = 0; i < hex.length; i += 2) bytes[i / 2] = parseInt(hex.substring(i, i + 2), 16);
  return bytes;
}

async function sha256Hex(data: string): Promise<string> {
  const enc = new TextEncoder().encode(data);
  const digest = await crypto.subtle.digest('SHA-256', enc);
  return toHex(digest);
}

export async function hashPassword(password: string, saltHex?: string): Promise<string> {
  const salt = saltHex || toHex(crypto.getRandomValues(new Uint8Array(16)).buffer);
  // Stretch with multiple rounds of SHA-256 to slow down brute force a bit
  let value = salt + ':' + password;
  for (let i = 0; i < 1000; i++) {
    value = await sha256Hex(value);
  }
  return `${salt}:${value}`;
}

export async function verifyPassword(password: string, stored: string): Promise<boolean> {
  if (!stored || !stored.includes(':')) return false;
  const [salt] = stored.split(':');
  const recomputed = await hashPassword(password, salt);
  return recomputed === stored;
}

export function genToken(len = 24): string {
  return toHex(crypto.getRandomValues(new Uint8Array(len)).buffer);
}

export function genCode(prefix: string): string {
  const rand = Math.random().toString(36).substring(2, 7).toUpperCase();
  const ts = Date.now().toString(36).toUpperCase().slice(-4);
  return `${prefix}-${ts}${rand}`;
}
