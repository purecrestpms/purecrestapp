import type { Context } from 'hono';

export function getHotelId(c: Context): number | null {
  const h = c.req.header('X-Hotel-Id');
  if (!h) return null;
  const n = parseInt(h);
  return isNaN(n) ? null : n;
}

export async function logActivity(db: D1Database, hotelId: number | null, userId: number | null, userName: string | null, action: string, details: string = '') {
  try {
    await db.prepare(`INSERT INTO activity_log (hotel_id, user_id, user_name, action, details) VALUES (?, ?, ?, ?, ?)`)
      .bind(hotelId, userId, userName, action, details).run();
  } catch (e) { /* non-fatal */ }
}

export function nightsBetween(ci: string, co: string): number {
  const d1 = new Date(ci + 'T00:00:00Z').getTime();
  const d2 = new Date(co + 'T00:00:00Z').getTime();
  return Math.max(1, Math.round((d2 - d1) / 86400000));
}

export function datesOverlap(aStart: string, aEnd: string, bStart: string, bEnd: string): boolean {
  // Standard hotel date-range overlap: [start, end) intervals overlap if aStart < bEnd && bStart < aEnd
  return aStart < bEnd && bStart < aEnd;
}

export function todayStr(): string {
  return new Date().toISOString().split('T')[0];
}
