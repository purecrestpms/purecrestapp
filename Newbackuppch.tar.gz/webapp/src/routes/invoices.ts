import { Hono } from 'hono';
import type { AppEnv } from '../types';
import { getHotelId } from '../utils/helpers';
import { genCode } from '../utils/crypto';

const invoices = new Hono<AppEnv>();

invoices.get('/', async (c) => {
  const hotelId = getHotelId(c);
  const rows = await c.env.DB.prepare(`
    SELECT i.*, g.first_name, g.last_name, rm.room_number FROM invoices i
    JOIN guests g ON g.id = i.guest_id
    LEFT JOIN reservations r ON r.id = i.reservation_id
    LEFT JOIN rooms rm ON rm.id = r.room_id
    WHERE i.hotel_id = ? ORDER BY i.created_at DESC`).bind(hotelId).all();
  return c.json(rows.results || []);
});

invoices.get('/:id', async (c) => {
  const id = c.req.param('id');
  const db = c.env.DB;
  const i = await db.prepare(`
    SELECT i.*, g.first_name, g.last_name, g.email, rm.room_number, h.name as hotel_name
    FROM invoices i JOIN guests g ON g.id = i.guest_id
    LEFT JOIN reservations r ON r.id = i.reservation_id
    LEFT JOIN rooms rm ON rm.id = r.room_id
    LEFT JOIN hotels h ON h.id = i.hotel_id
    WHERE i.id = ?`).bind(id).first();
  if (!i) return c.json({ error: 'Invoice not found' }, 404);
  return c.json(i);
});

invoices.post('/', async (c) => {
  const hotelId = getHotelId(c);
  const b = await c.req.json();
  const db = c.env.DB;
  const invNum = genCode('INV');
  const r = await db.prepare(`
    INSERT INTO invoices (hotel_id, invoice_number, reservation_id, guest_id, subtotal, tax_amount, discount_amount, total_amount, amount_paid, balance_due, status, items, created_by)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
    .bind(hotelId, invNum, b.reservation_id || null, b.guest_id, b.subtotal || 0, b.tax_amount || 0, b.discount_amount || 0, b.total_amount || 0, b.amount_paid || 0, b.balance_due || 0, b.status || 'draft', JSON.stringify(b.items || []), b.created_by || null)
    .run();
  return c.json({ id: r.meta.last_row_id, invoice_number: invNum, success: true });
});

invoices.put('/:id', async (c) => {
  const id = c.req.param('id');
  const b = await c.req.json();
  const db = c.env.DB;
  const fields: string[] = []; const vals: any[] = [];
  for (const k of ['status', 'amount_paid', 'balance_due']) {
    if (b[k] !== undefined) { fields.push(`${k}=?`); vals.push(b[k]); }
  }
  if (fields.length === 0) return c.json({ success: true });
  vals.push(id);
  await db.prepare(`UPDATE invoices SET ${fields.join(', ')} WHERE id = ?`).bind(...vals).run();
  return c.json({ success: true });
});

invoices.delete('/:id', async (c) => {
  const id = c.req.param('id');
  await c.env.DB.prepare(`DELETE FROM invoices WHERE id = ?`).bind(id).run();
  return c.json({ success: true });
});

export default invoices;
