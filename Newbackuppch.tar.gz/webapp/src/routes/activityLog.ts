import { Hono } from 'hono';
import type { AppEnv } from '../types';
import { getHotelId } from '../utils/helpers';

const activityLog = new Hono<AppEnv>();

activityLog.get('/', async (c) => {
  const hotelId = getHotelId(c);
  const rows = await c.env.DB.prepare(`SELECT * FROM activity_log WHERE hotel_id = ? ORDER BY created_at DESC LIMIT 100`).bind(hotelId).all();
  return c.json(rows.results || []);
});

export default activityLog;
