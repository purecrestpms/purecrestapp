import { Hono } from 'hono';
import type { AppEnv } from '../types';
import { getHotelId, logActivity } from '../utils/helpers';

const teams = new Hono<AppEnv>();

teams.get('/', async (c) => {
  const hotelId = getHotelId(c);
  const db = c.env.DB;
  const rows = await db.prepare(`SELECT * FROM teams WHERE hotel_id = ? ORDER BY name`).bind(hotelId).all<any>();
  const list = rows.results || [];
  for (const t of list) {
    const members = await db.prepare(`
      SELECT tm.*, u.full_name, u.username, u.role, u.email FROM team_members tm
      JOIN users u ON u.id = tm.user_id WHERE tm.team_id = ? ORDER BY u.full_name`).bind(t.id).all();
    t.members = members.results || [];
  }
  return c.json(list);
});

teams.post('/', async (c) => {
  const hotelId = getHotelId(c);
  const b = await c.req.json();
  if (!b.name) return c.json({ error: 'Team name required' }, 400);
  const db = c.env.DB;
  const r = await db.prepare(`INSERT INTO teams (hotel_id, name, description, color, created_by) VALUES (?, ?, ?, ?, ?)`)
    .bind(hotelId, b.name, b.description || '', b.color || '#6C63FF', b.created_by || null).run();
  await logActivity(db, hotelId, b.created_by, null, 'Created team', b.name);
  return c.json({ id: r.meta.last_row_id, success: true });
});

teams.put('/:id', async (c) => {
  const id = c.req.param('id');
  const b = await c.req.json();
  await c.env.DB.prepare(`UPDATE teams SET name=?, description=?, color=? WHERE id=?`)
    .bind(b.name, b.description || '', b.color || '#6C63FF', id).run();
  return c.json({ success: true });
});

teams.delete('/:id', async (c) => {
  const id = c.req.param('id');
  const db = c.env.DB;
  await db.prepare(`DELETE FROM team_members WHERE team_id = ?`).bind(id).run();
  await db.prepare(`DELETE FROM teams WHERE id = ?`).bind(id).run();
  return c.json({ success: true });
});

// Assign a staff member to a team
teams.post('/:id/members', async (c) => {
  const id = c.req.param('id');
  const b = await c.req.json();
  if (!b.user_id) return c.json({ error: 'user_id required' }, 400);
  const db = c.env.DB;
  const existing = await db.prepare(`SELECT id FROM team_members WHERE team_id = ? AND user_id = ?`).bind(id, b.user_id).first();
  if (existing) return c.json({ error: 'User already on this team' }, 400);
  const r = await db.prepare(`INSERT INTO team_members (team_id, user_id, role_in_team) VALUES (?, ?, ?)`)
    .bind(id, b.user_id, b.role_in_team || 'member').run();
  return c.json({ id: r.meta.last_row_id, success: true });
});

teams.delete('/:id/members/:userId', async (c) => {
  const id = c.req.param('id');
  const userId = c.req.param('userId');
  await c.env.DB.prepare(`DELETE FROM team_members WHERE team_id = ? AND user_id = ?`).bind(id, userId).run();
  return c.json({ success: true });
});

export default teams;
