import { Hono } from 'hono';
import type { AppEnv } from '../types';
import { getHotelId } from '../utils/helpers';

const shifts = new Hono<AppEnv>();

shifts.get('/', async (c) => {
  const hotelId = getHotelId(c);
  const rows = await c.env.DB.prepare(`SELECT * FROM shifts WHERE hotel_id = ? ORDER BY start_time DESC LIMIT 100`).bind(hotelId).all();
  return c.json(rows.results || []);
});

shifts.get('/current', async (c) => {
  const hotelId = getHotelId(c);
  const s = await c.env.DB.prepare(`SELECT * FROM shifts WHERE hotel_id = ? AND status = 'open' ORDER BY start_time DESC LIMIT 1`).bind(hotelId).first();
  return c.json(s || null);
});

shifts.post('/open', async (c) => {
  const hotelId = getHotelId(c);
  const b = await c.req.json();
  const db = c.env.DB;
  const u = await db.prepare(`SELECT full_name FROM users WHERE id = ?`).bind(b.user_id).first<any>();
  const r = await db.prepare(`
    INSERT INTO shifts (hotel_id, user_id, user_name, opening_cash, expected_balance, status) VALUES (?, ?, ?, ?, ?, 'open')`)
    .bind(hotelId, b.user_id, u?.full_name || '', b.opening_cash || 0, b.opening_cash || 0).run();
  return c.json({ id: r.meta.last_row_id, success: true });
});

shifts.post('/:id/close', async (c) => {
  const id = c.req.param('id');
  const b = await c.req.json();
  const db = c.env.DB;
  const s = await db.prepare(`SELECT * FROM shifts WHERE id = ?`).bind(id).first<any>();
  if (!s) return c.json({ error: 'Shift not found' }, 404);
  const variance = b.actual_balance - s.expected_balance;
  await db.prepare(`UPDATE shifts SET status='closed', end_time=CURRENT_TIMESTAMP, actual_balance=?, variance=?, notes=?, closed_by=? WHERE id=?`)
    .bind(b.actual_balance, variance, b.notes || '', b.closed_by || null, id).run();
  return c.json({ success: true, variance });
});

shifts.get('/:id/report', async (c) => {
  const id = c.req.param('id');
  const db = c.env.DB;
  const shift = await db.prepare(`SELECT * FROM shifts WHERE id = ?`).bind(id).first<any>();
  if (!shift) return c.json({ error: 'Shift not found' }, 404);
  const hotel = await db.prepare(`SELECT * FROM hotels WHERE id = ?`).bind(shift.hotel_id).first();
  const endTime = shift.end_time || new Date().toISOString();

  const checkins = await db.prepare(`
    SELECT r.reservation_code, r.actual_check_in, g.first_name, g.last_name, rm.room_number
    FROM reservations r JOIN guests g ON g.id = r.guest_id LEFT JOIN rooms rm ON rm.id = r.room_id
    WHERE r.hotel_id = ? AND r.actual_check_in BETWEEN ? AND ?`)
    .bind(shift.hotel_id, shift.start_time, endTime).all();

  const checkouts = await db.prepare(`
    SELECT r.reservation_code, r.actual_check_out, g.first_name, g.last_name, rm.room_number
    FROM reservations r JOIN guests g ON g.id = r.guest_id LEFT JOIN rooms rm ON rm.id = r.room_id
    WHERE r.hotel_id = ? AND r.actual_check_out BETWEEN ? AND ?`)
    .bind(shift.hotel_id, shift.start_time, endTime).all();

  const payRows = await db.prepare(`
    SELECT p.*, g.first_name, g.last_name, r.reservation_code FROM payments p
    LEFT JOIN guests g ON g.id = p.guest_id LEFT JOIN reservations r ON r.id = p.reservation_id
    WHERE p.shift_id = ?`).bind(id).all();

  const hkRows = await db.prepare(`
    SELECT h.*, rm.room_number FROM housekeeping_tasks h JOIN rooms rm ON rm.id = h.room_id
    WHERE h.hotel_id = ? AND h.created_at BETWEEN ? AND ?`).bind(shift.hotel_id, shift.start_time, endTime).all();

  const activities = await db.prepare(`
    SELECT * FROM activity_log WHERE hotel_id = ? AND created_at BETWEEN ? AND ? ORDER BY created_at DESC`)
    .bind(shift.hotel_id, shift.start_time, endTime).all();

  return c.json({
    shift, hotel,
    checkins: checkins.results || [], checkouts: checkouts.results || [],
    payments: payRows.results || [], housekeeping: hkRows.results || [], activities: activities.results || []
  });
});

export default shifts;
