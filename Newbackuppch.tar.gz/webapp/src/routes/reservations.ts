import { Hono } from 'hono';
import type { AppEnv } from '../types';
import { getHotelId, logActivity, nightsBetween, datesOverlap, todayStr } from '../utils/helpers';
import { genCode } from '../utils/crypto';

const reservations = new Hono<AppEnv>();

// Check if a room has a conflicting reservation or block in a date range.
// excludeResId lets us ignore the reservation being edited.
async function checkRoomConflict(db: D1Database, hotelId: number, roomId: number, checkIn: string, checkOut: string, excludeResId?: number) {
  // A room that is physically out of order (or legacy 'maintenance' status) is never bookable,
  // regardless of date range, until housekeeping/front-desk clears it.
  const room = await db.prepare(`SELECT id, status, housekeeping_status FROM rooms WHERE id = ?`).bind(roomId).first<any>();
  if (room && (room.housekeeping_status === 'out_of_order' || room.status === 'maintenance')) {
    return { conflict: true, type: 'maintenance', with: { reason: 'Room is out of order' } };
  }
  const resRows = await db.prepare(`
    SELECT id, reservation_code, check_in_date, check_out_date, source, guest_id FROM reservations
    WHERE hotel_id = ? AND room_id = ? AND status NOT IN ('cancelled','checked-out')
    ${excludeResId ? 'AND id != ?' : ''}`)
    .bind(...(excludeResId ? [hotelId, roomId, excludeResId] : [hotelId, roomId])).all<any>();
  for (const r of (resRows.results || [])) {
    if (datesOverlap(checkIn, checkOut, r.check_in_date, r.check_out_date)) {
      return { conflict: true, type: 'reservation', with: r };
    }
  }
  const blockRows = await db.prepare(`
    SELECT id, start_date, end_date, reason FROM room_blocks WHERE hotel_id = ? AND room_id = ?`)
    .bind(hotelId, roomId).all<any>();
  for (const b of (blockRows.results || [])) {
    if (datesOverlap(checkIn, checkOut, b.start_date, b.end_date)) {
      return { conflict: true, type: 'block', with: b };
    }
  }
  return { conflict: false };
}

reservations.get('/', async (c) => {
  const hotelId = getHotelId(c);
  const status = c.req.query('status') || 'all';
  const from = c.req.query('from');
  const to = c.req.query('to');
  const db = c.env.DB;
  let q = `SELECT res.*, g.first_name, g.last_name, g.phone as guest_phone, g.email as guest_email, g.vip_status,
    rm.room_number, rt.name as room_type_name, ch.name as channel_name
    FROM reservations res
    JOIN guests g ON g.id = res.guest_id
    LEFT JOIN rooms rm ON rm.id = res.room_id
    LEFT JOIN room_types rt ON rt.id = res.room_type_id
    LEFT JOIN ota_channels ch ON ch.id = res.channel_id
    WHERE res.hotel_id = ?`;
  const params: any[] = [hotelId];
  if (status !== 'all') { q += ` AND res.status = ?`; params.push(status); }
  if (from) { q += ` AND res.check_in_date >= ?`; params.push(from); }
  if (to) { q += ` AND res.check_out_date <= ?`; params.push(to); }
  q += ` ORDER BY res.check_in_date DESC`;
  const rows = await db.prepare(q).bind(...params).all();
  return c.json(rows.results || []);
});

reservations.get('/:id', async (c) => {
  const id = c.req.param('id');
  const db = c.env.DB;
  const r = await db.prepare(`
    SELECT res.*, g.first_name, g.last_name, g.phone as guest_phone, g.email as guest_email, g.address as guest_address,
    g.city as guest_city, g.country as guest_country, g.nationality, g.id_type, g.id_number, g.company, g.vip_status,
    rm.room_number, rt.name as room_type_name, ch.name as channel_name
    FROM reservations res
    JOIN guests g ON g.id = res.guest_id
    LEFT JOIN rooms rm ON rm.id = res.room_id
    LEFT JOIN room_types rt ON rt.id = res.room_type_id
    LEFT JOIN ota_channels ch ON ch.id = res.channel_id
    WHERE res.id = ?`).bind(id).first<any>();
  if (!r) return c.json({ error: 'Reservation not found' }, 404);
  const payments = await db.prepare(`SELECT * FROM payments WHERE reservation_id = ? ORDER BY created_at DESC`).bind(id).all();
  return c.json({ ...r, payments: payments.results || [] });
});

reservations.post('/', async (c) => {
  const hotelId = getHotelId(c);
  const b = await c.req.json();
  const db = c.env.DB;
  if (!b.guest_id || !b.check_in_date || !b.check_out_date) return c.json({ error: 'Missing required fields' }, 400);
  if (b.check_out_date <= b.check_in_date) return c.json({ error: 'Check-out must be after check-in' }, 400);

  // Double-booking prevention: if a specific room is requested, verify it's free
  if (b.room_id) {
    const conflict = await checkRoomConflict(db, hotelId!, b.room_id, b.check_in_date, b.check_out_date);
    if (conflict.conflict) {
      if (conflict.type === 'reservation') {
        return c.json({ error: `Room is already booked (${conflict.with.reservation_code}) for overlapping dates` }, 409);
      } else {
        return c.json({ error: `Room is blocked for these dates: ${conflict.with.reason || 'blocked'}` }, 409);
      }
    }
  }

  const nights = nightsBetween(b.check_in_date, b.check_out_date);
  const rate = b.rate_per_night || 0;
  const total = rate * nights;
  const code = genCode('RES');

  const r = await db.prepare(`
    INSERT INTO reservations (hotel_id, reservation_code, guest_id, room_type_id, room_id, check_in_date, check_out_date,
      actual_check_in, adults, children, rate_per_night, total_amount, status, source, channel_id, external_uid, special_requests, created_by)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
    .bind(hotelId, code, b.guest_id, b.room_type_id || null, b.room_id || null, b.check_in_date, b.check_out_date,
      b.status === 'checked-in' ? new Date().toISOString() : null,
      b.adults || 1, b.children || 0, rate, total, b.status || 'reserved', b.source || 'walk-in',
      b.channel_id || null, b.external_uid || null, b.special_requests || '', b.created_by || null)
    .run();
  const resId = r.meta.last_row_id;

  // Note: rooms.status (available/occupied/reserved) is now always computed live from
  // reservations + blocks (see utils/roomStatus.ts), so no per-room write is needed here.
  // Only key_assigned/key_card_number are set on explicit check-in (see /:id/checkin below).

  await logActivity(db, hotelId, b.created_by, null, 'Created reservation', code);
  return c.json({ id: resId, code, success: true });
});

reservations.post('/:id/checkin', async (c) => {
  const id = c.req.param('id');
  const b = await c.req.json();
  const db = c.env.DB;
  const res = await db.prepare(`SELECT * FROM reservations WHERE id = ?`).bind(id).first<any>();
  if (!res) return c.json({ error: 'Reservation not found' }, 404);

  // Verify room not double-booked for this stay before check-in
  if (b.room_id) {
    const conflict = await checkRoomConflict(db, res.hotel_id, b.room_id, res.check_in_date, res.check_out_date, parseInt(id));
    if (conflict.conflict && conflict.type === 'reservation') {
      return c.json({ error: `Room is already occupied by reservation ${conflict.with.reservation_code}` }, 409);
    }
  }

  await db.prepare(`UPDATE reservations SET room_id = ?, status = 'checked-in', actual_check_in = CURRENT_TIMESTAMP, key_card_number = ?, key_assigned = 1 WHERE id = ?`)
    .bind(b.room_id, b.key_card_number || '', id).run();
  // Room's operational status (occupied) is derived live; just mark housekeeping as occupied
  // so the housekeeping board reflects it immediately even before the next status refresh.
  if (b.room_id) await db.prepare(`UPDATE rooms SET housekeeping_status = 'occupied' WHERE id = ?`).bind(b.room_id).run();
  await logActivity(db, res.hotel_id, null, null, 'Checked in guest', res.reservation_code);
  return c.json({ success: true });
});

reservations.post('/:id/checkout', async (c) => {
  const id = c.req.param('id');
  const db = c.env.DB;
  const res = await db.prepare(`SELECT * FROM reservations WHERE id = ?`).bind(id).first<any>();
  if (!res) return c.json({ error: 'Reservation not found' }, 404);
  await db.prepare(`UPDATE reservations SET status = 'checked-out', actual_check_out = CURRENT_TIMESTAMP WHERE id = ?`).bind(id).run();
  // Room becomes free but dirty - housekeeping needs to clean it before it's bookable-clean again.
  if (res.room_id) await db.prepare(`UPDATE rooms SET housekeeping_status = 'vacant_dirty' WHERE id = ?`).bind(res.room_id).run();
  // Update guest loyalty/stay stats
  const nights = nightsBetween(res.check_in_date, res.check_out_date);
  const points = Math.round((res.total_amount || 0) / 1000);
  const guest = await db.prepare(`SELECT * FROM guests WHERE id = ?`).bind(res.guest_id).first<any>();
  if (guest) {
    const newPoints = (guest.loyalty_points || 0) + points;
    const newStays = (guest.total_stays || 0) + 1;
    const newSpent = (guest.total_spent || 0) + (res.total_amount || 0);
    let tier = 'bronze';
    if (newPoints >= 5000) tier = 'platinum'; else if (newPoints >= 2000) tier = 'gold'; else if (newPoints >= 500) tier = 'silver';
    await db.prepare(`UPDATE guests SET loyalty_points=?, loyalty_tier=?, total_stays=?, total_spent=? WHERE id=?`)
      .bind(newPoints, tier, newStays, newSpent, res.guest_id).run();
    if (points > 0) {
      await db.prepare(`INSERT INTO loyalty_transactions (guest_id, type, points, description) VALUES (?, 'earn', ?, ?)`)
        .bind(res.guest_id, points, `Stay ${res.reservation_code}`).run();
    }
  }
  await logActivity(db, res.hotel_id, null, null, 'Checked out guest', res.reservation_code);
  return c.json({ success: true });
});

reservations.post('/:id/change-room', async (c) => {
  const id = c.req.param('id');
  const { new_room_id, reason } = await c.req.json();
  const db = c.env.DB;
  const res = await db.prepare(`SELECT * FROM reservations WHERE id = ?`).bind(id).first<any>();
  if (!res) return c.json({ error: 'Reservation not found' }, 404);
  const conflict = await checkRoomConflict(db, res.hotel_id, new_room_id, res.check_in_date, res.check_out_date, parseInt(id));
  if (conflict.conflict && conflict.type === 'reservation') {
    return c.json({ error: `Target room already booked (${conflict.with.reservation_code})` }, 409);
  }
  const oldRoomId = res.room_id;
  await db.prepare(`UPDATE reservations SET room_id = ? WHERE id = ?`).bind(new_room_id, id).run();
  // Vacated room becomes dirty (needs cleaning before next guest); new room reflects live status automatically.
  if (oldRoomId) await db.prepare(`UPDATE rooms SET housekeeping_status = 'vacant_dirty' WHERE id = ?`).bind(oldRoomId).run();
  if (res.status === 'checked-in') await db.prepare(`UPDATE rooms SET housekeeping_status = 'occupied' WHERE id = ?`).bind(new_room_id).run();
  await logActivity(db, res.hotel_id, null, null, 'Changed room', `${res.reservation_code}: ${reason || ''}`);
  return c.json({ success: true });
});

reservations.post('/:id/cancel', async (c) => {
  const id = c.req.param('id');
  const db = c.env.DB;
  const res = await db.prepare(`SELECT * FROM reservations WHERE id = ?`).bind(id).first<any>();
  if (!res) return c.json({ error: 'Reservation not found' }, 404);
  await db.prepare(`UPDATE reservations SET status = 'cancelled' WHERE id = ?`).bind(id).run();
  // Room's live status recomputes automatically now that this reservation no longer counts;
  // if it had actually been checked-in (rare, but guards against inconsistent data), mark dirty.
  if (res.room_id && res.status === 'checked-in') await db.prepare(`UPDATE rooms SET housekeeping_status = 'vacant_dirty' WHERE id = ?`).bind(res.room_id).run();
  await logActivity(db, res.hotel_id, null, null, 'Cancelled reservation', res.reservation_code);
  return c.json({ success: true });
});

export default reservations;
export { checkRoomConflict };
