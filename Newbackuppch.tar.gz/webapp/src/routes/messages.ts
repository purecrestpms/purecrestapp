import { Hono } from 'hono';
import type { AppEnv } from '../types';
import { getHotelId } from '../utils/helpers';

const messages = new Hono<AppEnv>();

messages.get('/unread', async (c) => {
  const userId = c.req.query('user_id') || null;
  const hotelId = getHotelId(c);
  const r = await c.env.DB.prepare(`
    SELECT COUNT(*) as count FROM messages
    WHERE hotel_id = ? AND is_trashed = 0 AND is_read = 0 AND (to_user_id = ? OR (is_broadcast = 1 AND from_user_id != ?))`)
    .bind(hotelId, userId, userId).first<any>();
  return c.json({ count: r?.count || 0 });
});

messages.get('/', async (c) => {
  const userId = c.req.query('user_id') || null;
  const trashed = c.req.query('trashed') || '0';
  const hotelId = getHotelId(c);
  const db = c.env.DB;
  const rows = await db.prepare(`
    SELECT m.*, u1.full_name as from_name, u2.full_name as to_name,
    (SELECT COUNT(*) FROM messages r WHERE r.reply_to = m.id) as reply_count
    FROM messages m
    LEFT JOIN users u1 ON u1.id = m.from_user_id
    LEFT JOIN users u2 ON u2.id = m.to_user_id
    WHERE m.hotel_id = ? AND m.is_trashed = ? AND m.reply_to IS NULL
    AND (m.to_user_id = ? OR m.is_broadcast = 1 OR m.from_user_id = ?)
    ORDER BY m.created_at DESC`)
    .bind(hotelId, trashed, userId, userId).all();
  return c.json(rows.results || []);
});

messages.get('/:id', async (c) => {
  const id = c.req.param('id');
  const db = c.env.DB;
  const m = await db.prepare(`
    SELECT m.*, u1.full_name as from_name, u2.full_name as to_name FROM messages m
    LEFT JOIN users u1 ON u1.id = m.from_user_id LEFT JOIN users u2 ON u2.id = m.to_user_id
    WHERE m.id = ?`).bind(id).first<any>();
  if (!m) return c.json({ error: 'Message not found' }, 404);
  const replies = await db.prepare(`
    SELECT m.*, u1.full_name as from_name FROM messages m LEFT JOIN users u1 ON u1.id = m.from_user_id
    WHERE m.reply_to = ? ORDER BY m.created_at ASC`).bind(id).all();
  return c.json({ ...m, replies: replies.results || [] });
});

messages.post('/', async (c) => {
  const hotelId = getHotelId(c);
  const b = await c.req.json();
  const r = await c.env.DB.prepare(`
    INSERT INTO messages (hotel_id, from_user_id, to_user_id, subject, body, priority, is_broadcast, reply_to)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)`)
    .bind(hotelId, b.from_user_id, b.is_broadcast ? null : b.to_user_id, b.subject || '', b.body, b.priority || 'normal', b.is_broadcast ? 1 : 0, b.reply_to || null)
    .run();
  return c.json({ id: r.meta.last_row_id, success: true });
});

messages.put('/:id/read', async (c) => {
  const id = c.req.param('id');
  await c.env.DB.prepare(`UPDATE messages SET is_read = 1 WHERE id = ?`).bind(id).run();
  return c.json({ success: true });
});

messages.put('/:id/trash', async (c) => {
  const id = c.req.param('id');
  await c.env.DB.prepare(`UPDATE messages SET is_trashed = 1 WHERE id = ?`).bind(id).run();
  return c.json({ success: true });
});

messages.put('/:id/restore', async (c) => {
  const id = c.req.param('id');
  await c.env.DB.prepare(`UPDATE messages SET is_trashed = 0 WHERE id = ?`).bind(id).run();
  return c.json({ success: true });
});

messages.delete('/:id', async (c) => {
  const id = c.req.param('id');
  await c.env.DB.prepare(`DELETE FROM messages WHERE id = ? OR reply_to = ?`).bind(id, id).run();
  return c.json({ success: true });
});

export default messages;
