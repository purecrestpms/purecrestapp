import { Hono } from 'hono';
import type { AppEnv } from '../types';
import { getHotelId, logActivity } from '../utils/helpers';
import { hashPassword } from '../utils/crypto';

const users = new Hono<AppEnv>();

users.get('/', async (c) => {
  const hotelId = getHotelId(c);
  const db = c.env.DB;
  let rows;
  if (hotelId) {
    rows = await db.prepare(`SELECT id, hotel_id, username, full_name, role, email, phone, permissions, is_active, last_login FROM users WHERE hotel_id = ? ORDER BY full_name`).bind(hotelId).all();
  } else {
    rows = await db.prepare(`SELECT id, hotel_id, username, full_name, role, email, phone, permissions, is_active, last_login FROM users ORDER BY full_name`).all();
  }
  return c.json(rows.results || []);
});

users.post('/', async (c) => {
  const hotelId = getHotelId(c);
  const b = await c.req.json();
  if (!b.full_name || !b.username) return c.json({ error: 'Name and username required' }, 400);
  const db = c.env.DB;
  const existing = await db.prepare(`SELECT id FROM users WHERE username = ?`).bind(b.username).first();
  if (existing) return c.json({ error: 'Username already taken' }, 400);
  const hash = await hashPassword(b.password || 'password123');
  const perms = typeof b.permissions === 'object' ? JSON.stringify(b.permissions) : (b.permissions || '{}');
  const r = await db.prepare(`
    INSERT INTO users (hotel_id, username, password_hash, full_name, role, email, phone, permissions, created_by)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`)
    .bind(b.role === 'super_admin' ? null : hotelId, b.username, hash, b.full_name, b.role || 'receptionist', b.email || '', b.phone || '', perms, b.created_by || null)
    .run();
  await logActivity(db, hotelId, b.created_by, null, 'Created staff user', b.full_name);
  return c.json({ id: r.meta.last_row_id, success: true });
});

users.put('/:id', async (c) => {
  const id = c.req.param('id');
  const b = await c.req.json();
  const db = c.env.DB;
  const fields: string[] = []; const vals: any[] = [];
  if (b.full_name !== undefined) { fields.push('full_name=?'); vals.push(b.full_name); }
  if (b.role !== undefined) { fields.push('role=?'); vals.push(b.role); }
  if (b.email !== undefined) { fields.push('email=?'); vals.push(b.email); }
  if (b.phone !== undefined) { fields.push('phone=?'); vals.push(b.phone); }
  if (b.is_active !== undefined) { fields.push('is_active=?'); vals.push(b.is_active ? 1 : 0); }
  if (b.permissions !== undefined) { fields.push('permissions=?'); vals.push(typeof b.permissions === 'object' ? JSON.stringify(b.permissions) : b.permissions); }
  if (fields.length === 0) return c.json({ success: true });
  vals.push(id);
  await db.prepare(`UPDATE users SET ${fields.join(', ')} WHERE id = ?`).bind(...vals).run();
  return c.json({ success: true });
});

users.put('/:id/reset-password', async (c) => {
  const id = c.req.param('id');
  const { new_password } = await c.req.json();
  const hash = await hashPassword(new_password || 'password123');
  await c.env.DB.prepare(`UPDATE users SET password_hash = ? WHERE id = ?`).bind(hash, id).run();
  return c.json({ success: true });
});

export default users;
