import { Hono } from 'hono';
import type { AppEnv } from '../types';
import { genToken } from '../utils/crypto';

const license = new Hono<AppEnv>();

function daysLeft(trialStartedAt: string, trialDays: number): number {
  const start = new Date(trialStartedAt).getTime();
  const end = start + trialDays * 86400000;
  return Math.ceil((end - Date.now()) / 86400000);
}

// Compute a derived, always-current status object (trial countdown, expiry, etc.)
async function getLicenseState(db: D1Database) {
  let lic = await db.prepare(`SELECT * FROM license ORDER BY id DESC LIMIT 1`).first<any>();
  if (!lic) {
    await db.prepare(`INSERT INTO license (status, plan, trial_started_at, trial_days) VALUES ('trial','trial', CURRENT_TIMESTAMP, 14)`).run();
    lic = await db.prepare(`SELECT * FROM license ORDER BY id DESC LIMIT 1`).first<any>();
  }
  let status = lic.status;
  let remainingDays: number | null = null;

  if (status === 'trial') {
    remainingDays = daysLeft(lic.trial_started_at, lic.trial_days);
    if (remainingDays <= 0) {
      status = 'expired';
      await db.prepare(`UPDATE license SET status='expired', updated_at=CURRENT_TIMESTAMP WHERE id=?`).bind(lic.id).run();
    }
  } else if (status === 'active' && lic.expires_at) {
    const expiresAt = new Date(lic.expires_at).getTime();
    remainingDays = Math.ceil((expiresAt - Date.now()) / 86400000);
    if (remainingDays <= 0) {
      status = 'expired';
      await db.prepare(`UPDATE license SET status='expired', updated_at=CURRENT_TIMESTAMP WHERE id=?`).bind(lic.id).run();
    }
  }

  return { ...lic, status, remaining_days: remainingDays, is_valid: status === 'active' || status === 'trial' };
}

// Public-ish status check (used by login/trial banner, by any authenticated user)
license.get('/status', async (c) => {
  const state = await getLicenseState(c.env.DB);
  return c.json(state);
});

// Super admin: full license record + history
license.get('/', async (c) => {
  const state = await getLicenseState(c.env.DB);
  const history = await c.env.DB.prepare(`SELECT * FROM license_history ORDER BY created_at DESC LIMIT 50`).all();
  return c.json({ license: state, history: history.results || [] });
});

// Activate with a license key (format-validated locally; in production this
// would call out to a licensing server, but Workers has no persistent license
// server here so we accept any key matching PCH-XXXX-XXXX-XXXX-XXXX and store it).
license.post('/activate', async (c) => {
  const b = await c.req.json();
  const key = (b.license_key || '').trim().toUpperCase();
  const keyPattern = /^PCH-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$/;
  if (!keyPattern.test(key)) {
    return c.json({ error: 'Invalid license key format. Expected: PCH-XXXX-XXXX-XXXX-XXXX' }, 400);
  }
  const db = c.env.DB;
  const plan = b.plan || 'pro';
  const durationDays = b.duration_days || 365;
  const expiresAt = new Date(Date.now() + durationDays * 86400000).toISOString();
  const existing = await db.prepare(`SELECT id FROM license ORDER BY id DESC LIMIT 1`).first<any>();
  if (existing) {
    await db.prepare(`
      UPDATE license SET license_key=?, status='active', plan=?, customer_name=?, customer_email=?,
      max_hotels=?, max_rooms=?, activated_at=CURRENT_TIMESTAMP, expires_at=?, updated_at=CURRENT_TIMESTAMP WHERE id=?`)
      .bind(key, plan, b.customer_name || '', b.customer_email || '', b.max_hotels || 10, b.max_rooms || 1000, expiresAt, existing.id).run();
  } else {
    await db.prepare(`
      INSERT INTO license (license_key, status, plan, customer_name, customer_email, max_hotels, max_rooms, activated_at, expires_at)
      VALUES (?, 'active', ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, ?)`)
      .bind(key, plan, b.customer_name || '', b.customer_email || '', b.max_hotels || 10, b.max_rooms || 1000, expiresAt).run();
  }
  await db.prepare(`INSERT INTO license_history (action, license_key, plan, note) VALUES ('activated', ?, ?, ?)`)
    .bind(key, plan, b.customer_name ? `Activated for ${b.customer_name}` : 'Activated').run();
  const state = await getLicenseState(db);
  return c.json({ success: true, license: state });
});

// Super admin: generate a demo license key (so this can be tested without an external licensing service)
license.post('/generate-key', async (c) => {
  const seg = () => genToken(2).toUpperCase().slice(0, 4);
  const key = `PCH-${seg()}-${seg()}-${seg()}-${seg()}`;
  return c.json({ license_key: key });
});

license.post('/extend-trial', async (c) => {
  const { days } = await c.req.json();
  const db = c.env.DB;
  const lic = await db.prepare(`SELECT * FROM license ORDER BY id DESC LIMIT 1`).first<any>();
  if (!lic) return c.json({ error: 'No license record' }, 404);
  await db.prepare(`UPDATE license SET trial_days = trial_days + ?, status='trial', updated_at=CURRENT_TIMESTAMP WHERE id=?`)
    .bind(days || 7, lic.id).run();
  await db.prepare(`INSERT INTO license_history (action, note) VALUES ('renewed', ?)`).bind(`Trial extended by ${days || 7} days`).run();
  const state = await getLicenseState(db);
  return c.json({ success: true, license: state });
});

license.post('/deactivate', async (c) => {
  const db = c.env.DB;
  const lic = await db.prepare(`SELECT * FROM license ORDER BY id DESC LIMIT 1`).first<any>();
  if (!lic) return c.json({ error: 'No license record' }, 404);
  await db.prepare(`UPDATE license SET status='suspended', updated_at=CURRENT_TIMESTAMP WHERE id=?`).bind(lic.id).run();
  await db.prepare(`INSERT INTO license_history (action, note) VALUES ('suspended', 'Manually suspended by super admin')`).run();
  return c.json({ success: true });
});

export default license;
export { getLicenseState };
