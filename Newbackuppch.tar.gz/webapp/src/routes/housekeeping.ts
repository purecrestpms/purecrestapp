import { Hono } from 'hono';
import type { AppEnv } from '../types';
import { getHotelId, logActivity, todayStr } from '../utils/helpers';
import { computeLiveRoomStatuses, MANUAL_HOUSEKEEPING_STATUSES } from '../utils/roomStatus';

const housekeeping = new Hono<AppEnv>();

// Room housekeeping board: every room with its live status + housekeeping state,
// for the Housekeeping page's room-status view (Vacant Clean / Vacant Dirty / Occupied / Reserved / Out of Order).
housekeeping.get('/rooms', async (c) => {
  const hotelId = getHotelId(c);
  const db = c.env.DB;
  const rows = await db.prepare(`
    SELECT r.id, r.room_number, r.floor, t.name as type_name, t.color as type_color
    FROM rooms r JOIN room_types t ON t.id = r.room_type_id
    WHERE r.hotel_id = ? ORDER BY t.name, r.floor, r.room_number`).bind(hotelId).all<any>();
  const list = rows.results || [];
  if (hotelId) {
    const liveMap = await computeLiveRoomStatuses(db, hotelId, todayStr());
    for (const r of list) {
      const live = liveMap[r.id];
      r.status = live ? live.status : 'available';
      r.housekeeping_status = live ? live.housekeeping_status : 'vacant_clean';
    }
  }
  return c.json(list);
});

housekeeping.put('/rooms/:id/status', async (c) => {
  const id = c.req.param('id');
  const hotelId = getHotelId(c);
  const { status, user_id, user_name } = await c.req.json();
  if (!MANUAL_HOUSEKEEPING_STATUSES.includes(status)) {
    return c.json({ error: `Invalid status. Must be one of: ${MANUAL_HOUSEKEEPING_STATUSES.join(', ')}` }, 400);
  }
  await c.env.DB.prepare(`UPDATE rooms SET housekeeping_status = ? WHERE id = ?`).bind(status, id).run();
  await logActivity(c.env.DB, hotelId, user_id || null, user_name || null, 'Updated room housekeeping status', `Room #${id} -> ${status}`);
  return c.json({ success: true });
});

housekeeping.get('/', async (c) => {
  const hotelId = getHotelId(c);
  const rows = await c.env.DB.prepare(`
    SELECT t.*, r.room_number, u.full_name as assigned_to_name FROM housekeeping_tasks t
    JOIN rooms r ON r.id = t.room_id
    LEFT JOIN users u ON u.id = t.assigned_to
    WHERE t.hotel_id = ? ORDER BY CASE t.status WHEN 'pending' THEN 0 WHEN 'in-progress' THEN 1 ELSE 2 END, t.created_at DESC`).bind(hotelId).all();
  return c.json(rows.results || []);
});

housekeeping.post('/', async (c) => {
  const hotelId = getHotelId(c);
  const b = await c.req.json();
  const r = await c.env.DB.prepare(`
    INSERT INTO housekeeping_tasks (hotel_id, room_id, task_type, priority, assigned_to, notes) VALUES (?, ?, ?, ?, ?, ?)`)
    .bind(hotelId, b.room_id, b.task_type || 'cleaning', b.priority || 'normal', b.assigned_to || null, b.notes || '').run();
  return c.json({ id: r.meta.last_row_id, success: true });
});

housekeeping.put('/:id', async (c) => {
  const id = c.req.param('id');
  const { status } = await c.req.json();
  const db = c.env.DB;
  await db.prepare(`UPDATE housekeeping_tasks SET status = ?, completed_at = CASE WHEN ? = 'completed' THEN CURRENT_TIMESTAMP ELSE completed_at END WHERE id = ?`)
    .bind(status, status, id).run();
  return c.json({ success: true });
});

housekeeping.delete('/:id', async (c) => {
  const id = c.req.param('id');
  await c.env.DB.prepare(`DELETE FROM housekeeping_tasks WHERE id = ?`).bind(id).run();
  return c.json({ success: true });
});

export default housekeeping;
