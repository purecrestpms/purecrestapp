import { Hono } from 'hono';
import type { AppEnv } from '../types';
import { getHotelId, todayStr } from '../utils/helpers';

const dashboard = new Hono<AppEnv>();

dashboard.get('/', async (c) => {
  const hotelId = getHotelId(c);
  const db = c.env.DB;
  const today = todayStr();

  const arrivalsRow = await db.prepare(`SELECT COUNT(*) as n FROM reservations WHERE hotel_id = ? AND check_in_date = ? AND status != 'cancelled'`).bind(hotelId, today).first<any>();
  const departuresRow = await db.prepare(`SELECT COUNT(*) as n FROM reservations WHERE hotel_id = ? AND check_out_date = ? AND status = 'checked-in'`).bind(hotelId, today).first<any>();
  const inhouseRow = await db.prepare(`SELECT COUNT(*) as n FROM reservations WHERE hotel_id = ? AND status = 'checked-in'`).bind(hotelId).first<any>();
  const revenueRow = await db.prepare(`SELECT COALESCE(SUM(amount),0) as n FROM payments WHERE hotel_id = ? AND date(created_at) = ? AND is_refund = 0`).bind(hotelId, today).first<any>();

  const roomStatsRows = await db.prepare(`SELECT status, COUNT(*) as n FROM rooms WHERE hotel_id = ? GROUP BY status`).bind(hotelId).all<any>();
  const roomStats: any = { total: 0, occupied: 0, available: 0, reserved: 0, maintenance: 0 };
  for (const r of (roomStatsRows.results || [])) { roomStats[r.status] = r.n; roomStats.total += r.n; }

  const rooms = await db.prepare(`
    SELECT r.*, t.name as type_name, t.color as type_color FROM rooms r JOIN room_types t ON t.id = r.room_type_id
    WHERE r.hotel_id = ? ORDER BY r.floor, r.room_number`).bind(hotelId).all();

  const recentReservations = await db.prepare(`
    SELECT res.*, g.first_name, g.last_name, rm.room_number, rt.name as room_type_name
    FROM reservations res JOIN guests g ON g.id = res.guest_id
    LEFT JOIN rooms rm ON rm.id = res.room_id LEFT JOIN room_types rt ON rt.id = res.room_type_id
    WHERE res.hotel_id = ? ORDER BY res.created_at DESC LIMIT 8`).bind(hotelId).all();

  const currentShift = await db.prepare(`SELECT * FROM shifts WHERE hotel_id = ? AND status = 'open' ORDER BY start_time DESC LIMIT 1`).bind(hotelId).first();

  return c.json({
    arrivals: arrivalsRow?.n || 0,
    departures: departuresRow?.n || 0,
    inhouse: inhouseRow?.n || 0,
    revenue: revenueRow?.n || 0,
    roomStats,
    rooms: rooms.results || [],
    recentReservations: recentReservations.results || [],
    schedule: [],
    currentShift: currentShift || null
  });
});

export default dashboard;
