import { Hono } from 'hono';
import type { AppEnv } from '../types';
import { getHotelId, logActivity, datesOverlap } from '../utils/helpers';
import { checkRoomConflict } from './reservations';

const calendar = new Hono<AppEnv>();

function addDays(dateStr: string, n: number): string {
  const d = new Date(dateStr + 'T00:00:00Z');
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().split('T')[0];
}

function daysBetween(start: string, end: string): string[] {
  const out: string[] = [];
  let cur = start;
  while (cur < end) { out.push(cur); cur = addDays(cur, 1); }
  return out;
}

// Room-by-room availability grid for a date range. Supports daily/weekly/monthly
// since the client just picks the range (e.g. 7 days, or a full month) and gets
// per-day cell status for every room.
calendar.get('/grid', async (c) => {
  const hotelId = getHotelId(c);
  const from = c.req.query('from');
  const to = c.req.query('to'); // exclusive
  if (!from || !to) return c.json({ error: 'from and to required' }, 400);
  const db = c.env.DB;

  const rooms = await db.prepare(`
    SELECT r.id, r.room_number, r.floor, r.status as room_status, r.housekeeping_status, t.id as room_type_id, t.name as type_name, t.color as type_color
    FROM rooms r JOIN room_types t ON t.id = r.room_type_id
    WHERE r.hotel_id = ? ORDER BY t.name, r.floor, r.room_number`).bind(hotelId).all<any>();

  const reservations = await db.prepare(`
    SELECT res.id, res.reservation_code, res.room_id, res.check_in_date, res.check_out_date, res.status, res.source, res.channel_id,
      g.first_name, g.last_name, ch.name as channel_name
    FROM reservations res JOIN guests g ON g.id = res.guest_id
    LEFT JOIN ota_channels ch ON ch.id = res.channel_id
    WHERE res.hotel_id = ? AND res.status NOT IN ('cancelled') AND res.check_in_date < ? AND res.check_out_date > ?`)
    .bind(hotelId, to, from).all<any>();

  const blocks = await db.prepare(`
    SELECT * FROM room_blocks WHERE hotel_id = ? AND start_date < ? AND end_date > ?`)
    .bind(hotelId, to, from).all<any>();

  const days = daysBetween(from, to);

  const roomMap: Record<number, any> = {};
  for (const r of (rooms.results || [])) {
    roomMap[r.id] = { ...r, cells: {} };
    const isOOO = r.housekeeping_status === 'out_of_order';
    for (const d of days) roomMap[r.id].cells[d] = isOOO ? { status: 'blocked', reason: 'Out of order' } : { status: 'available' };
  }

  for (const res of (reservations.results || [])) {
    if (!res.room_id || !roomMap[res.room_id]) continue;
    for (const d of days) {
      if (d >= res.check_in_date && d < res.check_out_date) {
        roomMap[res.room_id].cells[d] = {
          status: res.status === 'checked-in' ? 'occupied' : 'reserved',
          reservation_id: res.id, reservation_code: res.reservation_code,
          guest_name: `${res.first_name} ${res.last_name}`,
          source: res.source, channel_name: res.channel_name,
          is_checkin: d === res.check_in_date, is_checkout: d === addDays(res.check_out_date, -1)
        };
      }
    }
  }

  for (const b of (blocks.results || [])) {
    const targetRooms = b.room_id ? [b.room_id] : (rooms.results || []).filter((r: any) => !b.room_type_id || r.room_type_id === b.room_type_id).map((r: any) => r.id);
    for (const rid of targetRooms) {
      if (!roomMap[rid]) continue;
      for (const d of days) {
        if (d >= b.start_date && d < b.end_date && roomMap[rid].cells[d].status === 'available') {
          roomMap[rid].cells[d] = { status: 'blocked', block_id: b.id, reason: b.reason };
        }
      }
    }
  }

  return c.json({ days, rooms: Object.values(roomMap) });
});

// ---- Date blocking (manual room/room-type closures, independent of reservations) ----
calendar.get('/blocks', async (c) => {
  const hotelId = getHotelId(c);
  const rows = await c.env.DB.prepare(`
    SELECT b.*, r.room_number, t.name as room_type_name FROM room_blocks b
    LEFT JOIN rooms r ON r.id = b.room_id
    LEFT JOIN room_types t ON t.id = b.room_type_id
    WHERE b.hotel_id = ? ORDER BY b.start_date DESC`).bind(hotelId).all();
  return c.json(rows.results || []);
});

calendar.post('/blocks', async (c) => {
  const hotelId = getHotelId(c);
  const b = await c.req.json();
  if (!b.start_date || !b.end_date) return c.json({ error: 'start_date and end_date required' }, 400);
  if (b.end_date <= b.start_date) return c.json({ error: 'End date must be after start date' }, 400);
  if (!b.room_id && !b.room_type_id) return c.json({ error: 'room_id or room_type_id required' }, 400);
  const db = c.env.DB;

  // If a specific room is targeted, verify there's no active reservation conflict first
  if (b.room_id) {
    const conflict = await checkRoomConflict(db, hotelId!, b.room_id, b.start_date, b.end_date);
    if (conflict.conflict && conflict.type === 'reservation') {
      return c.json({ error: `Cannot block: room has an active reservation (${conflict.with.reservation_code}) in this range` }, 409);
    }
  }

  const r = await db.prepare(`
    INSERT INTO room_blocks (hotel_id, room_id, room_type_id, start_date, end_date, reason, block_type, created_by)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)`)
    .bind(hotelId, b.room_id || null, b.room_type_id || null, b.start_date, b.end_date, b.reason || 'Blocked', b.block_type || 'manual', b.created_by || null)
    .run();
  await logActivity(db, hotelId, b.created_by, null, 'Blocked dates', `${b.start_date} to ${b.end_date}: ${b.reason || ''}`);
  return c.json({ id: r.meta.last_row_id, success: true });
});

calendar.delete('/blocks/:id', async (c) => {
  const id = c.req.param('id');
  await c.env.DB.prepare(`DELETE FROM room_blocks WHERE id = ?`).bind(id).run();
  return c.json({ success: true });
});

// Quick availability check for a proposed stay (used by manual booking entry form before submit)
calendar.get('/availability', async (c) => {
  const hotelId = getHotelId(c);
  const roomTypeId = c.req.query('room_type_id');
  const from = c.req.query('from');
  const to = c.req.query('to');
  if (!from || !to) return c.json({ error: 'from and to required' }, 400);
  const db = c.env.DB;
  let q = `SELECT r.id, r.room_number FROM rooms r WHERE r.hotel_id = ?`;
  const params: any[] = [hotelId];
  if (roomTypeId) { q += ` AND r.room_type_id = ?`; params.push(roomTypeId); }
  const rooms = await db.prepare(q).bind(...params).all<any>();

  const available: any[] = [];
  for (const room of (rooms.results || [])) {
    const conflict = await checkRoomConflict(db, hotelId!, room.id, from, to);
    if (!conflict.conflict) available.push(room);
  }
  return c.json({ available_rooms: available, count: available.length });
});

export default calendar;
