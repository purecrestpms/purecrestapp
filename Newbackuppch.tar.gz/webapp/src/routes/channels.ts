import { Hono } from 'hono';
import type { AppEnv } from '../types';
import { getHotelId, logActivity, nightsBetween, datesOverlap } from '../utils/helpers';
import { genToken, genCode } from '../utils/crypto';
import { parseICal, generateICal } from '../utils/ical';
import { checkRoomConflict } from './reservations';

const channels = new Hono<AppEnv>();

// List all available OTA channel definitions (Booking.com, Airbnb, Expedia, etc.)
channels.get('/catalog', async (c) => {
  const rows = await c.env.DB.prepare(`SELECT * FROM ota_channels ORDER BY name`).all();
  return c.json(rows.results || []);
});

// List this hotel's connections
channels.get('/connections', async (c) => {
  const hotelId = getHotelId(c);
  const rows = await c.env.DB.prepare(`
    SELECT cc.*, ch.name as channel_name, ch.icon as channel_icon, ch.color as channel_color, ch.type as channel_type,
    rt.name as room_type_name
    FROM channel_connections cc
    JOIN ota_channels ch ON ch.id = cc.channel_id
    LEFT JOIN room_types rt ON rt.id = cc.room_type_id
    WHERE cc.hotel_id = ? ORDER BY cc.created_at DESC`).bind(hotelId).all();
  return c.json(rows.results || []);
});

// Create a new channel connection (iCal import URL and/or API credentials)
channels.post('/connections', async (c) => {
  const hotelId = getHotelId(c);
  const b = await c.req.json();
  if (!b.channel_id) return c.json({ error: 'Channel required' }, 400);
  const db = c.env.DB;
  const exportToken = genToken(16);
  const r = await db.prepare(`
    INSERT INTO channel_connections (hotel_id, channel_id, room_type_id, label, ical_import_url, ical_export_token, api_key, api_secret, connection_mode, status, auto_sync, created_by)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
    .bind(hotelId, b.channel_id, b.room_type_id || null, b.label || '', b.ical_import_url || '', exportToken,
      b.api_key || '', b.api_secret || '', b.connection_mode || 'ical', b.ical_import_url || b.api_key ? 'connected' : 'pending',
      b.auto_sync === false ? 0 : 1, b.created_by || null)
    .run();
  await logActivity(db, hotelId, b.created_by, null, 'Connected OTA channel', b.label || '');
  return c.json({ id: r.meta.last_row_id, success: true, export_token: exportToken });
});

channels.put('/connections/:id', async (c) => {
  const id = c.req.param('id');
  const b = await c.req.json();
  const db = c.env.DB;
  const fields: string[] = []; const vals: any[] = [];
  for (const k of ['label', 'ical_import_url', 'api_key', 'api_secret', 'connection_mode', 'status']) {
    if (b[k] !== undefined) { fields.push(`${k}=?`); vals.push(b[k]); }
  }
  if (b.auto_sync !== undefined) { fields.push('auto_sync=?'); vals.push(b.auto_sync ? 1 : 0); }
  if (b.room_type_id !== undefined) { fields.push('room_type_id=?'); vals.push(b.room_type_id); }
  if (fields.length === 0) return c.json({ success: true });
  vals.push(id);
  await db.prepare(`UPDATE channel_connections SET ${fields.join(', ')} WHERE id = ?`).bind(...vals).run();
  return c.json({ success: true });
});

channels.delete('/connections/:id', async (c) => {
  const id = c.req.param('id');
  await c.env.DB.prepare(`DELETE FROM channel_connections WHERE id = ?`).bind(id).run();
  await c.env.DB.prepare(`DELETE FROM channel_sync_logs WHERE connection_id = ?`).bind(id).run();
  return c.json({ success: true });
});

// Sync logs for this hotel (most recent first)
channels.get('/sync-logs', async (c) => {
  const hotelId = getHotelId(c);
  const rows = await c.env.DB.prepare(`SELECT * FROM channel_sync_logs WHERE hotel_id = ? ORDER BY started_at DESC LIMIT 100`).bind(hotelId).all();
  return c.json(rows.results || []);
});

// Export this hotel's availability as an iCal feed for a given connection (for OTAs that pull availability)
channels.get('/connections/:id/export.ics', async (c) => {
  const id = c.req.param('id');
  const db = c.env.DB;
  const conn = await db.prepare(`SELECT cc.*, h.name as hotel_name FROM channel_connections cc JOIN hotels h ON h.id = cc.hotel_id WHERE cc.id = ?`).bind(id).first<any>();
  if (!conn) return c.text('Not found', 404);
  // Export all non-cancelled reservations (blocked dates) for this hotel/room type as busy events
  let q = `SELECT res.id, res.reservation_code, res.check_in_date, res.check_out_date, res.room_id, g.first_name, g.last_name
    FROM reservations res JOIN guests g ON g.id = res.guest_id WHERE res.hotel_id = ? AND res.status NOT IN ('cancelled','checked-out')`;
  const params: any[] = [conn.hotel_id];
  if (conn.room_type_id) { q += ` AND res.room_type_id = ?`; params.push(conn.room_type_id); }
  const rows = await db.prepare(q).bind(...params).all<any>();
  const blockRows = await db.prepare(`SELECT * FROM room_blocks WHERE hotel_id = ? ${conn.room_type_id ? 'AND (room_type_id = ? OR room_type_id IS NULL)' : ''}`)
    .bind(...(conn.room_type_id ? [conn.hotel_id, conn.room_type_id] : [conn.hotel_id])).all<any>();

  const events = [
    ...(rows.results || []).map((r: any) => ({
      uid: `pchpms-res-${r.id}@pchpms`,
      summary: `Reserved - ${r.reservation_code}`,
      start: r.check_in_date, end: r.check_out_date,
      description: `Guest: ${r.first_name} ${r.last_name}`
    })),
    ...(blockRows.results || []).map((bl: any) => ({
      uid: `pchpms-block-${bl.id}@pchpms`,
      summary: `Blocked - ${bl.reason || 'Unavailable'}`,
      start: bl.start_date, end: bl.end_date
    }))
  ];
  const ics = generateICal(conn.hotel_name, events);
  return c.text(ics, 200, { 'Content-Type': 'text/calendar; charset=utf-8' });
});

// Trigger a manual (or scheduled-on-request, since Workers cron triggers aren't used here) sync
// for one connection: fetches the iCal import URL, parses events, creates/updates reservations,
// flags duplicates, and prevents double-booking.
channels.post('/connections/:id/sync', async (c) => {
  const id = c.req.param('id');
  const db = c.env.DB;
  const conn = await db.prepare(`SELECT cc.*, ch.name as channel_name FROM channel_connections cc JOIN ota_channels ch ON ch.id = cc.channel_id WHERE cc.id = ?`).bind(id).first<any>();
  if (!conn) return c.json({ error: 'Connection not found' }, 404);

  const startedAt = new Date().toISOString();
  let fetched = 0, created = 0, updated = 0, duplicates = 0, conflicts = 0;
  let status = 'success'; let message = '';

  try {
    if (!conn.ical_import_url) {
      throw new Error('No iCal import URL configured for this connection');
    }
    const resp = await fetch(conn.ical_import_url, { headers: { 'User-Agent': 'PCH PMS-ChannelManager/1.0' } });
    if (!resp.ok) throw new Error(`Failed to fetch calendar feed (HTTP ${resp.status})`);
    const text = await resp.text();
    const events = parseICal(text);
    fetched = events.length;

    // Determine a default room type/room to attach imported bookings to
    let defaultRoomTypeId = conn.room_type_id;
    if (!defaultRoomTypeId) {
      const rt = await db.prepare(`SELECT id FROM room_types WHERE hotel_id = ? ORDER BY id LIMIT 1`).bind(conn.hotel_id).first<any>();
      defaultRoomTypeId = rt?.id || null;
    }

    for (const ev of events) {
      const externalUid = `${conn.channel_name}:${ev.uid}`;
      // Duplicate detection: same external_uid already imported
      const existing = await db.prepare(`SELECT * FROM reservations WHERE hotel_id = ? AND external_uid = ?`).bind(conn.hotel_id, externalUid).first<any>();
      if (existing) {
        // Update dates if the OTA event moved; otherwise treat as already-synced (duplicate skip)
        if (existing.check_in_date === ev.dtstart && existing.check_out_date === ev.dtend) {
          duplicates++;
          continue;
        }
        // Double-booking check before applying update, excluding this reservation itself
        if (existing.room_id) {
          const conflict = await checkRoomConflict(db, conn.hotel_id, existing.room_id, ev.dtstart, ev.dtend, existing.id);
          if (conflict.conflict && conflict.type === 'reservation') { conflicts++; continue; }
        }
        await db.prepare(`UPDATE reservations SET check_in_date=?, check_out_date=?, updated_at=CURRENT_TIMESTAMP WHERE id=?`)
          .bind(ev.dtstart, ev.dtend, existing.id).run();
        updated++;
        continue;
      }

      // Cross-channel duplicate heuristic: same hotel/room-type/date-range already booked (any source)
      let targetRoomId: number | null = null;
      if (defaultRoomTypeId) {
        const freeRoom = await db.prepare(`SELECT id FROM rooms WHERE hotel_id = ? AND room_type_id = ? AND status = 'available'`)
          .bind(conn.hotel_id, defaultRoomTypeId).first<any>();
        targetRoomId = freeRoom?.id || null;
      }
      if (targetRoomId) {
        const conflict = await checkRoomConflict(db, conn.hotel_id, targetRoomId, ev.dtstart, ev.dtend);
        if (conflict.conflict) {
          if (conflict.type === 'reservation' && conflict.with.source && conflict.with.source !== 'walk-in') {
            // Likely the same booking already synced via another path -> treat as duplicate
            duplicates++;
            continue;
          }
          conflicts++;
          continue;
        }
      }

      // Create a placeholder guest for OTA-sourced bookings (no PII typically in free/busy iCal feeds)
      const guestName = (ev.summary || 'OTA Guest').replace(/^(Reserved|Blocked|Closed)[\s-]*/i, '') || 'OTA Guest';
      const guestRes = await db.prepare(`INSERT INTO guests (hotel_id, first_name, last_name) VALUES (?, ?, ?)`)
        .bind(conn.hotel_id, guestName.split(' ')[0] || 'OTA', guestName.split(' ').slice(1).join(' ') || conn.channel_name).run();
      const guestId = guestRes.meta.last_row_id;

      const nights = nightsBetween(ev.dtstart, ev.dtend);
      const roomType = defaultRoomTypeId ? await db.prepare(`SELECT base_price FROM room_types WHERE id = ?`).bind(defaultRoomTypeId).first<any>() : null;
      const rate = roomType?.base_price || 0;
      const code = genCode('OTA');

      await db.prepare(`
        INSERT INTO reservations (hotel_id, reservation_code, guest_id, room_type_id, room_id, check_in_date, check_out_date,
          adults, rate_per_night, total_amount, status, source, channel_id, external_uid, special_requests)
        VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?, ?, 'reserved', ?, ?, ?, ?)`)
        .bind(conn.hotel_id, code, guestId, defaultRoomTypeId, targetRoomId, ev.dtstart, ev.dtend, rate, rate * nights,
          conn.channel_name.toLowerCase(), conn.channel_id, externalUid, ev.description || '')
        .run();
      if (targetRoomId) await db.prepare(`UPDATE rooms SET status = 'reserved' WHERE id = ?`).bind(targetRoomId).run();
      created++;
    }

    await db.prepare(`UPDATE channel_connections SET status='connected', last_sync_at=CURRENT_TIMESTAMP, last_sync_status='success' WHERE id=?`).bind(id).run();
  } catch (e: any) {
    status = 'error';
    message = e.message || 'Sync failed';
    await db.prepare(`UPDATE channel_connections SET status='error', last_sync_at=CURRENT_TIMESTAMP, last_sync_status=? WHERE id=?`).bind(message, id).run();
  }

  await db.prepare(`
    INSERT INTO channel_sync_logs (hotel_id, connection_id, channel_name, direction, status, events_fetched, reservations_created, reservations_updated, duplicates_skipped, conflicts_detected, message, started_at, finished_at)
    VALUES (?, ?, ?, 'import', ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)`)
    .bind(conn.hotel_id, id, conn.channel_name, status, fetched, created, updated, duplicates, conflicts, message, startedAt)
    .run();

  return c.json({ success: status === 'success', status, fetched, created, updated, duplicates, conflicts, message });
});

// Sync all auto-sync-enabled connections for this hotel (one button: "Sync All")
channels.post('/sync-all', async (c) => {
  const hotelId = getHotelId(c);
  const db = c.env.DB;
  const conns = await db.prepare(`SELECT id FROM channel_connections WHERE hotel_id = ? AND auto_sync = 1 AND ical_import_url != ''`).bind(hotelId).all<any>();
  const results = [];
  for (const conn of (conns.results || [])) {
    const resp = await fetch(`${new URL(c.req.url).origin}/api/channels/connections/${conn.id}/sync`, {
      method: 'POST', headers: { 'X-Hotel-Id': String(hotelId) }
    }).catch(() => null);
    if (resp) results.push(await resp.json().catch(() => ({ connection_id: conn.id, error: 'sync failed' })));
  }
  return c.json({ results });
});

export default channels;
