import { Hono } from 'hono';
import type { AppEnv } from '../types';
import { getHotelId, logActivity, todayStr } from '../utils/helpers';
import { computeLiveRoomStatuses, computeLiveRoomStatus, MANUAL_HOUSEKEEPING_STATUSES } from '../utils/roomStatus';

const rooms = new Hono<AppEnv>();

function parseFeatures(f: any): string {
  if (Array.isArray(f)) return JSON.stringify(f);
  if (typeof f === 'string') {
    try { JSON.parse(f); return f; } catch { return JSON.stringify(f.split(',').map((s: string) => s.trim()).filter(Boolean)); }
  }
  return '[]';
}

rooms.get('/', async (c) => {
  const hotelId = getHotelId(c);
  const asOf = c.req.query('date') || todayStr();
  const rows = await c.env.DB.prepare(`
    SELECT r.*, t.name as type_name, t.base_price, t.color as type_color, t.max_occupancy,
      t.bedrooms as type_bedrooms, t.bathrooms as type_bathrooms, t.unit_kind, t.features as type_features,
      (SELECT image_url FROM room_images ri WHERE ri.room_id = r.id ORDER BY ri.is_primary DESC, ri.sort_order ASC LIMIT 1) as primary_image
    FROM rooms r JOIN room_types t ON t.id = r.room_type_id
    WHERE r.hotel_id = ? ORDER BY r.floor, r.room_number`).bind(hotelId).all<any>();
  const list = rows.results || [];
  if (hotelId) {
    const liveMap = await computeLiveRoomStatuses(c.env.DB, hotelId, asOf);
    for (const r of list) {
      const live = liveMap[r.id];
      if (live) { r.status = live.status; r.housekeeping_status = live.housekeeping_status; }
    }
  }
  return c.json(list);
});

rooms.get('/:id', async (c) => {
  const id = c.req.param('id');
  const db = c.env.DB;
  const room = await db.prepare(`
    SELECT r.*, t.name as type_name, t.base_price, t.color as type_color, t.max_occupancy,
      t.bedrooms as type_bedrooms, t.bathrooms as type_bathrooms, t.unit_kind, t.features as type_features
    FROM rooms r JOIN room_types t ON t.id = r.room_type_id WHERE r.id = ?`).bind(id).first<any>();
  if (!room) return c.json({ error: 'Room not found' }, 404);
  const live = await computeLiveRoomStatus(db, room.hotel_id, room.id, todayStr());
  if (live) { room.status = live.status; room.housekeeping_status = live.housekeeping_status; }
  const images = await db.prepare(`SELECT * FROM room_images WHERE room_id = ? ORDER BY is_primary DESC, sort_order ASC`).bind(id).all();
  return c.json({ ...room, images: images.results || [] });
});

rooms.post('/', async (c) => {
  const hotelId = getHotelId(c);
  const b = await c.req.json();
  if (!b.room_number || !b.room_type_id) return c.json({ error: 'Room number and type required' }, 400);
  const r = await c.env.DB.prepare(`INSERT INTO rooms (hotel_id, room_type_id, room_number, floor, status, features, description) VALUES (?, ?, ?, ?, 'available', ?, ?)`)
    .bind(hotelId, b.room_type_id, b.room_number, b.floor || 1, parseFeatures(b.features), b.description || '').run();
  await logActivity(c.env.DB, hotelId, b.created_by, null, 'Added room', b.room_number);
  return c.json({ id: r.meta.last_row_id, success: true });
});

// Full edit: number, type, floor, notes, features, description
rooms.put('/:id', async (c) => {
  const id = c.req.param('id');
  const b = await c.req.json();
  const db = c.env.DB;
  const fields: string[] = []; const vals: any[] = [];
  if (b.room_number !== undefined) { fields.push('room_number=?'); vals.push(b.room_number); }
  if (b.room_type_id !== undefined) { fields.push('room_type_id=?'); vals.push(b.room_type_id); }
  if (b.floor !== undefined) { fields.push('floor=?'); vals.push(b.floor); }
  if (b.notes !== undefined) { fields.push('notes=?'); vals.push(b.notes); }
  if (b.description !== undefined) { fields.push('description=?'); vals.push(b.description); }
  if (b.features !== undefined) { fields.push('features=?'); vals.push(parseFeatures(b.features)); }
  if (b.status !== undefined) { fields.push('status=?'); vals.push(b.status); }
  if (fields.length === 0) return c.json({ success: true });
  vals.push(id);
  await db.prepare(`UPDATE rooms SET ${fields.join(', ')} WHERE id = ?`).bind(...vals).run();
  return c.json({ success: true });
});

// Legacy operational status setter. `status` here only makes sense for a manual
// "maintenance" toggle now (occupied/reserved/available are always derived live) -
// we map it onto housekeeping_status so it keeps working for any old callers.
rooms.put('/:id/status', async (c) => {
  const id = c.req.param('id');
  const { status } = await c.req.json();
  const hk = status === 'maintenance' ? 'out_of_order' : status === 'available' ? 'vacant_clean' : null;
  if (hk) {
    await c.env.DB.prepare(`UPDATE rooms SET housekeeping_status = ? WHERE id = ?`).bind(hk, id).run();
  }
  return c.json({ success: true });
});

// Housekeeping status setter: vacant_clean | vacant_dirty | out_of_order (manual states only;
// occupied/reserved are computed live from reservations and rejected here).
rooms.put('/:id/housekeeping-status', async (c) => {
  const id = c.req.param('id');
  const { status } = await c.req.json();
  if (!MANUAL_HOUSEKEEPING_STATUSES.includes(status)) {
    return c.json({ error: `Invalid status. Must be one of: ${MANUAL_HOUSEKEEPING_STATUSES.join(', ')}` }, 400);
  }
  await c.env.DB.prepare(`UPDATE rooms SET housekeeping_status = ? WHERE id = ?`).bind(status, id).run();
  return c.json({ success: true });
});

rooms.delete('/:id', async (c) => {
  const id = c.req.param('id');
  const db = c.env.DB;
  // Clean up R2 images + DB rows for this room before deleting it
  const imgs = await db.prepare(`SELECT image_key FROM room_images WHERE room_id = ?`).bind(id).all<any>();
  for (const img of (imgs.results || [])) {
    try { await c.env.R2.delete(img.image_key); } catch (e) { /* non-fatal */ }
  }
  await db.prepare(`DELETE FROM room_images WHERE room_id = ?`).bind(id).run();
  await db.prepare(`DELETE FROM rooms WHERE id = ?`).bind(id).run();
  return c.json({ success: true });
});

// ---- Room image gallery (stored in R2) ----
rooms.post('/:id/images', async (c) => {
  const id = c.req.param('id');
  const db = c.env.DB;
  const formData = await c.req.formData();
  const file = formData.get('file') as File | null;
  if (!file) return c.json({ error: 'No file provided' }, 400);
  const ext = (file.name?.split('.').pop() || 'jpg').toLowerCase().replace(/[^a-z0-9]/g, '') || 'jpg';
  const key = `rooms/${id}/${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
  const buf = await file.arrayBuffer();
  await c.env.R2.put(key, buf, { httpMetadata: { contentType: file.type || 'image/jpeg' } });
  const url = `/api/rooms/files/${encodeURIComponent(key)}`;
  const existingCount = await db.prepare(`SELECT COUNT(*) as n FROM room_images WHERE room_id = ?`).bind(id).first<any>();
  const isPrimary = (existingCount?.n || 0) === 0 ? 1 : 0;
  const r = await db.prepare(`INSERT INTO room_images (room_id, image_key, image_url, is_primary, sort_order) VALUES (?, ?, ?, ?, ?)`)
    .bind(id, key, url, isPrimary, existingCount?.n || 0).run();
  return c.json({ id: r.meta.last_row_id, image_url: url, success: true });
});

rooms.get('/files/:key{.+}', async (c) => {
  const key = c.req.param('key');
  const obj = await c.env.R2.get(key);
  if (!obj) return c.notFound();
  return new Response(obj.body, {
    headers: {
      'Content-Type': obj.httpMetadata?.contentType || 'image/jpeg',
      'Cache-Control': 'public, max-age=31536000'
    }
  });
});

rooms.put('/:id/images/:imageId/primary', async (c) => {
  const id = c.req.param('id');
  const imageId = c.req.param('imageId');
  const db = c.env.DB;
  await db.prepare(`UPDATE room_images SET is_primary = 0 WHERE room_id = ?`).bind(id).run();
  await db.prepare(`UPDATE room_images SET is_primary = 1 WHERE id = ?`).bind(imageId).run();
  return c.json({ success: true });
});

rooms.delete('/:id/images/:imageId', async (c) => {
  const imageId = c.req.param('imageId');
  const db = c.env.DB;
  const img = await db.prepare(`SELECT * FROM room_images WHERE id = ?`).bind(imageId).first<any>();
  if (img) {
    try { await c.env.R2.delete(img.image_key); } catch (e) { /* non-fatal */ }
    await db.prepare(`DELETE FROM room_images WHERE id = ?`).bind(imageId).run();
  }
  return c.json({ success: true });
});

export default rooms;
