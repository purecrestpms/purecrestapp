import { Hono } from 'hono';
import type { AppEnv } from '../types';
import { logActivity } from '../utils/helpers';

const admin = new Hono<AppEnv>();

// ---- Property Types ----
admin.get('/property-types', async (c) => {
  const rows = await c.env.DB.prepare(`SELECT * FROM property_types ORDER BY is_system DESC, name`).all();
  return c.json(rows.results || []);
});

admin.post('/property-types', async (c) => {
  const b = await c.req.json();
  if (!b.name) return c.json({ error: 'Name required' }, 400);
  const db = c.env.DB;
  const r = await db.prepare(`INSERT INTO property_types (name, description, icon) VALUES (?, ?, ?)`)
    .bind(b.name, b.description || '', b.icon || 'fa-hotel').run();
  return c.json({ id: r.meta.last_row_id, success: true });
});

admin.put('/property-types/:id', async (c) => {
  const id = c.req.param('id');
  const b = await c.req.json();
  await c.env.DB.prepare(`UPDATE property_types SET name=?, description=?, icon=? WHERE id=? AND is_system=0`)
    .bind(b.name, b.description || '', b.icon || 'fa-hotel', id).run();
  return c.json({ success: true });
});

admin.delete('/property-types/:id', async (c) => {
  const id = c.req.param('id');
  await c.env.DB.prepare(`DELETE FROM property_types WHERE id = ? AND is_system = 0`).bind(id).run();
  return c.json({ success: true });
});

// ---- Roles ----
admin.get('/roles', async (c) => {
  const rows = await c.env.DB.prepare(`SELECT * FROM roles ORDER BY is_system DESC, name`).all();
  return c.json(rows.results || []);
});

admin.post('/roles', async (c) => {
  const b = await c.req.json();
  if (!b.key || !b.name) return c.json({ error: 'Key and name required' }, 400);
  const db = c.env.DB;
  const existing = await db.prepare(`SELECT id FROM roles WHERE key = ?`).bind(b.key).first();
  if (existing) return c.json({ error: 'Role key already exists' }, 400);
  const perms = typeof b.permissions === 'object' ? JSON.stringify(b.permissions) : (b.permissions || '{}');
  const r = await db.prepare(`INSERT INTO roles (key, name, description, permissions) VALUES (?, ?, ?, ?)`)
    .bind(b.key, b.name, b.description || '', perms).run();
  return c.json({ id: r.meta.last_row_id, success: true });
});

admin.put('/roles/:id', async (c) => {
  const id = c.req.param('id');
  const b = await c.req.json();
  const perms = typeof b.permissions === 'object' ? JSON.stringify(b.permissions) : b.permissions;
  await c.env.DB.prepare(`UPDATE roles SET name=?, description=?, permissions=COALESCE(?,permissions) WHERE id=? AND is_system=0`)
    .bind(b.name, b.description || '', perms ?? null, id).run();
  return c.json({ success: true });
});

admin.delete('/roles/:id', async (c) => {
  const id = c.req.param('id');
  await c.env.DB.prepare(`DELETE FROM roles WHERE id = ? AND is_system = 0`).bind(id).run();
  return c.json({ success: true });
});

// ---- Platform-wide stats for super admin dashboard ----
admin.get('/stats', async (c) => {
  const db = c.env.DB;
  const hotels = await db.prepare(`SELECT COUNT(*) as n FROM hotels`).first<any>();
  const rooms = await db.prepare(`SELECT COUNT(*) as n FROM rooms`).first<any>();
  const users = await db.prepare(`SELECT COUNT(*) as n FROM users WHERE role != 'super_admin'`).first<any>();
  const activeReservations = await db.prepare(`SELECT COUNT(*) as n FROM reservations WHERE status IN ('reserved','checked-in')`).first<any>();
  return c.json({ hotels: hotels?.n || 0, rooms: rooms?.n || 0, users: users?.n || 0, activeReservations: activeReservations?.n || 0 });
});

// ---- Downloadable full-database backup (super admin only, enforced client-side by role gating + here by requiring no hotel scoping) ----
admin.get('/backup', async (c) => {
  const db = c.env.DB;
  const tables = [
    'property_types', 'roles', 'hotels', 'users', 'room_types', 'rooms', 'guests', 'reservations',
    'payments', 'invoices', 'housekeeping_tasks', 'pos_items', 'pos_orders', 'shifts', 'messages',
    'loyalty_transactions', 'activity_log', 'room_blocks', 'ota_channels', 'channel_connections', 'channel_sync_logs'
  ];
  const backup: Record<string, any[]> = {};
  for (const t of tables) {
    try {
      const rows = await db.prepare(`SELECT * FROM ${t}`).all();
      backup[t] = rows.results || [];
    } catch (e) { backup[t] = []; }
  }
  const payload = {
    generated_at: new Date().toISOString(),
    app: 'PCH PMS',
    version: 2,
    tables: backup
  };
  await logActivity(db, null, null, 'Super Admin', 'Downloaded full system backup', '');
  return c.json(payload, 200, {
    'Content-Disposition': `attachment; filename="pchpms_backup_${new Date().toISOString().split('T')[0]}.json"`
  });
});

export default admin;
