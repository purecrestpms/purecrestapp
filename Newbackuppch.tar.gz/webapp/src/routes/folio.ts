import { Hono } from 'hono';
import type { AppEnv } from '../types';

const folio = new Hono<AppEnv>();

folio.get('/:resId', async (c) => {
  const resId = c.req.param('resId');
  const db = c.env.DB;
  const r = await db.prepare(`
    SELECT res.*, g.first_name, g.last_name, g.phone as guest_phone, g.email as guest_email,
    rm.room_number, rt.name as room_type_name, h.name as hotel_name, h.address as hotel_address,
    h.city as hotel_city, h.country as hotel_country, h.phone as hotel_phone, h.email as hotel_email
    FROM reservations res
    JOIN guests g ON g.id = res.guest_id
    LEFT JOIN rooms rm ON rm.id = res.room_id
    LEFT JOIN room_types rt ON rt.id = res.room_type_id
    LEFT JOIN hotels h ON h.id = res.hotel_id
    WHERE res.id = ?`).bind(resId).first<any>();
  if (!r) return c.json({ error: 'Reservation not found' }, 404);
  const payments = await db.prepare(`SELECT * FROM payments WHERE reservation_id = ? ORDER BY created_at ASC`).bind(resId).all();
  const posOrders = await db.prepare(`SELECT * FROM pos_orders WHERE reservation_id = ? ORDER BY created_at ASC`).bind(resId).all();
  return c.json({ ...r, payments: payments.results || [], pos_orders: posOrders.results || [] });
});

export default folio;
