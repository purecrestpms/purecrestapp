import { Hono } from 'hono';
import type { AppEnv } from '../types';
import { getHotelId, logActivity } from '../utils/helpers';

const payments = new Hono<AppEnv>();

payments.get('/', async (c) => {
  const hotelId = getHotelId(c);
  const from = c.req.query('from');
  const to = c.req.query('to');
  const db = c.env.DB;
  let q = `SELECT p.*, g.first_name, g.last_name, r.reservation_code FROM payments p
    LEFT JOIN guests g ON g.id = p.guest_id
    LEFT JOIN reservations r ON r.id = p.reservation_id
    WHERE p.hotel_id = ?`;
  const params: any[] = [hotelId];
  if (from) { q += ` AND date(p.created_at) >= date(?)`; params.push(from); }
  if (to) { q += ` AND date(p.created_at) <= date(?)`; params.push(to); }
  q += ` ORDER BY p.created_at DESC`;
  const rows = await db.prepare(q).bind(...params).all();
  return c.json(rows.results || []);
});

payments.post('/', async (c) => {
  const hotelId = getHotelId(c);
  const b = await c.req.json();
  const db = c.env.DB;
  const amount = b.is_refund ? -Math.abs(b.amount) : Math.abs(b.amount);
  const r = await db.prepare(`
    INSERT INTO payments (hotel_id, reservation_id, guest_id, amount, payment_method, payment_type, reference_number, notes, shift_id, received_by, is_refund)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
    .bind(hotelId, b.reservation_id || null, b.guest_id || null, amount, b.payment_method || 'cash', b.payment_type || 'room_charge', b.reference_number || '', b.notes || '', b.shift_id || null, b.received_by || null, b.is_refund ? 1 : 0)
    .run();
  if (b.reservation_id) {
    await db.prepare(`UPDATE reservations SET paid_amount = paid_amount + ? WHERE id = ?`).bind(amount, b.reservation_id).run();
  }
  if (b.shift_id) {
    const col = b.payment_method === 'cash' ? 'total_cash' : b.payment_method === 'card' ? 'total_card' : 'total_transfer';
    await db.prepare(`UPDATE shifts SET total_payments = total_payments + ?, ${col} = ${col} + ?, expected_balance = expected_balance + ? WHERE id = ?`)
      .bind(amount, amount, amount, b.shift_id).run();
  }
  await logActivity(db, hotelId, b.received_by, null, b.is_refund ? 'Issued refund' : 'Recorded payment', `${amount}`);
  return c.json({ id: r.meta.last_row_id, success: true });
});

// Refund endpoint (explicit, for clarity in reporting)
payments.post('/:id/refund', async (c) => {
  const id = c.req.param('id');
  const hotelId = getHotelId(c);
  const b = await c.req.json();
  const db = c.env.DB;
  const orig = await db.prepare(`SELECT * FROM payments WHERE id = ?`).bind(id).first<any>();
  if (!orig) return c.json({ error: 'Payment not found' }, 404);
  const refundAmount = b.amount ? Math.abs(b.amount) : Math.abs(orig.amount);
  const r = await db.prepare(`
    INSERT INTO payments (hotel_id, reservation_id, guest_id, amount, payment_method, payment_type, notes, received_by, is_refund)
    VALUES (?, ?, ?, ?, ?, 'refund', ?, ?, 1)`)
    .bind(hotelId, orig.reservation_id, orig.guest_id, -refundAmount, orig.payment_method, b.reason || 'Refund', b.received_by || null)
    .run();
  if (orig.reservation_id) {
    await db.prepare(`UPDATE reservations SET paid_amount = paid_amount - ? WHERE id = ?`).bind(refundAmount, orig.reservation_id).run();
  }
  await logActivity(db, hotelId, b.received_by, null, 'Issued refund', `${refundAmount} for payment #${id}`);
  return c.json({ id: r.meta.last_row_id, success: true });
});

export default payments;
