import { Hono } from 'hono';
import type { AppEnv } from '../types';
import { getHotelId, logActivity, nightsBetween } from '../utils/helpers';
import { genToken, genCode } from '../utils/crypto';
import { parseICal, generateICal } from '../utils/ical';
import { checkRoomConflict } from './reservations';

const roomIcal = new Hono<AppEnv>();

// ---- List / CRUD feeds for a given room ----
roomIcal.get('/room/:roomId', async (c) => {
  const roomId = c.req.param('roomId');
  const rows = await c.env.DB.prepare(`SELECT * FROM room_ical_feeds WHERE room_id = ? ORDER BY created_at DESC`).bind(roomId).all();
  return c.json(rows.results || []);
});

// All feeds for the current hotel (used by the Rooms & Units overview / Channel manager tab)
roomIcal.get('/', async (c) => {
  const hotelId = getHotelId(c);
  const rows = await c.env.DB.prepare(`
    SELECT f.*, r.room_number, t.name as type_name
    FROM room_ical_feeds f JOIN rooms r ON r.id = f.room_id LEFT JOIN room_types t ON t.id = r.room_type_id
    WHERE f.hotel_id = ? ORDER BY r.room_number`).bind(hotelId).all();
  return c.json(rows.results || []);
});

roomIcal.post('/', async (c) => {
  const hotelId = getHotelId(c);
  const b = await c.req.json();
  if (!b.room_id) return c.json({ error: 'room_id required' }, 400);
  const db = c.env.DB;
  const exportToken = genToken(16);
  const r = await db.prepare(`
    INSERT INTO room_ical_feeds (hotel_id, room_id, label, source_name, import_url, export_token, auto_sync, status, created_by)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`)
    .bind(hotelId, b.room_id, b.label || '', b.source_name || 'Other', b.import_url || '', exportToken,
      b.auto_sync === false ? 0 : 1, b.import_url ? 'connected' : 'pending', b.created_by || null)
    .run();
  await logActivity(db, hotelId, b.created_by, null, 'Added room iCal feed', b.label || `Room #${b.room_id}`);
  return c.json({ id: r.meta.last_row_id, export_token: exportToken, success: true });
});

roomIcal.put('/:id', async (c) => {
  const id = c.req.param('id');
  const b = await c.req.json();
  const db = c.env.DB;
  const fields: string[] = []; const vals: any[] = [];
  for (const k of ['label', 'source_name', 'import_url', 'status']) {
    if (b[k] !== undefined) { fields.push(`${k}=?`); vals.push(b[k]); }
  }
  if (b.auto_sync !== undefined) { fields.push('auto_sync=?'); vals.push(b.auto_sync ? 1 : 0); }
  if (fields.length === 0) return c.json({ success: true });
  vals.push(id);
  await db.prepare(`UPDATE room_ical_feeds SET ${fields.join(', ')} WHERE id = ?`).bind(...vals).run();
  return c.json({ success: true });
});

roomIcal.delete('/:id', async (c) => {
  const id = c.req.param('id');
  await c.env.DB.prepare(`DELETE FROM room_ical_feeds WHERE id = ?`).bind(id).run();
  await c.env.DB.prepare(`DELETE FROM room_ical_sync_logs WHERE feed_id = ?`).bind(id).run();
  return c.json({ success: true });
});

// ---- Export: this room's availability as an iCal feed (for the OTA to pull) ----
roomIcal.get('/:id/export.ics', async (c) => {
  const id = c.req.param('id');
  const db = c.env.DB;
  const feed = await db.prepare(`
    SELECT f.*, r.room_number, h.name as hotel_name FROM room_ical_feeds f
    JOIN rooms r ON r.id = f.room_id JOIN hotels h ON h.id = f.hotel_id WHERE f.id = ?`).bind(id).first<any>();
  if (!feed) return c.text('Not found', 404);

  const rows = await db.prepare(`
    SELECT res.id, res.reservation_code, res.check_in_date, res.check_out_date, g.first_name, g.last_name
    FROM reservations res JOIN guests g ON g.id = res.guest_id
    WHERE res.room_id = ? AND res.status NOT IN ('cancelled','checked-out')`).bind(feed.room_id).all<any>();
  const blockRows = await db.prepare(`SELECT * FROM room_blocks WHERE room_id = ?`).bind(feed.room_id).all<any>();

  const events = [
    ...(rows.results || []).map((r: any) => ({
      uid: `pchpms-res-${r.id}@pchpms`,
      summary: `Reserved - ${r.reservation_code}`,
      start: r.check_in_date, end: r.check_out_date,
      description: `Guest: ${r.first_name} ${r.last_name}`
    })),
    ...(blockRows.results || []).map((bl: any) => ({
      uid: `pchpms-block-${bl.id}@pchpms`,
      summary: `Blocked - ${bl.reason || 'Unavailable'}`,
      start: bl.start_date, end: bl.end_date
    }))
  ];
  const ics = generateICal(`${feed.hotel_name} - Room ${feed.room_number}`, events);
  return c.text(ics, 200, { 'Content-Type': 'text/calendar; charset=utf-8' });
});

// ---- Sync: fetch the per-room import URL, detect new/modified/cancelled bookings ----
roomIcal.post('/:id/sync', async (c) => {
  const id = c.req.param('id');
  const db = c.env.DB;
  const feed = await db.prepare(`SELECT * FROM room_ical_feeds WHERE id = ?`).bind(id).first<any>();
  if (!feed) return c.json({ error: 'Feed not found' }, 404);

  const startedAt = new Date().toISOString();
  let fetched = 0, created = 0, updated = 0, cancelledCount = 0, duplicates = 0, conflicts = 0;
  let status = 'success'; let message = '';

  try {
    if (!feed.import_url) throw new Error('No iCal import URL configured for this room');
    const resp = await fetch(feed.import_url, { headers: { 'User-Agent': 'PCH-PMS-RoomSync/1.0' } });
    if (!resp.ok) throw new Error(`Failed to fetch calendar feed (HTTP ${resp.status})`);
    const text = await resp.text();
    const events = parseICal(text);
    fetched = events.length;

    const room = await db.prepare(`SELECT * FROM rooms r WHERE r.id = ?`).bind(feed.room_id).first<any>();
    const roomType = room ? await db.prepare(`SELECT base_price FROM room_types WHERE id = ?`).bind(room.room_type_id).first<any>() : null;

    const seenUids = new Set<string>();
    for (const ev of events) {
      const externalUid = `${feed.source_name}:${ev.uid}`;
      seenUids.add(externalUid);

      const existing = await db.prepare(`SELECT * FROM reservations WHERE ical_feed_id = ? AND external_uid = ?`).bind(feed.id, externalUid).first<any>();
      if (existing) {
        if (existing.check_in_date === ev.dtstart && existing.check_out_date === ev.dtend) {
          duplicates++;
          continue;
        }
        // Dates moved on the OTA side -> detect as "modified", check for conflicts first
        const conflict = await checkRoomConflict(db, feed.hotel_id, feed.room_id, ev.dtstart, ev.dtend, existing.id);
        if (conflict.conflict && conflict.type === 'reservation') { conflicts++; continue; }
        await db.prepare(`UPDATE reservations SET check_in_date=?, check_out_date=?, updated_at=CURRENT_TIMESTAMP WHERE id=?`)
          .bind(ev.dtstart, ev.dtend, existing.id).run();
        updated++;
        continue;
      }

      // New external booking: check room availability before creating
      const conflict = await checkRoomConflict(db, feed.hotel_id, feed.room_id, ev.dtstart, ev.dtend);
      if (conflict.conflict) {
        if (conflict.type === 'reservation') { duplicates++; continue; }
        conflicts++; continue;
      }

      const guestName = (ev.summary || `${feed.source_name} Guest`).replace(/^(Reserved|Blocked|Closed)[\s-]*/i, '') || `${feed.source_name} Guest`;
      const guestRes = await db.prepare(`INSERT INTO guests (hotel_id, first_name, last_name) VALUES (?, ?, ?)`)
        .bind(feed.hotel_id, guestName.split(' ')[0] || feed.source_name, guestName.split(' ').slice(1).join(' ') || 'Guest').run();
      const guestId = guestRes.meta.last_row_id;

      const nights = nightsBetween(ev.dtstart, ev.dtend);
      const rate = roomType?.base_price || 0;
      const code = genCode('ICAL');

      await db.prepare(`
        INSERT INTO reservations (hotel_id, reservation_code, guest_id, room_type_id, room_id, check_in_date, check_out_date,
          adults, rate_per_night, total_amount, status, source, external_uid, ical_feed_id, special_requests)
        VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?, ?, 'reserved', ?, ?, ?, ?)`)
        .bind(feed.hotel_id, code, guestId, room?.room_type_id || null, feed.room_id, ev.dtstart, ev.dtend, rate, rate * nights,
          feed.source_name.toLowerCase(), externalUid, feed.id, ev.description || '')
        .run();
      await db.prepare(`UPDATE rooms SET status = 'reserved' WHERE id = ?`).bind(feed.room_id).run();
      created++;
    }

    // Cancellation detection: any previously-imported reservation from this feed whose
    // UID no longer appears in the feed is treated as cancelled by the OTA.
    const priorImports = await db.prepare(`
      SELECT id, reservation_code, external_uid, room_id FROM reservations
      WHERE ical_feed_id = ? AND status NOT IN ('cancelled','checked-out')`).bind(feed.id).all<any>();
    for (const res of (priorImports.results || [])) {
      if (!seenUids.has(res.external_uid)) {
        await db.prepare(`UPDATE reservations SET status='cancelled', updated_at=CURRENT_TIMESTAMP WHERE id=?`).bind(res.id).run();
        await db.prepare(`UPDATE rooms SET status='available' WHERE id=? AND status != 'occupied'`).bind(res.room_id).run();
        cancelledCount++;
      }
    }

    await db.prepare(`UPDATE room_ical_feeds SET status='connected', last_sync_at=CURRENT_TIMESTAMP, last_sync_status='success' WHERE id=?`).bind(id).run();
  } catch (e: any) {
    status = 'error';
    message = e.message || 'Sync failed';
    await db.prepare(`UPDATE room_ical_feeds SET status='error', last_sync_at=CURRENT_TIMESTAMP, last_sync_status=? WHERE id=?`).bind(message, id).run();
  }

  await db.prepare(`
    INSERT INTO room_ical_sync_logs (hotel_id, feed_id, room_id, status, events_fetched, created_count, updated_count, cancelled_count, duplicates_skipped, conflicts_detected, message, started_at, finished_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)`)
    .bind(feed.hotel_id, id, feed.room_id, status, fetched, created, updated, cancelledCount, duplicates, conflicts, message, startedAt)
    .run();

  return c.json({ success: status === 'success', status, fetched, created, updated, cancelled: cancelledCount, duplicates, conflicts, message });
});

// Sync all auto-sync-enabled room feeds for this hotel
roomIcal.post('/sync-all', async (c) => {
  const hotelId = getHotelId(c);
  const db = c.env.DB;
  const feeds = await db.prepare(`SELECT id FROM room_ical_feeds WHERE hotel_id = ? AND auto_sync = 1 AND import_url != ''`).bind(hotelId).all<any>();
  const results = [];
  for (const feed of (feeds.results || [])) {
    const resp = await fetch(`${new URL(c.req.url).origin}/api/room-ical/${feed.id}/sync`, {
      method: 'POST', headers: { 'X-Hotel-Id': String(hotelId) }
    }).catch(() => null);
    if (resp) results.push(await resp.json().catch(() => ({ feed_id: feed.id, error: 'sync failed' })));
  }
  return c.json({ results });
});

// Sync logs for a room (or whole hotel if no room specified)
roomIcal.get('/sync-logs', async (c) => {
  const hotelId = getHotelId(c);
  const roomId = c.req.query('room_id');
  let q = `SELECT l.*, r.room_number FROM room_ical_sync_logs l LEFT JOIN rooms r ON r.id = l.room_id WHERE l.hotel_id = ?`;
  const params: any[] = [hotelId];
  if (roomId) { q += ` AND l.room_id = ?`; params.push(roomId); }
  q += ` ORDER BY l.started_at DESC LIMIT 100`;
  const rows = await c.env.DB.prepare(q).bind(...params).all();
  return c.json(rows.results || []);
});

export default roomIcal;
