import { Hono } from 'hono';
import type { AppEnv } from '../types';
import { getHotelId } from '../utils/helpers';

const roomTypes = new Hono<AppEnv>();

function parseFeatures(f: any): string {
  if (Array.isArray(f)) return JSON.stringify(f);
  if (typeof f === 'string') {
    try { JSON.parse(f); return f; } catch { return JSON.stringify(f.split(',').map((s: string) => s.trim()).filter(Boolean)); }
  }
  return '[]';
}

roomTypes.get('/', async (c) => {
  const hotelId = getHotelId(c);
  const rows = await c.env.DB.prepare(`
    SELECT t.*, (SELECT COUNT(*) FROM rooms r WHERE r.room_type_id = t.id) as room_count
    FROM room_types t WHERE t.hotel_id = ? ORDER BY t.base_price`).bind(hotelId).all();
  return c.json(rows.results || []);
});

roomTypes.post('/', async (c) => {
  const hotelId = getHotelId(c);
  const b = await c.req.json();
  if (!b.name) return c.json({ error: 'Name required' }, 400);
  const r = await c.env.DB.prepare(`
    INSERT INTO room_types (hotel_id, name, base_price, max_occupancy, color, description, bedrooms, bathrooms, unit_kind, features)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
    .bind(hotelId, b.name, b.base_price || 0, b.max_occupancy || 2, b.color || '#6C63FF', b.description || '',
      b.bedrooms ?? 1, b.bathrooms ?? 1, b.unit_kind || 'room', parseFeatures(b.features)).run();
  return c.json({ id: r.meta.last_row_id, success: true });
});

roomTypes.put('/:id', async (c) => {
  const id = c.req.param('id');
  const b = await c.req.json();
  await c.env.DB.prepare(`
    UPDATE room_types SET name=?, base_price=?, max_occupancy=?, color=?, description=COALESCE(?,description),
    bedrooms=COALESCE(?,bedrooms), bathrooms=COALESCE(?,bathrooms), unit_kind=COALESCE(?,unit_kind), features=COALESCE(?,features) WHERE id=?`)
    .bind(b.name, b.base_price, b.max_occupancy, b.color, b.description ?? null,
      b.bedrooms ?? null, b.bathrooms ?? null, b.unit_kind ?? null, b.features !== undefined ? parseFeatures(b.features) : null, id).run();
  return c.json({ success: true });
});

roomTypes.delete('/:id', async (c) => {
  const id = c.req.param('id');
  await c.env.DB.prepare(`DELETE FROM room_types WHERE id = ?`).bind(id).run();
  return c.json({ success: true });
});

export default roomTypes;
