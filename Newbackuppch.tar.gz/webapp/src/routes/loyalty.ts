import { Hono } from 'hono';
import type { AppEnv } from '../types';

const loyalty = new Hono<AppEnv>();

loyalty.post('/redeem', async (c) => {
  const b = await c.req.json();
  const db = c.env.DB;
  const guest = await db.prepare(`SELECT * FROM guests WHERE id = ?`).bind(b.guest_id).first<any>();
  if (!guest) return c.json({ error: 'Guest not found' }, 404);
  if ((guest.loyalty_points || 0) < b.points) return c.json({ error: 'Insufficient points' }, 400);
  await db.prepare(`UPDATE guests SET loyalty_points = loyalty_points - ? WHERE id = ?`).bind(b.points, b.guest_id).run();
  await db.prepare(`INSERT INTO loyalty_transactions (guest_id, type, points, description) VALUES (?, 'redeem', ?, ?)`)
    .bind(b.guest_id, b.points, b.description || 'Points redeemed').run();
  return c.json({ success: true });
});

export default loyalty;
