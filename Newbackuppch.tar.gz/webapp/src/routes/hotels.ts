import { Hono } from 'hono';
import type { AppEnv } from '../types';
import { logActivity } from '../utils/helpers';

const hotels = new Hono<AppEnv>();

hotels.get('/', async (c) => {
  const db = c.env.DB;
  const rows = await db.prepare(`
    SELECT h.*, pt.name as property_type_name,
    (SELECT COUNT(*) FROM rooms r WHERE r.hotel_id = h.id) as room_count,
    (SELECT COUNT(*) FROM users u WHERE u.hotel_id = h.id) as staff_count
    FROM hotels h LEFT JOIN property_types pt ON pt.id = h.property_type_id
    ORDER BY h.name`).all();
  return c.json(rows.results || []);
});

hotels.get('/:id', async (c) => {
  const id = c.req.param('id');
  const h = await c.env.DB.prepare(`SELECT * FROM hotels WHERE id = ?`).bind(id).first();
  if (!h) return c.json({ error: 'Hotel not found' }, 404);
  return c.json(h);
});

hotels.post('/', async (c) => {
  const b = await c.req.json();
  if (!b.name) return c.json({ error: 'Name required' }, 400);
  const db = c.env.DB;
  const r = await db.prepare(`
    INSERT INTO hotels (name, code, property_type_id, address, city, country, phone, email, currency, tax_rate, checkin_time, checkout_time)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
    .bind(b.name, b.code || null, b.property_type_id || null, b.address || '', b.city || '', b.country || '', b.phone || '', b.email || '', b.currency || '₦', b.tax_rate ?? 7.5, b.checkin_time || '14:00', b.checkout_time || '12:00')
    .run();
  const hotelId = r.meta.last_row_id;
  // Seed a default room type so the hotel is immediately usable
  await db.prepare(`INSERT INTO room_types (hotel_id, name, base_price, max_occupancy, color) VALUES (?, 'Standard Room', 20000, 2, '#6C63FF')`).bind(hotelId).run();
  await logActivity(db, null, null, 'Super Admin', 'Created hotel', b.name);
  return c.json({ id: hotelId, success: true });
});

hotels.put('/:id', async (c) => {
  const id = c.req.param('id');
  const b = await c.req.json();
  const db = c.env.DB;
  await db.prepare(`UPDATE hotels SET name=?, code=?, address=?, city=?, country=?, phone=?, email=?, currency=?, tax_rate=COALESCE(?,tax_rate), checkin_time=COALESCE(?,checkin_time), checkout_time=COALESCE(?,checkout_time) WHERE id=?`)
    .bind(b.name, b.code, b.address || '', b.city || '', b.country || '', b.phone || '', b.email || '', b.currency || '₦', b.tax_rate ?? null, b.checkin_time ?? null, b.checkout_time ?? null, id).run();
  return c.json({ success: true });
});

hotels.delete('/:id', async (c) => {
  const id = c.req.param('id');
  await c.env.DB.prepare(`DELETE FROM hotels WHERE id = ?`).bind(id).run();
  return c.json({ success: true });
});

export default hotels;
