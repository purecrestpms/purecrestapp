import { Hono } from 'hono';
import type { AppEnv } from '../types';
import { hashPassword, verifyPassword } from '../utils/crypto';
import { logActivity } from '../utils/helpers';

const auth = new Hono<AppEnv>();

auth.post('/login', async (c) => {
  const { username, password } = await c.req.json();
  if (!username || !password) return c.json({ error: 'Username and password required' }, 400);
  const db = c.env.DB;
  const user = await db.prepare(`SELECT * FROM users WHERE username = ? AND is_active = 1`).bind(username).first<any>();
  if (!user) return c.json({ error: 'Invalid username or password' }, 401);
  const ok = await verifyPassword(password, user.password_hash);
  if (!ok) return c.json({ error: 'Invalid username or password' }, 401);

  await db.prepare(`UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = ?`).bind(user.id).run();

  const safeUser: any = {
    id: user.id, username: user.username, full_name: user.full_name, role: user.role,
    email: user.email, phone: user.phone, permissions: user.permissions, hotel_id: user.hotel_id
  };

  let hotels: any[] = [];
  if (user.role === 'super_admin') {
    const rows = await db.prepare(`
      SELECT h.*, (SELECT COUNT(*) FROM rooms r WHERE r.hotel_id = h.id) as room_count,
      (SELECT COUNT(*) FROM users u WHERE u.hotel_id = h.id) as staff_count
      FROM hotels h ORDER BY h.name`).all();
    hotels = rows.results || [];
  } else if (user.hotel_id) {
    const hotel = await db.prepare(`SELECT * FROM hotels WHERE id = ?`).bind(user.hotel_id).first<any>();
    if (hotel) {
      safeUser.hotel_name = hotel.name;
      safeUser.hotel_city = hotel.city;
      safeUser.hotel_currency = hotel.currency;
    }
  }

  await logActivity(db, user.hotel_id, user.id, user.full_name, 'Logged in', '');
  return c.json({ user: safeUser, hotels });
});

auth.put('/change-password', async (c) => {
  const { user_id, current_password, new_password } = await c.req.json();
  const db = c.env.DB;
  const user = await db.prepare(`SELECT * FROM users WHERE id = ?`).bind(user_id).first<any>();
  if (!user) return c.json({ error: 'User not found' }, 404);
  const ok = await verifyPassword(current_password, user.password_hash);
  if (!ok) return c.json({ error: 'Current password incorrect' }, 401);
  const newHash = await hashPassword(new_password);
  await db.prepare(`UPDATE users SET password_hash = ? WHERE id = ?`).bind(newHash, user_id).run();
  return c.json({ success: true });
});

export default auth;
