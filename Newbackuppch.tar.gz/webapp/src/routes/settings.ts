import { Hono } from 'hono';
import type { AppEnv } from '../types';
import { getHotelId } from '../utils/helpers';

const settings = new Hono<AppEnv>();

settings.get('/property', async (c) => {
  const hotelId = getHotelId(c);
  const h = await c.env.DB.prepare(`SELECT * FROM hotels WHERE id = ?`).bind(hotelId).first();
  if (!h) return c.json({ error: 'Hotel not found' }, 404);
  return c.json(h);
});

settings.put('/property', async (c) => {
  const hotelId = getHotelId(c);
  const b = await c.req.json();
  await c.env.DB.prepare(`
    UPDATE hotels SET name=?, address=?, city=?, country=?, phone=?, email=?, currency=?, tax_rate=?, checkin_time=?, checkout_time=? WHERE id=?`)
    .bind(b.name, b.address || '', b.city || '', b.country || '', b.phone || '', b.email || '', b.currency || '₦', b.tax_rate ?? 7.5, b.checkin_time || '14:00', b.checkout_time || '12:00', hotelId)
    .run();
  return c.json({ success: true });
});

export default settings;
