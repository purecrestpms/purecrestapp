import { Hono } from 'hono';
import type { AppEnv } from '../types';
import { getHotelId } from '../utils/helpers';

const guests = new Hono<AppEnv>();

guests.get('/', async (c) => {
  const hotelId = getHotelId(c);
  const search = c.req.query('search') || '';
  const db = c.env.DB;
  let q = `SELECT * FROM guests WHERE hotel_id = ?`;
  const params: any[] = [hotelId];
  if (search) {
    q += ` AND (first_name LIKE ? OR last_name LIKE ? OR phone LIKE ? OR email LIKE ?)`;
    const s = `%${search}%`;
    params.push(s, s, s, s);
  }
  q += ` ORDER BY first_name, last_name`;
  const rows = await db.prepare(q).bind(...params).all();
  return c.json(rows.results || []);
});

guests.get('/:id', async (c) => {
  const id = c.req.param('id');
  const db = c.env.DB;
  const g = await db.prepare(`SELECT * FROM guests WHERE id = ?`).bind(id).first<any>();
  if (!g) return c.json({ error: 'Guest not found' }, 404);
  const resRows = await db.prepare(`
    SELECT r.*, rm.room_number, rt.name as room_type_name FROM reservations r
    LEFT JOIN rooms rm ON rm.id = r.room_id
    LEFT JOIN room_types rt ON rt.id = r.room_type_id
    WHERE r.guest_id = ? ORDER BY r.check_in_date DESC`).bind(id).all();
  const loyaltyRows = await db.prepare(`SELECT * FROM loyalty_transactions WHERE guest_id = ? ORDER BY created_at DESC`).bind(id).all();
  return c.json({ ...g, reservations: resRows.results || [], loyalty: loyaltyRows.results || [] });
});

guests.post('/', async (c) => {
  const hotelId = getHotelId(c);
  const b = await c.req.json();
  if (!b.first_name || !b.last_name) return c.json({ error: 'Name required' }, 400);
  const db = c.env.DB;
  const r = await db.prepare(`
    INSERT INTO guests (hotel_id, first_name, last_name, phone, email, id_type, id_number, nationality, address, city, country, date_of_birth, gender, company, vip_status)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
    .bind(hotelId, b.first_name, b.last_name, b.phone || '', b.email || '', b.id_type || '', b.id_number || '', b.nationality || '', b.address || '', b.city || '', b.country || '', b.date_of_birth || '', b.gender || '', b.company || '', b.vip_status ? 1 : 0)
    .run();
  return c.json({ id: r.meta.last_row_id, success: true });
});

guests.put('/:id', async (c) => {
  const id = c.req.param('id');
  const b = await c.req.json();
  await c.env.DB.prepare(`
    UPDATE guests SET first_name=?, last_name=?, phone=?, email=?, address=?, city=?, country=?, nationality=?, vip_status=? WHERE id=?`)
    .bind(b.first_name, b.last_name, b.phone || '', b.email || '', b.address || '', b.city || '', b.country || '', b.nationality || '', b.vip_status ? 1 : 0, id).run();
  return c.json({ success: true });
});

guests.delete('/:id', async (c) => {
  const id = c.req.param('id');
  await c.env.DB.prepare(`DELETE FROM guests WHERE id = ?`).bind(id).run();
  return c.json({ success: true });
});

export default guests;
