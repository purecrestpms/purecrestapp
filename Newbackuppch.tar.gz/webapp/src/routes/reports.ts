import { Hono } from 'hono';
import type { AppEnv } from '../types';
import { getHotelId } from '../utils/helpers';

const reports = new Hono<AppEnv>();

reports.get('/revenue', async (c) => {
  const hotelId = getHotelId(c);
  const from = c.req.query('from');
  const to = c.req.query('to');
  const db = c.env.DB;
  let q = `SELECT date(created_at) as date, SUM(amount) as total FROM payments WHERE hotel_id = ? AND is_refund = 0`;
  const params: any[] = [hotelId];
  if (from) { q += ` AND date(created_at) >= date(?)`; params.push(from); }
  if (to) { q += ` AND date(created_at) <= date(?)`; params.push(to); }
  q += ` GROUP BY date(created_at) ORDER BY date DESC LIMIT 30`;
  const rows = await db.prepare(q).bind(...params).all<any>();
  const daily = rows.results || [];
  const total = daily.reduce((s: number, d: any) => s + (d.total || 0), 0);
  return c.json({ daily, total });
});

reports.get('/occupancy', async (c) => {
  const hotelId = getHotelId(c);
  const db = c.env.DB;
  const overall = await db.prepare(`SELECT status, COUNT(*) as count FROM rooms WHERE hotel_id = ? GROUP BY status`).bind(hotelId).all();
  const byType = await db.prepare(`
    SELECT t.name,
      COUNT(r.id) as total,
      SUM(CASE WHEN r.status='occupied' THEN 1 ELSE 0 END) as occupied,
      SUM(CASE WHEN r.status='available' THEN 1 ELSE 0 END) as available,
      SUM(CASE WHEN r.status='reserved' THEN 1 ELSE 0 END) as reserved,
      SUM(CASE WHEN r.status='maintenance' THEN 1 ELSE 0 END) as maintenance
    FROM room_types t LEFT JOIN rooms r ON r.room_type_id = t.id
    WHERE t.hotel_id = ? GROUP BY t.id`).bind(hotelId).all();
  return c.json({ overall: overall.results || [], byType: byType.results || [] });
});

reports.get('/guests', async (c) => {
  const hotelId = getHotelId(c);
  const rows = await c.env.DB.prepare(`
    SELECT g.first_name, g.last_name, COUNT(r.id) as total_reservations, COALESCE(SUM(r.total_amount),0) as total_revenue
    FROM guests g LEFT JOIN reservations r ON r.guest_id = g.id
    WHERE g.hotel_id = ? GROUP BY g.id ORDER BY total_revenue DESC LIMIT 20`).bind(hotelId).all();
  return c.json({ topGuests: rows.results || [] });
});

reports.get('/shifts', async (c) => {
  const hotelId = getHotelId(c);
  const from = c.req.query('from');
  const to = c.req.query('to');
  const db = c.env.DB;
  let q = `SELECT * FROM shifts WHERE hotel_id = ?`;
  const params: any[] = [hotelId];
  if (from) { q += ` AND date(start_time) >= date(?)`; params.push(from); }
  if (to) { q += ` AND date(start_time) <= date(?)`; params.push(to); }
  q += ` ORDER BY start_time DESC`;
  const rows = await db.prepare(q).bind(...params).all();
  return c.json(rows.results || []);
});

// Channel performance report - revenue/bookings by OTA source
reports.get('/channels', async (c) => {
  const hotelId = getHotelId(c);
  const from = c.req.query('from');
  const to = c.req.query('to');
  const db = c.env.DB;
  let q = `
    SELECT COALESCE(ch.name, res.source) as channel_name, COUNT(res.id) as bookings,
      COALESCE(SUM(res.total_amount),0) as revenue,
      SUM(CASE WHEN res.status='cancelled' THEN 1 ELSE 0 END) as cancellations
    FROM reservations res LEFT JOIN ota_channels ch ON ch.id = res.channel_id
    WHERE res.hotel_id = ?`;
  const params: any[] = [hotelId];
  if (from) { q += ` AND res.check_in_date >= ?`; params.push(from); }
  if (to) { q += ` AND res.check_in_date <= ?`; params.push(to); }
  q += ` GROUP BY channel_name ORDER BY revenue DESC`;
  const rows = await db.prepare(q).bind(...params).all();
  return c.json(rows.results || []);
});

export default reports;
