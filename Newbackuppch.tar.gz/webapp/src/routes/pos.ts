import { Hono } from 'hono';
import type { AppEnv } from '../types';
import { getHotelId } from '../utils/helpers';

const pos = new Hono<AppEnv>();

pos.get('/items', async (c) => {
  const hotelId = getHotelId(c);
  const rows = await c.env.DB.prepare(`SELECT * FROM pos_items WHERE hotel_id = ? AND is_active = 1 ORDER BY category, name`).bind(hotelId).all();
  return c.json(rows.results || []);
});

pos.post('/items', async (c) => {
  const hotelId = getHotelId(c);
  const b = await c.req.json();
  const r = await c.env.DB.prepare(`INSERT INTO pos_items (hotel_id, name, price, category) VALUES (?, ?, ?, ?)`)
    .bind(hotelId, b.name, b.price, b.category || 'food').run();
  return c.json({ id: r.meta.last_row_id, success: true });
});

pos.get('/orders', async (c) => {
  const hotelId = getHotelId(c);
  const rows = await c.env.DB.prepare(`SELECT * FROM pos_orders WHERE hotel_id = ? ORDER BY created_at DESC LIMIT 100`).bind(hotelId).all();
  return c.json(rows.results || []);
});

pos.post('/orders', async (c) => {
  const hotelId = getHotelId(c);
  const b = await c.req.json();
  const db = c.env.DB;
  const orderNum = 'PO-' + Date.now().toString(36).toUpperCase();
  const r = await db.prepare(`
    INSERT INTO pos_orders (hotel_id, order_number, reservation_id, guest_id, room_id, items, subtotal, tax, total, payment_method, payment_status, shift_id, created_by)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
    .bind(hotelId, orderNum, b.reservation_id || null, b.guest_id || null, b.room_id || null, JSON.stringify(b.items || []), b.subtotal || 0, b.tax || 0, b.total || 0, b.payment_method || 'cash', b.payment_status || 'paid', b.shift_id || null, b.created_by || null)
    .run();
  return c.json({ id: r.meta.last_row_id, order_number: orderNum, success: true });
});

export default pos;
