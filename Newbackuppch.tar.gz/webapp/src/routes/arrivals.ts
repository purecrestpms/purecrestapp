import { Hono } from 'hono';
import type { AppEnv } from '../types';
import { getHotelId, todayStr } from '../utils/helpers';

const arrivals = new Hono<AppEnv>();

arrivals.get('/', async (c) => {
  const hotelId = getHotelId(c);
  const today = todayStr();
  const rows = await c.env.DB.prepare(`
    SELECT res.*, g.first_name, g.last_name, g.phone as guest_phone, g.vip_status,
    rm.room_number, rt.name as room_type_name
    FROM reservations res JOIN guests g ON g.id = res.guest_id
    LEFT JOIN rooms rm ON rm.id = res.room_id LEFT JOIN room_types rt ON rt.id = res.room_type_id
    WHERE res.hotel_id = ? AND res.check_in_date = ? AND res.status != 'cancelled'
    ORDER BY res.status, g.last_name`).bind(hotelId, today).all();
  return c.json(rows.results || []);
});

// Compatibility: /api/inhouse is used by the frontend (renderInHouse) to list
// all currently checked-in guests. This endpoint was previously missing,
// causing the In-House page to fail to load.
const inhouse = new Hono<AppEnv>();
inhouse.get('/', async (c) => {
  const hotelId = getHotelId(c);
  const rows = await c.env.DB.prepare(`
    SELECT res.*, g.first_name, g.last_name, g.phone as guest_phone, g.vip_status,
    rm.room_number, rt.name as room_type_name
    FROM reservations res JOIN guests g ON g.id = res.guest_id
    LEFT JOIN rooms rm ON rm.id = res.room_id LEFT JOIN room_types rt ON rt.id = res.room_type_id
    WHERE res.hotel_id = ? AND res.status = 'checked-in'
    ORDER BY res.check_out_date ASC, g.last_name`).bind(hotelId).all();
  return c.json(rows.results || []);
});

export default arrivals;
export { inhouse };
