export type Bindings = {
  DB: D1Database;
  R2: R2Bucket;
};

export type AppEnv = { Bindings: Bindings };
