import { Hono } from 'hono'
import { serveStatic } from 'hono/cloudflare-workers'
import type { AppEnv } from './types'

import auth from './routes/auth'
import hotels from './routes/hotels'
import roomTypes from './routes/roomTypes'
import rooms from './routes/rooms'
import guests from './routes/guests'
import users from './routes/users'
import reservations from './routes/reservations'
import payments from './routes/payments'
import invoices from './routes/invoices'
import housekeeping from './routes/housekeeping'
import pos from './routes/pos'
import shifts from './routes/shifts'
import messages from './routes/messages'
import loyalty from './routes/loyalty'
import reports from './routes/reports'
import settings from './routes/settings'
import dashboard from './routes/dashboard'
import sync from './routes/sync'
import channels from './routes/channels'
import admin from './routes/admin'
import calendar from './routes/calendar'
import activityLog from './routes/activityLog'
import folio from './routes/folio'
import teams from './routes/teams'
import license from './routes/license'
import roomIcal from './routes/roomIcal'

const app = new Hono<AppEnv>()

app.use('/static/*', serveStatic({ root: './public' }))

app.route('/api/auth', auth)
app.route('/api/hotels', hotels)
app.route('/api/room-types', roomTypes)
app.route('/api/rooms', rooms)
app.route('/api/guests', guests)
app.route('/api/users', users)
app.route('/api/reservations', reservations)
app.route('/api/payments', payments)
app.route('/api/invoices', invoices)
app.route('/api/housekeeping', housekeeping)
app.route('/api/pos', pos)
app.route('/api/shifts', shifts)
app.route('/api/messages', messages)
app.route('/api/loyalty', loyalty)
app.route('/api/reports', reports)
app.route('/api/settings', settings)
app.route('/api/dashboard', dashboard)
app.route('/api/sync', sync)
app.route('/api/channels', channels)
app.route('/api/admin', admin)
app.route('/api/calendar', calendar)
app.route('/api/activity-log', activityLog)
app.route('/api/folio', folio)
app.route('/api/teams', teams)
app.route('/api/license', license)
app.route('/api/room-ical', roomIcal)

// Compatibility aliases for arrivals/in-house convenience endpoints used by the frontend
import arrivals, { inhouse } from './routes/arrivals'
app.route('/api/arrivals', arrivals)
app.route('/api/inhouse', inhouse)

app.get('/sw.js', (c) => c.redirect('/static/sw.js', 301))

app.get('/', (c) => {
  return c.html(`<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>PCH PMS - Property Management System</title>
<meta name="theme-color" content="#6C63FF">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="PCH PMS">
<link rel="manifest" href="/static/manifest.webmanifest">
<link rel="icon" type="image/png" sizes="192x192" href="/static/icon-192.png">
<link rel="apple-touch-icon" href="/static/icon-192.png">
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.5.0/css/all.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/flatpickr/dist/themes/material_purple.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.2/jspdf.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.8.2/jspdf.plugin.autotable.min.js"></script>
<script>
tailwind.config = {
  theme: {
    extend: {
      colors: {
        primary: { 50:'#f0effe', 100:'#e0dffd', 200:'#c1bffb', 300:'#a29ff9', 400:'#837ff7', DEFAULT:'#6C63FF', 600:'#564fcc', 700:'#413b99', 800:'#2b2866', 900:'#161433' },
        sidebar: { DEFAULT:'#1a1145', light:'#2d1f6e', hover:'#3a2d7e' },
        success: '#00C9A7', danger: '#FF6B6B', warning: '#FFD93D', info: '#4FC3F7'
      }
    }
  }
}
</script>
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');
* { font-family: 'Inter', sans-serif; }
::-webkit-scrollbar { width: 6px; height: 6px; }
::-webkit-scrollbar-track { background: #f1f1f1; border-radius: 3px; }
::-webkit-scrollbar-thumb { background: #c5c5d2; border-radius: 3px; }
::-webkit-scrollbar-thumb:hover { background: #6C63FF; }
.sidebar-item { transition: all 0.2s; border-radius: 10px; margin: 2px 8px; }
.sidebar-item:hover, .sidebar-item.active { background: rgba(108,99,255,0.3); }
.sidebar-item.active { background: #6C63FF; }
.card { background: white; border-radius: 16px; box-shadow: 0 2px 12px rgba(0,0,0,0.06); border: 1px solid #f0f0f5; transition: all 0.2s; }
.card:hover { box-shadow: 0 4px 20px rgba(0,0,0,0.1); }
.stat-card { border-radius: 16px; padding: 20px; background: white; border: 1px solid #f0f0f5; transition: all 0.3s; }
.stat-card:hover { transform: translateY(-2px); box-shadow: 0 8px 25px rgba(0,0,0,0.1); }
.room-pill { display: inline-flex; align-items: center; justify-content: center; width: 44px; height: 36px; border-radius: 8px; font-size: 12px; font-weight: 600; cursor: pointer; transition: all 0.2s; border: 2px solid transparent; }
.room-pill:hover { transform: scale(1.1); box-shadow: 0 4px 12px rgba(0,0,0,0.15); }
.room-pill.occupied { background: #6C63FF; color: white; }
.room-pill.available { background: #e8faf5; color: #00C9A7; border-color: #00C9A7; }
.room-pill.reserved { background: #fff8e1; color: #FF9800; border-color: #FF9800; }
.room-pill.maintenance { background: #f5f5f5; color: #9e9e9e; border-color: #9e9e9e; }
.badge { display: inline-flex; align-items: center; padding: 4px 12px; border-radius: 20px; font-size: 11px; font-weight: 600; letter-spacing: 0.5px; text-transform: uppercase; }
.badge-success { background: #e8faf5; color: #00C9A7; }
.badge-warning { background: #fff8e1; color: #FF9800; }
.badge-danger { background: #fde8e8; color: #FF6B6B; }
.badge-info { background: #e3f2fd; color: #2196F3; }
.badge-primary { background: #f0effe; color: #6C63FF; }
.badge-gold { background: #fff8e1; color: #FFB300; }
.badge-platinum { background: #e8eaf6; color: #5C6BC0; }
.badge-silver { background: #f5f5f5; color: #78909C; }
.badge-bronze { background: #efebe9; color: #8D6E63; }
.modal-overlay { position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.5); z-index: 1000; display: flex; align-items: center; justify-content: center; backdrop-filter: blur(4px); }
.modal-content { background: white; border-radius: 20px; max-height: 90vh; overflow-y: auto; box-shadow: 0 25px 60px rgba(0,0,0,0.3); }
.btn { padding: 10px 20px; border-radius: 10px; font-weight: 600; font-size: 14px; cursor: pointer; transition: all 0.2s; display: inline-flex; align-items: center; gap: 8px; border: none; }
.btn:hover { transform: translateY(-1px); box-shadow: 0 4px 12px rgba(0,0,0,0.15); }
.btn-primary { background: #6C63FF; color: white; }
.btn-primary:hover { background: #564fcc; }
.btn-success { background: #00C9A7; color: white; }
.btn-danger { background: #FF6B6B; color: white; }
.btn-warning { background: #FF9800; color: white; }
.btn-outline { background: transparent; border: 2px solid #e0e0e0; color: #666; }
.btn-outline:hover { border-color: #6C63FF; color: #6C63FF; }
.btn-sm { padding: 6px 14px; font-size: 12px; }
.input-field { width: 100%; padding: 10px 14px; border: 2px solid #e8e8f0; border-radius: 10px; font-size: 14px; transition: all 0.2s; background: #fafafe; }
.input-field:focus { outline: none; border-color: #6C63FF; background: white; box-shadow: 0 0 0 3px rgba(108,99,255,0.1); }
.table-row:hover { background: #fafafe; }
.fade-in { animation: fadeIn 0.3s ease-in; }
@keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
select.input-field { appearance: none; background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' fill='%23666' viewBox='0 0 16 16'%3E%3Cpath d='M8 11L3 6h10l-5 5z'/%3E%3C/svg%3E"); background-repeat: no-repeat; background-position: right 12px center; }
.notification-badge { position: absolute; top: -2px; right: -2px; min-width: 18px; height: 18px; border-radius: 9px; background: #FF6B6B; color: white; font-size: 10px; font-weight: 700; display: flex; align-items: center; justify-content: center; }
.offline-indicator { position: fixed; bottom: 0; left: 0; right: 0; background: #FF6B6B; color: white; text-align: center; padding: 8px; font-size: 13px; font-weight: 600; z-index: 9999; display: none; }
.offline-indicator.show { display: block; }
.sync-indicator { position: fixed; bottom: 40px; right: 20px; background: #FF9800; color: white; padding: 8px 16px; border-radius: 20px; font-size: 12px; font-weight: 600; z-index: 9999; display: none; }
.sync-indicator.show { display: flex; align-items: center; gap: 8px; }
.cal-cell { width: 100%; height: 34px; border-radius: 6px; font-size: 10px; display: flex; align-items: center; justify-content: center; cursor: pointer; transition: all 0.15s; border: 1px solid transparent; }
.cal-cell.available { background: #f8f9fc; color: #c5c5d2; }
.cal-cell.available:hover { background: #e8faf5; color: #00C9A7; border-color:#00C9A7; }
.cal-cell.reserved { background: #fff3cd; color: #FF9800; font-weight: 600; }
.cal-cell.occupied { background: #6C63FF; color: white; font-weight: 600; }
.cal-cell.blocked { background: #ececec; color: #9e9e9e; background-image: repeating-linear-gradient(45deg, rgba(0,0,0,0.04), rgba(0,0,0,0.04) 4px, transparent 4px, transparent 8px); }
.cal-row-label { position: sticky; left: 0; background: white; z-index: 5; }
.channel-card { border-radius: 16px; border: 1px solid #f0f0f5; padding: 16px; transition: all .2s; }
.channel-card:hover { box-shadow: 0 4px 20px rgba(0,0,0,0.08); }
.nav-group-label { font-size: 10px; font-weight: 700; letter-spacing: 1px; text-transform: uppercase; color: rgba(255,255,255,0.3); padding: 14px 20px 6px; }
.room-thumb { width: 100%; height: 110px; object-fit: cover; border-radius: 10px; background: #f0f0f5; }
.feature-chip { display: inline-flex; align-items: center; gap: 4px; padding: 3px 10px; border-radius: 20px; background: #f0effe; color: #6C63FF; font-size: 11px; font-weight: 600; }
.img-upload-drop { border: 2px dashed #e0e0ea; border-radius: 14px; padding: 24px; text-align: center; cursor: pointer; transition: all .2s; }
.img-upload-drop:hover { border-color: #6C63FF; background: #f8f8ff; }
.mobile-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 40; display: none; }
.mobile-overlay.show { display: block; }
#sidebar-toggle-btn { display: none; }
@media (max-width: 900px) {
  #sidebar { position: fixed; top: 0; left: 0; bottom: 0; z-index: 50; transform: translateX(-100%); transition: transform .25s ease; width: 260px !important; min-width: 260px !important; }
  #sidebar.mobile-open { transform: translateX(0); }
  #sidebar-toggle-btn { display: flex; }
  .main-flex-wrap { flex-direction: column; }
  header.app-header { padding-left: 1rem; padding-right: 1rem; }
  main#main-content { padding: 0.75rem !important; }
  .grid-cols-6, .grid-cols-5, .grid-cols-4 { grid-template-columns: repeat(2, minmax(0,1fr)) !important; }
  .lg\\:col-span-2 { grid-column: span 1 / span 1 !important; }
  table { font-size: 12px; }
  .modal-content { max-width: 95vw !important; margin: 0 8px; }
  .hide-mobile { display: none !important; }
}
@media (max-width: 480px) {
  .grid-cols-6, .grid-cols-4, .grid-cols-3, .grid-cols-2 { grid-template-columns: repeat(2, minmax(0,1fr)) !important; }
}
@media print {
  .no-print { display: none !important; }
  body { background: white !important; }
  .modal-overlay { position: static; background: none; backdrop-filter: none; }
  .modal-content { box-shadow: none; max-height: none; border-radius: 0; }
}
</style>
</head>
<body class="bg-gray-50">
<div id="offline-bar" class="offline-indicator"><i class="fas fa-wifi-slash"></i> You are offline. Changes will sync when connection returns.</div>
<div id="sync-bar" class="sync-indicator"><i class="fas fa-sync fa-spin"></i> Syncing...</div>
<div id="update-bar" class="update-indicator" style="display:none;position:fixed;top:0;left:0;right:0;background:#6C63FF;color:white;text-align:center;padding:10px;z-index:10000;font-size:13px;font-weight:600;">
  <i class="fas fa-arrow-up"></i> New version available! <button onclick="location.reload()" style="background:white;color:#6C63FF;border:none;padding:4px 12px;border-radius:20px;cursor:pointer;font-weight:700;margin-left:8px;">Update Now</button>
</div>
<div id="app"></div>
<script src="/static/app.js"></script>
</body>
</html>`)
})

export default app
